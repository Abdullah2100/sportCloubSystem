﻿using Microsoft.Win32;
using SportCllubeBuisness;
using System;

namespace SportClubeSystem.GenralClass
{
    public class clsEmployee
    {
        public static clsEmployeeBuisness employee;


        public static void saveEmployeeToRegistory(string userNamee, string password)
        {
            string keyPath = @"HKEY_LOCAL_MACHINE\SOFTWARE\SportCloupApp";
            string userName = "username";
            string userData = userNamee;
            string passwordName = "password";
            string passwordData = password;
            try
            {

                Microsoft.Win32.Registry.SetValue(keyPath, userName, userData, RegistryValueKind.String);
                Microsoft.Win32.Registry.SetValue(keyPath, passwordName, passwordData, RegistryValueKind.String);
            }
            catch (Exception e)
            {
                clsEventHandlerBuisness.addingEvent(e.Message);

            }

        }
        public static bool isUserInRegistory(ref string userName, ref string password)
        {
            bool isFound = false;
            string keyPath = @"HKEY_LOCAL_MACHINE\SOFTWARE\SportCloupApp";

            string userNameAndPassword;
            try
            {
                userName = Registry.GetValue(keyPath, "userName", null) as string;
                password = Registry.GetValue(keyPath, "password", null) as string;
                if (!string.IsNullOrEmpty(userName + password))
                    isFound = true;
            }
            catch (Exception e)
            {
                //  clsEventHandlerBuisness.addingEvent(e.Message);

            }
            return isFound;
        }
    }
}
