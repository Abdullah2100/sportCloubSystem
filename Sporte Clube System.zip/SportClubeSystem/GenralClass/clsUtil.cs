﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace SportClubeSystem.GenralClass
{
    public class clsUtil
    {

        public static string decodePassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
            }

        }

        public static bool compareHash(string password, string hashPassword)
        {
            return decodePassword(password).Equals(hashPassword);
        }

    }
}
