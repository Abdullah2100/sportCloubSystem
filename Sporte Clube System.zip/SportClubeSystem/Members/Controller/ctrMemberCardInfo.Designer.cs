﻿namespace SportClubeSystem.Members.Controller
{
    partial class ctrMemberCardInfo
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbMember = new System.Windows.Forms.GroupBox();
            this.lbIsActive = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbMemberID = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ctrPersonCard2 = new SportClubeSystem.People.ctrPersonCard();
            this.gbMember.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbMember
            // 
            this.gbMember.BackColor = System.Drawing.Color.White;
            this.gbMember.Controls.Add(this.lbIsActive);
            this.gbMember.Controls.Add(this.label3);
            this.gbMember.Controls.Add(this.lbMemberID);
            this.gbMember.Controls.Add(this.label1);
            this.gbMember.Location = new System.Drawing.Point(21, 317);
            this.gbMember.Name = "gbMember";
            this.gbMember.Size = new System.Drawing.Size(870, 108);
            this.gbMember.TabIndex = 1;
            this.gbMember.TabStop = false;
            this.gbMember.Text = "Member Info";
            // 
            // lbIsActive
            // 
            this.lbIsActive.AutoSize = true;
            this.lbIsActive.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.lbIsActive.Location = new System.Drawing.Point(676, 46);
            this.lbIsActive.Name = "lbIsActive";
            this.lbIsActive.Size = new System.Drawing.Size(72, 26);
            this.lbIsActive.TabIndex = 13;
            this.lbIsActive.Text = "[????]";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.label3.Location = new System.Drawing.Point(556, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 26);
            this.label3.TabIndex = 12;
            this.label3.Text = "Is Active :";
            // 
            // lbMemberID
            // 
            this.lbMemberID.AutoSize = true;
            this.lbMemberID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.lbMemberID.Location = new System.Drawing.Point(170, 46);
            this.lbMemberID.Name = "lbMemberID";
            this.lbMemberID.Size = new System.Drawing.Size(72, 26);
            this.lbMemberID.TabIndex = 11;
            this.lbMemberID.Text = "[????]";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.label1.Location = new System.Drawing.Point(36, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 26);
            this.label1.TabIndex = 10;
            this.label1.Text = "Member ID :";
            // 
            // ctrPersonCard2
            // 
            this.ctrPersonCard2.BackColor = System.Drawing.Color.White;
            this.ctrPersonCard2.Location = new System.Drawing.Point(11, -4);
            this.ctrPersonCard2.Name = "ctrPersonCard2";
            this.ctrPersonCard2.Size = new System.Drawing.Size(893, 316);
            this.ctrPersonCard2.TabIndex = 2;
            // 
            // ctrMemberCardInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ctrPersonCard2);
            this.Controls.Add(this.gbMember);
            this.Name = "ctrMemberCardInfo";
            this.Size = new System.Drawing.Size(907, 438);
            this.gbMember.ResumeLayout(false);
            this.gbMember.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private People.ctrPersonCard ctrPersonCard1;
        private System.Windows.Forms.GroupBox gbMember;
        private System.Windows.Forms.Label lbIsActive;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbMemberID;
        private System.Windows.Forms.Label label1;
        private People.ctrPersonCard ctrPersonCard2;
    }
}
