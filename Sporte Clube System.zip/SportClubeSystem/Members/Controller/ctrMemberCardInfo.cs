﻿using SportCllubeBuisness;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportClubeSystem.Members.Controller
{
    public partial class ctrMemberCardInfo : UserControl
    {
        public ctrMemberCardInfo()
        {
            InitializeComponent();
        }
        public void loadData(int memberID)
        {
            clsMemberBuisness member = clsMemberBuisness.findMemberByID(memberID);
            if(member == null)
            {
                return;
            }
            ctrPersonCard2.loadData(member.personID);
            lbMemberID.Text = member.id.ToString();
            lbIsActive.Text = member.isActive?"true":"false";
        }

         
    }
}
