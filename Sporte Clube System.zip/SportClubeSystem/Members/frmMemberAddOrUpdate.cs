﻿using SportCllubeBuisness;
using SportClubeSystem.GenralClass;
using System;
using System.Windows.Forms;

namespace SportClubeSystem.Members
{
    public partial class frmMemberAddOrUpdate : Form
    {
        public enum enMode { add, update }
        private enMode _mode;
        clsMemberBuisness _member;
        private int _memberID = 0;
        private int _personID

        {
            get { return ctrPersonCardWithFilter1.personID; }
        }
        clsPeopleBuisness _person
        {
            get { return ctrPersonCardWithFilter1.person; }
        }
        public frmMemberAddOrUpdate()
        {
            InitializeComponent();
            _mode = enMode.add;
        }

        public frmMemberAddOrUpdate(int memberID)
        {
            InitializeComponent();
            _mode = enMode.update;
            this._memberID = memberID;
        }

        private void _reaseate()
        {
            if (_mode == enMode.add)
            {
                lbHeaderTitle.Text = "Add New Member";
                btnSave.Text = "Save";
                _member = new clsMemberBuisness();
            }
            else
            {
                lbHeaderTitle.Text = "Update member";
                btnSave.Text = "Update";
                btnSave.Enabled = true;
            }

        }

        private void _loadData(int memberID)
        {
            _member = clsMemberBuisness.findMemberByID(memberID);
            if (_member == null)
            {
                MessageBox.Show("Member Not Found", "Error", MessageBoxButtons.OK);
                this.Close();
                return;
            }
            ctrPersonCardWithFilter1.loadPersonData(_member.personID);
            ctrPersonCardWithFilter1.filterState = false;
            chkbIsActive.Checked = _member.isActive;
        }

        private void ctrPersonCardWithFilter1_onAddComplate(int obj)
        {
            if (_personID != 0)
            {
                MessageBox.Show("Person Not Found", "Error", MessageBoxButtons.OK);
                btnSave.Enabled = false;
                gbMemberInfo.Enabled = false;
                return;
            }
            ctrPersonCardWithFilter1.loadPersonData(obj);
            gbMemberInfo.Enabled = true;
            btnSave.Enabled = true;

        }
        private void ctrPersonCardWithFilter1_onPersonSelect(int obj)
        {

            if (clsMemberBuisness.isMemberExistByPersonID(obj))
            {
                MessageBox.Show("Person is Linked to Member", "Error", MessageBoxButtons.OK);
                btnSave.Enabled = false;
                gbMemberInfo.Enabled = false;
                return;
            }
            ctrPersonCardWithFilter1.loadPersonData(obj);
            gbMemberInfo.Enabled = true;
            btnSave.Enabled = true;
        }

        private void frmMemberAddOrUpdate_Load(object sender, EventArgs e)
        {
            _reaseate();
            if (_mode == enMode.update)
                _loadData(_memberID);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (_personID == 0)
            {
                MessageBox.Show("Please select person to link it ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            _member.isActive = chkbIsActive.Checked;
            _member.addBy = clsEmployee.employee.id;
            if (_member.save())
            {
                MessageBox.Show("Member Data Seve Seccessfuly", "Done", MessageBoxButtons.OK);
                btnSave.Text = "Update";
                return;
            }
            else
            {
                MessageBox.Show("Could Not Linke Member To Person", "Error", MessageBoxButtons.OK);
                return;
            }
        }

    }
}
