﻿namespace SportClubeSystem.Members
{
    partial class frmMemberAddOrUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbHeaderTitle = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.gbMemberInfo = new System.Windows.Forms.GroupBox();
            this.chkbIsActive = new System.Windows.Forms.CheckBox();
            this.ctrPersonCardWithFilter1 = new SportClubeSystem.People.controller.ctrPersonCardWithFilter();
            this.gbMemberInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbHeaderTitle
            // 
            this.lbHeaderTitle.AutoSize = true;
            this.lbHeaderTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHeaderTitle.ForeColor = System.Drawing.Color.Red;
            this.lbHeaderTitle.Location = new System.Drawing.Point(285, 47);
            this.lbHeaderTitle.Name = "lbHeaderTitle";
            this.lbHeaderTitle.Size = new System.Drawing.Size(402, 54);
            this.lbHeaderTitle.TabIndex = 9;
            this.lbHeaderTitle.Text = "Add new Member";
            // 
            // btnClose
            // 
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.btnClose.Location = new System.Drawing.Point(638, 633);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(132, 52);
            this.btnClose.TabIndex = 10;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnSave
            // 
            this.btnSave.Enabled = false;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.btnSave.Location = new System.Drawing.Point(814, 633);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(132, 52);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // gbMemberInfo
            // 
            this.gbMemberInfo.Controls.Add(this.chkbIsActive);
            this.gbMemberInfo.Location = new System.Drawing.Point(78, 550);
            this.gbMemberInfo.Name = "gbMemberInfo";
            this.gbMemberInfo.Size = new System.Drawing.Size(868, 68);
            this.gbMemberInfo.TabIndex = 12;
            this.gbMemberInfo.TabStop = false;
            this.gbMemberInfo.Text = "Member Info";
            // 
            // chkbIsActive
            // 
            this.chkbIsActive.AutoSize = true;
            this.chkbIsActive.Location = new System.Drawing.Point(33, 30);
            this.chkbIsActive.Name = "chkbIsActive";
            this.chkbIsActive.Size = new System.Drawing.Size(76, 20);
            this.chkbIsActive.TabIndex = 1;
            this.chkbIsActive.Text = "isActive";
            this.chkbIsActive.UseVisualStyleBackColor = true;
            // 
            // ctrPersonCardWithFilter1
            // 
            this.ctrPersonCardWithFilter1.BackColor = System.Drawing.Color.White;
            this.ctrPersonCardWithFilter1.filterState = true;
            this.ctrPersonCardWithFilter1.Location = new System.Drawing.Point(64, 117);
            this.ctrPersonCardWithFilter1.Name = "ctrPersonCardWithFilter1";
            this.ctrPersonCardWithFilter1.Size = new System.Drawing.Size(895, 427);
            this.ctrPersonCardWithFilter1.TabIndex = 2;
            this.ctrPersonCardWithFilter1.onPersonSelect += new System.Action<int>(this.ctrPersonCardWithFilter1_onPersonSelect);
            this.ctrPersonCardWithFilter1.onAddComplate += new System.Action<int>(this.ctrPersonCardWithFilter1_onAddComplate);
            // 
            // frmMemberAddOrUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(985, 710);
            this.Controls.Add(this.ctrPersonCardWithFilter1);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.gbMemberInfo);
            this.Controls.Add(this.lbHeaderTitle);
            this.Name = "frmMemberAddOrUpdate";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmMemberAddOrUpdate";
            this.Load += new System.EventHandler(this.frmMemberAddOrUpdate_Load);
            this.gbMemberInfo.ResumeLayout(false);
            this.gbMemberInfo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lbHeaderTitle;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.GroupBox gbMemberInfo;
        private System.Windows.Forms.CheckBox chkbIsActive;
        private People.controller.ctrPersonCardWithFilter ctrPersonCardWithFilter1;
    }
}