﻿namespace SportClubeSystem.Members
{
    partial class frmListMember
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbHeaderTitle = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtFilterHolder = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.lbListSize = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbFilter = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.dgvMember = new System.Windows.Forms.DataGridView();
            this.cmsMember = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.addMmeberToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateMemberToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteMemberToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showMemberInfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.activateMebmerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deActivateMemberToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cbStateFilter = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMember)).BeginInit();
            this.cmsMember.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbHeaderTitle
            // 
            this.lbHeaderTitle.AutoSize = true;
            this.lbHeaderTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHeaderTitle.ForeColor = System.Drawing.Color.Red;
            this.lbHeaderTitle.Location = new System.Drawing.Point(370, 332);
            this.lbHeaderTitle.Name = "lbHeaderTitle";
            this.lbHeaderTitle.Size = new System.Drawing.Size(497, 54);
            this.lbHeaderTitle.TabIndex = 9;
            this.lbHeaderTitle.Text = "Member Management";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SportClubeSystem.Properties.Resources.Members;
            this.pictureBox1.Location = new System.Drawing.Point(411, 28);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(416, 290);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // txtFilterHolder
            // 
            this.txtFilterHolder.Location = new System.Drawing.Point(248, 414);
            this.txtFilterHolder.Name = "txtFilterHolder";
            this.txtFilterHolder.Size = new System.Drawing.Size(188, 22);
            this.txtFilterHolder.TabIndex = 22;
            this.txtFilterHolder.Visible = false;
            this.txtFilterHolder.TextChanged += new System.EventHandler(this.txtFilterHolder_TextChanged);
            this.txtFilterHolder.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFilterHolder_KeyPress);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(1086, 649);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(159, 49);
            this.btnClose.TabIndex = 21;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            // 
            // lbListSize
            // 
            this.lbListSize.AutoSize = true;
            this.lbListSize.Location = new System.Drawing.Point(101, 665);
            this.lbListSize.Name = "lbListSize";
            this.lbListSize.Size = new System.Drawing.Size(14, 16);
            this.lbListSize.TabIndex = 20;
            this.lbListSize.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(30, 665);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 16);
            this.label5.TabIndex = 19;
            this.label5.Text = "Recourd :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 665);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(14, 16);
            this.label4.TabIndex = 18;
            this.label4.Text = "#";
            // 
            // cbFilter
            // 
            this.cbFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbFilter.FormattingEnabled = true;
            this.cbFilter.Items.AddRange(new object[] {
            "none",
            "Member ID",
            "Person ID",
            "FullName",
            "Gender",
            "BrithDay",
            "Nationality",
            "Phone",
            "Is Active"});
            this.cbFilter.Location = new System.Drawing.Point(79, 414);
            this.cbFilter.Name = "cbFilter";
            this.cbFilter.Size = new System.Drawing.Size(154, 24);
            this.cbFilter.TabIndex = 15;
            this.cbFilter.SelectedIndexChanged += new System.EventHandler(this.cbFilter_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.label2.Location = new System.Drawing.Point(10, 415);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 22);
            this.label2.TabIndex = 17;
            this.label2.Text = "Filter :";
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.White;
            this.btnAdd.Image = global::SportClubeSystem.Properties.Resources.add;
            this.btnAdd.Location = new System.Drawing.Point(1181, 389);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(64, 47);
            this.btnAdd.TabIndex = 16;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // dgvMember
            // 
            this.dgvMember.BackgroundColor = System.Drawing.Color.White;
            this.dgvMember.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMember.ContextMenuStrip = this.cmsMember;
            this.dgvMember.Location = new System.Drawing.Point(12, 451);
            this.dgvMember.Name = "dgvMember";
            this.dgvMember.RowHeadersWidth = 51;
            this.dgvMember.RowTemplate.Height = 24;
            this.dgvMember.Size = new System.Drawing.Size(1233, 184);
            this.dgvMember.TabIndex = 14;
            // 
            // cmsMember
            // 
            this.cmsMember.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.cmsMember.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addMmeberToolStripMenuItem,
            this.updateMemberToolStripMenuItem,
            this.deleteMemberToolStripMenuItem,
            this.showMemberInfoToolStripMenuItem,
            this.activateMebmerToolStripMenuItem,
            this.deActivateMemberToolStripMenuItem});
            this.cmsMember.Name = "cmsMember";
            this.cmsMember.Size = new System.Drawing.Size(212, 176);
            this.cmsMember.Opening += new System.ComponentModel.CancelEventHandler(this.cmsMember_Opening);
            // 
            // addMmeberToolStripMenuItem
            // 
            this.addMmeberToolStripMenuItem.Name = "addMmeberToolStripMenuItem";
            this.addMmeberToolStripMenuItem.Size = new System.Drawing.Size(211, 24);
            this.addMmeberToolStripMenuItem.Text = "Add Mmeber";
            this.addMmeberToolStripMenuItem.Click += new System.EventHandler(this.addMmeberToolStripMenuItem_Click);
            // 
            // updateMemberToolStripMenuItem
            // 
            this.updateMemberToolStripMenuItem.Name = "updateMemberToolStripMenuItem";
            this.updateMemberToolStripMenuItem.Size = new System.Drawing.Size(211, 24);
            this.updateMemberToolStripMenuItem.Text = "Update Member";
            this.updateMemberToolStripMenuItem.Click += new System.EventHandler(this.updateMemberToolStripMenuItem_Click);
            // 
            // deleteMemberToolStripMenuItem
            // 
            this.deleteMemberToolStripMenuItem.Name = "deleteMemberToolStripMenuItem";
            this.deleteMemberToolStripMenuItem.Size = new System.Drawing.Size(211, 24);
            this.deleteMemberToolStripMenuItem.Text = "Delete Member";
            this.deleteMemberToolStripMenuItem.Click += new System.EventHandler(this.deleteMemberToolStripMenuItem_Click);
            // 
            // showMemberInfoToolStripMenuItem
            // 
            this.showMemberInfoToolStripMenuItem.Name = "showMemberInfoToolStripMenuItem";
            this.showMemberInfoToolStripMenuItem.Size = new System.Drawing.Size(211, 24);
            this.showMemberInfoToolStripMenuItem.Text = "Show member Info";
            this.showMemberInfoToolStripMenuItem.Click += new System.EventHandler(this.showMemberInfoToolStripMenuItem_Click);
            // 
            // activateMebmerToolStripMenuItem
            // 
            this.activateMebmerToolStripMenuItem.Name = "activateMebmerToolStripMenuItem";
            this.activateMebmerToolStripMenuItem.Size = new System.Drawing.Size(211, 24);
            this.activateMebmerToolStripMenuItem.Text = "Activate Mebmer";
            this.activateMebmerToolStripMenuItem.Click += new System.EventHandler(this.activateMebmerToolStripMenuItem_Click);
            // 
            // deActivateMemberToolStripMenuItem
            // 
            this.deActivateMemberToolStripMenuItem.Name = "deActivateMemberToolStripMenuItem";
            this.deActivateMemberToolStripMenuItem.Size = new System.Drawing.Size(211, 24);
            this.deActivateMemberToolStripMenuItem.Text = "DeActivate Member";
            this.deActivateMemberToolStripMenuItem.Click += new System.EventHandler(this.deActivateMemberToolStripMenuItem_Click);
            // 
            // cbStateFilter
            // 
            this.cbStateFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbStateFilter.FormattingEnabled = true;
            this.cbStateFilter.Items.AddRange(new object[] {
            "All",
            "Yes",
            "No"});
            this.cbStateFilter.Location = new System.Drawing.Point(248, 413);
            this.cbStateFilter.Name = "cbStateFilter";
            this.cbStateFilter.Size = new System.Drawing.Size(140, 24);
            this.cbStateFilter.TabIndex = 23;
            this.cbStateFilter.Visible = false;
            this.cbStateFilter.SelectedIndexChanged += new System.EventHandler(this.cbStateFilter_SelectedIndexChanged);
            // 
            // frmListMember
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1260, 710);
            this.Controls.Add(this.cbStateFilter);
            this.Controls.Add(this.txtFilterHolder);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lbListSize);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cbFilter);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.dgvMember);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lbHeaderTitle);
            this.Name = "frmListMember";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmListMember";
            this.Load += new System.EventHandler(this.frmListMember_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMember)).EndInit();
            this.cmsMember.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbHeaderTitle;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtFilterHolder;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lbListSize;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbFilter;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DataGridView dgvMember;
        private System.Windows.Forms.ComboBox cbStateFilter;
        private System.Windows.Forms.ContextMenuStrip cmsMember;
        private System.Windows.Forms.ToolStripMenuItem addMmeberToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateMemberToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteMemberToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showMemberInfoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem activateMebmerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deActivateMemberToolStripMenuItem;
    }
}