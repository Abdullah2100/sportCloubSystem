﻿using SportCllubeBuisness;
using System;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;

namespace SportClubeSystem.Members
{
    public partial class frmListMember : Form
    {
        DataTable dtMember;
        public frmListMember()
        {
            InitializeComponent();
        }

        private void _loadData()
        {
            cbFilter.SelectedIndex = 0;
            dtMember = clsMemberBuisness.getAllMember();
            dgvMember.DataSource = dtMember;
            if (dgvMember.Rows.Count > 0)
            {

                dgvMember.Columns[0].HeaderText = "Member ID";
                dgvMember.Columns[0].Width = 60;


                dgvMember.Columns[1].HeaderText = "Person ID";
                dgvMember.Columns[1].Width = 60;


                dgvMember.Columns[2].HeaderText = "FullName";
                dgvMember.Columns[2].Width = 310;

                dgvMember.Columns[3].HeaderText = "Gender";
                dgvMember.Columns[3].Width = 50;


                dgvMember.Columns[4].HeaderText = "BrithDay";
                dgvMember.Columns[4].Width = 130;


                dgvMember.Columns[5].HeaderText = "Nationality";
                dgvMember.Columns[5].Width = 60;



                dgvMember.Columns[6].HeaderText = "Phone";
                dgvMember.Columns[6].Width = 120;



                dgvMember.Columns[7].HeaderText = "Is Active";
                dgvMember.Columns[7].Width = 80;


                lbListSize.Text = dtMember.Rows.Count.ToString();

            }

        }
        private void frmListMember_Load(object sender, EventArgs e)
        {
            _loadData();
        }

        private void cbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbFilter.Text == "Is Active")
            {
                cbStateFilter.Visible = (cbFilter.Text == "Is Active");
                cbStateFilter.SelectedIndex = 0;
                txtFilterHolder.Visible = false;


            }
            else
            {
                txtFilterHolder.Visible = (cbFilter.Text != "none");
                txtFilterHolder.Text = "";
                cbStateFilter.Visible = (cbFilter.Text == "Is Active");
            }
            txtFilterHolder.Focus();


        }

        private void txtFilterHolder_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (cbFilter.Text == "Member ID" || cbFilter.Text == "Person ID")
            {
                if (char.IsLetter(e.KeyChar))
                {
                    e.Handled = true;
                }
            }
        }

        private void txtFilterHolder_TextChanged(object sender, EventArgs e)
        {
            string columnName = "";
            switch (cbFilter.Text)
            {
                case "Member ID":
                    { columnName = "memberID"; }
                    break;

                case "Person ID":
                    { columnName = "personID"; }
                    break;

                case "FullName":
                    { columnName = "fullName"; }
                    break;

                case "Gender":
                    { columnName = "gender"; }
                    break;
                case "BrithDay":
                    { columnName = "bithDay"; }
                    break;
                case "Nationality":
                    { columnName = "nationality"; }
                    break;
                case "Phone":
                    { columnName = "phone"; }
                    break;
                case "Is Active":
                    { columnName = "isActive"; }
                    break;

                default:
                    {
                        columnName = "phone";
                    }
                    break;
            }


            if (string.IsNullOrEmpty(txtFilterHolder.Text) || columnName == "none")
            {
                txtFilterHolder.Text = "";
                dtMember.DefaultView.RowFilter = "";
                return;
            }

            if (columnName == "personID" || columnName == "memberID")
            {
                dtMember.DefaultView.RowFilter = string.Format(" '[{0}]' = '{1}' ", columnName, txtFilterHolder.Text);
            }
            else
            {
                dtMember.DefaultView.RowFilter = string.Format("'[{0}]' like '{1}%'", columnName, txtFilterHolder.Text);
            }


        }

        private void cbStateFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            string filterName = "isActive";
            string columnState = "";
            switch (cbStateFilter.Text)
            {
                case "No":
                    {
                        columnState = "0";

                    }
                    break;
                case "Yes":
                    {
                        columnState = "1";
                    }
                    break;

                default:
                    {
                        columnState = "All";
                    }
                    break;
            }
            if (columnState == "All")
            {
                dtMember.DefaultView.RowFilter = "";
                return;
            }

            dtMember.DefaultView.RowFilter = string.Format("{0} = {1}", filterName, columnState);


        }

        private void addMmeberToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMemberAddOrUpdate form = new frmMemberAddOrUpdate();
            form.ShowDialog();
            _loadData();
        }

        private void updateMemberToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int memberID = (int)dgvMember.CurrentRow.Cells[0].Value;
            frmMemberAddOrUpdate form = new frmMemberAddOrUpdate(memberID);
            form.ShowDialog();
            _loadData();

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            frmMemberAddOrUpdate form = new frmMemberAddOrUpdate();
            form.ShowDialog();
            _loadData();
        }

        private void activateMebmerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int memberID = (int)dgvMember.CurrentRow.Cells[0].Value;
            if (MessageBox.Show("Are You Sure You Want to Activate Member", "Question", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == DialogResult.OK)
            {
                if (clsMemberBuisness.activateMember(memberID))
                {
                    MessageBox.Show("Activate Member Secssfuly", "Question");
                    _loadData();
                }
            }

        }

        private void deActivateMemberToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int memberID = (int)dgvMember.CurrentRow.Cells[0].Value;

            if (MessageBox.Show("Are You Sure You Want to Deactivate Member", "Question", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == DialogResult.OK)
            {
                if (clsMemberBuisness.deActivateMember(memberID))
                {
                    MessageBox.Show("DeActivate Member Secssfuly", "Question", MessageBoxButtons.OK);
                    _loadData();
                }
            }
        }

        private void cmsMember_Opening(object sender, CancelEventArgs e)
        {
            bool hasData = dtMember.Rows.Count > 0;
            int memberID = !hasData ? 0 : (int)dgvMember.CurrentRow.Cells[0].Value;
            bool state = hasData == false ? false : clsMemberBuisness.isMemberActiveByID(memberID);
            activateMebmerToolStripMenuItem.Enabled = (!state && hasData);
            deActivateMemberToolStripMenuItem.Enabled = (hasData && state);
            updateMemberToolStripMenuItem.Enabled = (hasData && state);
            showMemberInfoToolStripMenuItem.Enabled = (hasData && state);
            deleteMemberToolStripMenuItem.Enabled = (hasData && state);
        }

        private void showMemberInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int memberID = (int)dgvMember.CurrentRow.Cells[0].Value;

            frmShowMemberInfo form = new frmShowMemberInfo(memberID);
            form.ShowDialog();
        }

        private void deleteMemberToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int memberID = (int)dgvMember.CurrentRow.Cells[0].Value;

            if (MessageBox.Show("Are You Sure You Delete Member", "Question", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == DialogResult.OK)
            {
                if (clsMemberBuisness.deleteMemberByID(memberID))
                {
                    MessageBox.Show("Member Delete Sucssfuly", "Done", MessageBoxButtons.OK);
                    _loadData();
                }
                else
                {
                    MessageBox.Show("Member Could Not Delete Because It is Linked", "Error", MessageBoxButtons.OK);
                }
            }
        }
    }
}
