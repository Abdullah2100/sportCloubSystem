﻿using SportCllubeBuisness;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportClubeSystem.Members
{
    public partial class frmShowMemberInfo : Form
    {
        private int _memberID;
        private clsMemberBuisness _member;
        public frmShowMemberInfo(int memberID)
        {
            InitializeComponent();
            _memberID = memberID;
        }

        private void frmShowMemberInfo_Load(object sender, EventArgs e)
        {
            _member = clsMemberBuisness.findMemberByID(_memberID);

            if(_member == null)
            {
                           
                MessageBox.Show("Member Not Found", "Error", MessageBoxButtons.OK);
                this.Close();
                return;
            }
            ctrMemberCardInfo2.loadData(_memberID);

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

           }
}
