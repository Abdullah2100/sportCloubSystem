﻿using SportCllubeBuisness;
using SportClubeSystem.Coach;
using SportClubeSystem.CoachTraining;
using SportClubeSystem.Sports;
using System.Data;
using System.Windows.Forms;

namespace SportClubeSystem.SportCoaches
{
    public partial class frmCoachTrainingList : Form
    {
        DataTable dtCoachTraining = new DataTable();

        public frmCoachTrainingList()
        {
            InitializeComponent();
        }

        void _loadData()
        {
            cbFilter.SelectedIndex = 0;

            dtCoachTraining = clsCoachTrainingBuisness.getAllCoachsTraingin();
            dgvCoachTraining.DataSource = dtCoachTraining;


            if (dtCoachTraining.Rows.Count > 0)
            {

                dgvCoachTraining.Columns[0].HeaderText = "Coachs Trainging ID";
                dgvCoachTraining.Columns[0].Width = 50;


                dgvCoachTraining.Columns[1].HeaderText = "FullName";
                dgvCoachTraining.Columns[1].Width = 250;

                dgvCoachTraining.Columns[2].HeaderText = "is Training Avalidable";
                dgvCoachTraining.Columns[2].Width = 100;

                dgvCoachTraining.Columns[3].HeaderText = "Sport Name";
                dgvCoachTraining.Columns[3].Width = 150;



                dgvCoachTraining.Columns[4].HeaderText = " Start At ";
                dgvCoachTraining.Columns[4].Width = 70;

                dgvCoachTraining.Columns[5].HeaderText = "End At ";
                dgvCoachTraining.Columns[5].Width = 70;

                dgvCoachTraining.Columns[6].HeaderText = "Cost";
                dgvCoachTraining.Columns[6].Width = 100;

            }
        }

        private void frmSpotCoachesList_Load(object sender, System.EventArgs e)
        {
            _loadData();
        }

        private void cbFilter_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            txtFilterHolder.Text = "";

            if (cbFilter.SelectedIndex == 0)
            {
                txtFilterHolder.Enabled = (cbFilter.SelectedIndex != 0);
                cbpIsAvalialbe.Visible = (cbFilter.SelectedIndex == 3);
            }
            else
            {
                txtFilterHolder.Enabled = (cbFilter.SelectedIndex != 0);
                cbpIsAvalialbe.Visible = (cbFilter.SelectedIndex == 3);
                txtFilterHolder.Visible = (cbFilter.SelectedIndex != 3);

            }

        }

        private void txtFilterHolder_TextChanged(object sender, System.EventArgs e)
        {
            string columnName = "";

            switch (cbFilter.Text)
            {
                case "Coachs Trainging ID":
                    {
                        columnName = "CoachsTraingingID";
                    }
                    break;


                case "FullName":
                    {
                        columnName = "fullName";
                    }
                    break;
                    ;

                case "is Training Avalidable":
                    {
                        columnName = "isAvaliable";
                    }
                    break;

                case "Sport Name":
                    {
                        columnName = "sportName";

                    }
                    break;


                case "Start At":
                    {
                        columnName = "startAt";

                    }
                    break;

                case "End At":
                    {

                        columnName = "endAt";
                    }
                    break;

                case "Cost":
                    {
                        columnName = "cost";

                    }
                    break;

                default:
                    {

                        columnName = "none";
                    }
                    break;
            }

            if (string.IsNullOrEmpty(txtFilterHolder.Text) || columnName == "none")
            {
                dtCoachTraining.DefaultView.RowFilter = "";
                return;
            }

            if (columnName == "CoachsTraingingID")

                dtCoachTraining.DefaultView.RowFilter = string.Format("[{0}] = {1}", columnName, txtFilterHolder.Text);

            else
                dtCoachTraining.DefaultView.RowFilter = string.Format("[{0}] like '{1}%'", columnName, txtFilterHolder.Text);


        }

        private void txtFilterHolder_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (cbFilter.SelectedIndex == 0)
            {
                if (char.IsDigit
                    (e.KeyChar))
                {
                    e.Handled = true;
                }
            }
        }

        private void cbpIsAvalialbe_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            string columnName = "";
            switch (cbpIsAvalialbe.Text)
            {
                case "No": { columnName = "0"; } break;
                case "Yes": { columnName = "1"; } break;
            }
            if (columnName == "")
                dtCoachTraining.DefaultView.RowFilter = "";
            else
                dtCoachTraining.DefaultView.RowFilter = string.Format("[{0}] = {1}", "isAvaliable", columnName);

        }

        private void btnAdd_Click(object sender, System.EventArgs e)
        {
            frmAddOrUpdateCoachTraining form = new frmAddOrUpdateCoachTraining();
            form.ShowDialog();
        }

        private void cmsCoachTraing_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {
            bool hasData = dtCoachTraining.Rows.Count > 0;
            int trianingCoachID = !hasData ? 0 : (int)dgvCoachTraining.CurrentRow.Cells[0].Value;
            bool coatchTraingingState = !hasData ? false : clsCoachTrainingBuisness.isCoachTrainingActive(trianingCoachID);
            activeCoachTrainingToolStripMenuItem.Enabled = (!coatchTraingingState && hasData);
            deActiveCoachTrainingToolStripMenuItem.Enabled = (coatchTraingingState && hasData);
            deleteCoachTrainingToolStripMenuItem.Enabled = (coatchTraingingState && hasData);
            updateCoachTrainingToolStripMenuItem.Enabled = (coatchTraingingState && hasData);
            showInfoToolStripMenuItem.Enabled = (coatchTraingingState && hasData);
            updateSportToolStripMenuItem.Enabled = (coatchTraingingState && hasData);
            updateCoachToolStripMenuItem.Enabled = (coatchTraingingState && hasData);
        }

        private void addCoachTrainingToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            frmAddOrUpdateCoachTraining form = new frmAddOrUpdateCoachTraining();
            form.ShowDialog();
            _loadData();
        }

        private void updateCoachTrainingToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            int trianingCoachID = (int)dgvCoachTraining.CurrentRow.Cells[0].Value;
            frmAddOrUpdateCoachTraining form = new frmAddOrUpdateCoachTraining(trianingCoachID);
            form.ShowDialog();
            _loadData();
        }

        private void activeCoachTrainingToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            int trianingCoachID = (int)dgvCoachTraining.CurrentRow.Cells[0].Value;
            if (clsCoachTrainingBuisness.activateCoachTraining(trianingCoachID))
            {
                MessageBox.Show("the CoachTraining is Activiate Successfuly", "Done", MessageBoxButtons.OK);
                _loadData();

            }
            else
            {
                MessageBox.Show("Could Not Activate The CoatchTraining", "Done", MessageBoxButtons.OK);

            }
        }

        private void deActiveCoachTrainingToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            int trianingCoachID = (int)dgvCoachTraining.CurrentRow.Cells[0].Value;
            if (clsCoachTrainingBuisness.deActivateCoachTraining(trianingCoachID))
            {
                MessageBox.Show("the CoachTraining is deActivate Successfuly", "Done", MessageBoxButtons.OK);
                _loadData();

            }
            else
            {
                MessageBox.Show("Could Not DeActivate The CoatchTraining", "Done", MessageBoxButtons.OK);

            }
        }

        private void updateSportToolStripMenuItem_Click(object sender, System.EventArgs e)
        {

            int trianingCoachID = (int)dgvCoachTraining.CurrentRow.Cells[0].Value;
            int sportId = clsCoachTrainingBuisness.findCoachTrainingByID(trianingCoachID).sportID;
            frmAddOrUpdateSport form = new frmAddOrUpdateSport(sportId);
            form.ShowDialog();
            _loadData();

        }

        private void updateCoachToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            int trianingCoachID = (int)dgvCoachTraining.CurrentRow.Cells[0].Value;
            int coachId = clsCoachTrainingBuisness.findCoachTrainingByID(trianingCoachID).coachID;
            frmAddOrUpdateCoach form = new frmAddOrUpdateCoach(coachId);
            form.ShowDialog();
            _loadData();
        }

        private void showInfoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            int trianingCoachID = (int)dgvCoachTraining.CurrentRow.Cells[0].Value;
            frmShowCoachingTrainingInfo form = new frmShowCoachingTrainingInfo(trianingCoachID);
            form.ShowDialog();
        }

        private void deleteCoachTrainingToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            int trianingCoachID = (int)dgvCoachTraining.CurrentRow.Cells[0].Value;
            if (clsCoachTrainingBuisness.deleteCoachTrainginByID(trianingCoachID))
            {
                MessageBox.Show("the CoachTraining is delete Successfuly", "Done", MessageBoxButtons.OK);
                _loadData();

            }
            else
            {
                MessageBox.Show("Could Not deleted The CoatchTraining", "Done", MessageBoxButtons.OK);

            }
        }
    }
}
