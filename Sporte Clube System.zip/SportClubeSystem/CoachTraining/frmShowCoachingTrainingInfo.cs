﻿using SportCllubeBuisness;
using System.Windows.Forms;

namespace SportClubeSystem.CoachTraining
{
    public partial class frmShowCoachingTrainingInfo : Form
    {

        clsCoachTrainingBuisness cotchTraining;
        public frmShowCoachingTrainingInfo(int coachTraining)
        {
            InitializeComponent();
            _loadCoachData(coachTraining);
        }

        private void _loadCoachData(int coachTrainingID)
        {
            cotchTraining = clsCoachTrainingBuisness.findCoachTrainingByID(coachTrainingID);
            if (cotchTraining == null)
            {
                MessageBox.Show("coachTraining Not Found ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }
            ctrCoachTrainingCardInfo1.loadData(coachTrainingID);
        }


    }
}
