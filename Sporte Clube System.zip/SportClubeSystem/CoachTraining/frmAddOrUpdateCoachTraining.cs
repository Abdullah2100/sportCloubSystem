﻿using SportCllubeBuisness;
using SportClubeSystem.GenralClass;
using System;
using System.Data;
using System.Windows.Forms;

namespace SportClubeSystem.SportCoaches
{
    public partial class frmAddOrUpdateCoachTraining : Form
    {
        enum enMode { update, add }
        enMode _mode { get; set; }
        clsCoachTrainingBuisness _coachTraining;
        int _coachTrainingID = 0;
        int _traingingDay = 0;


        public frmAddOrUpdateCoachTraining()
        {
            InitializeComponent();
            _mode = enMode.add;
        }

        public frmAddOrUpdateCoachTraining(int coachTrainingId)
        {
            InitializeComponent();
            _mode = enMode.update;
            _coachTrainingID = coachTrainingId;
        }

        private void _traingingDayHandlerWhenIsUpdateData(int day = -1, bool isAll = false)
        {


            if (((day | 1) == day || isAll == true))
            {
                checSat.Checked = true;
            }

            if (((day | 2) == day || isAll == true))
            {
                checSun.Checked = true;
            }

            if (((day | 4) == day || isAll == true))
            {
                checMon.Checked = true;
            }
            if (((day | 8) == day || isAll == true))
            {
                checTus.Checked = true;
            }
            if (((day | 16) == day || isAll == true))
            {
                checWen.Checked = true;
            }
            if (((day | 32) == day || isAll == true))
            {
                checThir.Checked = true;
            }
            if (((day | 64) == day || isAll == true))
            {
                checFrid.Checked = true;
            }

            if (day == -1)
            {
                _traingingDayHandlerWhenIsUpdateData(-1, true);
                checAll.Checked = true;
                return;
            }

        }

        private void traingingDayHandlerWhenIsUpdateData(object sender, EventArgs e)
        {
            _traingingDay = 0;

            if (checAll.Checked)
            {
                _traingingDay = -1;
                return;
            }

            if (checSat.Checked)
            {
                _traingingDay = (_traingingDay | 1);
            }
            if (checSun.Checked)
            {
                _traingingDay = (_traingingDay | 2);
            }

            if (checMon.Checked)
            {
                _traingingDay = (_traingingDay | 4);
            }

            if (checTus.Checked)
            {
                _traingingDay = (_traingingDay | 8);
            }

            if (checWen.Checked)
            {
                _traingingDay = (_traingingDay | 16);
            }

            if (checThir.Checked)
            {
                _traingingDay = (_traingingDay | 32);
            }

            if (checFrid.Checked)
            {
                _traingingDay = (_traingingDay | 64);
            }




        }

        private void _fillSportsInCombobox()
        {
            DataTable sportList = clsSportBuisness.getAllActiveSportName();
            if (sportList.Rows.Count > 0)
            {
                foreach (DataRow row in sportList.Rows)
                {
                    cbbSports.Items.Add(row[0]);
                }
            }
        }

        private void _fileCoachesInCombobox()
        {
            DataTable coachetList = clsCoachBuisness.getAllActiveCoachsName();
            if (coachetList.Rows.Count > 0)
            {

                foreach (DataRow row in coachetList.Rows)
                {
                    cbbCoaches.Items.Add(row["fullName"]);
                }
            }
        }



        private void _reseatData()
        {
            _fileCoachesInCombobox();
            _fillSportsInCombobox();

            if (_mode == enMode.add)
            {
                lbHeaderTitle.Text = "Add New CoachTraiing";
                btnSave.Text = "Save";
                _coachTraining = new clsCoachTrainingBuisness();
            }
            else
            {
                lbHeaderTitle.Text = "Update CoachTraiing";
                btnSave.Text = "Update";

            }




            mtbStartAt.Text = "";
            mtbEndAt.Text = "";

            txtFee.Text = "";

            checSat.Checked = false;
            checSun.Checked = false;
            checMon.Checked = false;
            checTus.Checked = false;
            checWen.Checked = false;
            checThir.Checked = false;
            checFrid.Checked = false;
        }

        private void _loadData()
        {
            _coachTraining = clsCoachTrainingBuisness.findCoachTrainingByID(_coachTrainingID);

            if (_coachTraining == null)
            {

                MessageBox.Show("CoachTraining not Found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;

            }
            cbbSports.SelectedIndex = cbbSports.FindString(_coachTraining.sprotInfo.name);

            cbbCoaches.SelectedIndex = cbbCoaches.FindString(_coachTraining.coatchInfo.fullName);

            mtbStartAt.Text = _coachTraining.dayilyStartAt;

            mtbEndAt.Text = _coachTraining.dayilyEndAt;

            txtFee.Text = _coachTraining.fee.ToString();

            _traingingDayHandlerWhenIsUpdateData(_coachTraining.trainingDay);
        }

        private void frmAddOrUpdateCoachTraining_Load(object sender, System.EventArgs e)
        {
            _reseatData();
            if (_mode == enMode.update)
                _loadData();
        }

        private void _validationInput()
        {
            if (string.IsNullOrEmpty(cbbSports.Text))
            {
                errorProvider1.SetError(cbbSports, "لا بد من تحديد رياضه");
                return;
            }
            if (string.IsNullOrEmpty(cbbCoaches.Text))
            {
                errorProvider1.SetError(cbbCoaches, "لا بد من تحديد المدرب");
                return;
            }
            if (string.IsNullOrEmpty(mtbStartAt.Text))
            {
                errorProvider1.SetError(mtbStartAt, "لا بد من تحديد وقت اليومي لبداية التمرين");
                return;
            }

            if (string.IsNullOrEmpty(mtbEndAt.Text))
            {
                errorProvider1.SetError(mtbEndAt, "لا بد من تحديد  اليومي لنهاية التمرين");
                return;
            }

            if (string.IsNullOrEmpty(txtFee.Text))
            {
                errorProvider1.SetError(txtFee, "لا بد من تحديد سعر الاشتراك للتمرين");
                return;
            }

            if (_traingingDay == 0)
            {
                errorProvider1.SetError(gbTrainingDay, "لا بد من تحديد ايام التمرين");
                return;
            }
        }

        private void btnSave_Click(object sender, System.EventArgs e)
        {
            _validationInput();

            int coachID = clsCoachBuisness.findCoachByFullName(cbbCoaches.Text).id;
            int sportID = clsSportBuisness.findSport(cbbSports.Text).id;
            clsCoachTrainingBuisness coatchTraining = clsCoachTrainingBuisness.findCoachTrainingByCoachID(coachID);

            if (coatchTraining.sportID == sportID && coatchTraining.coachID == coachID)
            {
                MessageBox.Show("coach is already has training this sport", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }



            _coachTraining.coachID = coachID;
            _coachTraining.sportID = sportID;
            _coachTraining.dayilyStartAt = mtbStartAt.Text;
            _coachTraining.dayilyEndAt = mtbEndAt.Text;
            _coachTraining.fee = Convert.ToDecimal(txtFee.Text);
            _coachTraining.trainingDay = _traingingDay;
            _coachTraining.addBy = clsEmployee.employee.id;

            if (_coachTraining.save())
            {
                btnSave.Text = "Update";
                MessageBox.Show("data Saving Seccsfuly", "Done", MessageBoxButtons.OK);
                return;
            }
            else
            {
                MessageBox.Show("CoachTraining not Found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

        }

        private void txtFee_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void checThir_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }
    }
}
