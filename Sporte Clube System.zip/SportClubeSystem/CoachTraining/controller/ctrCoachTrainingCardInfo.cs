﻿using SportCllubeBuisness;
using System.Windows.Forms;

namespace SportClubeSystem.CoachTraining.controller
{
    public partial class ctrCoachTrainingCardInfo : UserControl
    {
        clsCoachTrainingBuisness coachTraingin;

        public ctrCoachTrainingCardInfo()
        {
            InitializeComponent();
        }

        private void _traingingDayHandlerWhenIsUpdateData(int day = -1, bool isAll = false)
        {


            if (((day | 1) == day || isAll == true))
            {
                checSat.Checked = true;
            }

            if (((day | 2) == day || isAll == true))
            {
                checSun.Checked = true;
            }

            if (((day | 4) == day || isAll == true))
            {
                checMon.Checked = true;
            }
            if (((day | 8) == day || isAll == true))
            {
                checTus.Checked = true;
            }
            if (((day | 16) == day || isAll == true))
            {
                checWen.Checked = true;
            }
            if (((day | 32) == day || isAll == true))
            {
                checThir.Checked = true;
            }
            if (((day | 64) == day || isAll == true))
            {
                checFrid.Checked = true;
            }

            if (day == -1)
            {
                _traingingDayHandlerWhenIsUpdateData(-1, true);
                checAll.Checked = true;
                return;
            }

        }


        public void loadData(int id)
        {
            coachTraingin = clsCoachTrainingBuisness.findCoachTrainingByID(id);

            if (coachTraingin == null)
            {
                MessageBox.Show("This Trainging is not Found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return;
            }

            lbCoachname.Text = coachTraingin.coatchInfo.fullName;
            lbSportName.Text = coachTraingin.sprotInfo.name;
            lbStartAt.Text = coachTraingin.dayilyStartAt.ToString();
            lbEndAt.Text = coachTraingin.dayilyEndAt.ToString();
            lbFee.Text = coachTraingin.fee.ToString();
            _traingingDayHandlerWhenIsUpdateData(coachTraingin.trainingDay);
            ctrPersonCard1.loadData(coachTraingin.coatchInfo.personID);

        }


    }
}
