﻿namespace SportClubeSystem.CoachTraining.controller
{
    partial class ctrCoachTrainingCardInfo
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lbEndAt = new System.Windows.Forms.Label();
            this.lbFee = new System.Windows.Forms.Label();
            this.lbStartAt = new System.Windows.Forms.Label();
            this.lbSportName = new System.Windows.Forms.Label();
            this.lbCoachname = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checAll = new System.Windows.Forms.CheckBox();
            this.checFrid = new System.Windows.Forms.CheckBox();
            this.checThir = new System.Windows.Forms.CheckBox();
            this.checWen = new System.Windows.Forms.CheckBox();
            this.checTus = new System.Windows.Forms.CheckBox();
            this.checMon = new System.Windows.Forms.CheckBox();
            this.checSun = new System.Windows.Forms.CheckBox();
            this.checSat = new System.Windows.Forms.CheckBox();
            this.ctrPersonCard1 = new SportClubeSystem.People.ctrPersonCard();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lbEndAt);
            this.groupBox3.Controls.Add(this.lbFee);
            this.groupBox3.Controls.Add(this.lbStartAt);
            this.groupBox3.Controls.Add(this.lbSportName);
            this.groupBox3.Controls.Add(this.lbCoachname);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Location = new System.Drawing.Point(17, 315);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(453, 206);
            this.groupBox3.TabIndex = 41;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Traingin Info";
            // 
            // lbEndAt
            // 
            this.lbEndAt.AutoSize = true;
            this.lbEndAt.Location = new System.Drawing.Point(140, 136);
            this.lbEndAt.Name = "lbEndAt";
            this.lbEndAt.Size = new System.Drawing.Size(50, 16);
            this.lbEndAt.TabIndex = 49;
            this.lbEndAt.Text = "[?????]";
            // 
            // lbFee
            // 
            this.lbFee.AutoSize = true;
            this.lbFee.Location = new System.Drawing.Point(140, 169);
            this.lbFee.Name = "lbFee";
            this.lbFee.Size = new System.Drawing.Size(50, 16);
            this.lbFee.TabIndex = 48;
            this.lbFee.Text = "[?????]";
            // 
            // lbStartAt
            // 
            this.lbStartAt.AutoSize = true;
            this.lbStartAt.Location = new System.Drawing.Point(140, 101);
            this.lbStartAt.Name = "lbStartAt";
            this.lbStartAt.Size = new System.Drawing.Size(50, 16);
            this.lbStartAt.TabIndex = 47;
            this.lbStartAt.Text = "[?????]";
            // 
            // lbSportName
            // 
            this.lbSportName.AutoSize = true;
            this.lbSportName.Location = new System.Drawing.Point(140, 68);
            this.lbSportName.Name = "lbSportName";
            this.lbSportName.Size = new System.Drawing.Size(50, 16);
            this.lbSportName.TabIndex = 46;
            this.lbSportName.Text = "[?????]";
            // 
            // lbCoachname
            // 
            this.lbCoachname.AutoSize = true;
            this.lbCoachname.Location = new System.Drawing.Point(140, 35);
            this.lbCoachname.Name = "lbCoachname";
            this.lbCoachname.Size = new System.Drawing.Size(50, 16);
            this.lbCoachname.TabIndex = 45;
            this.lbCoachname.Text = "[?????]";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(68, 68);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 16);
            this.label7.TabIndex = 44;
            this.label7.Text = "Sports :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(83, 169);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 16);
            this.label6.TabIndex = 43;
            this.label6.Text = "Fee :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(68, 136);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 16);
            this.label5.TabIndex = 42;
            this.label5.Text = "End At :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(62, 101);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 16);
            this.label1.TabIndex = 41;
            this.label1.Text = "Start At  :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(47, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 16);
            this.label2.TabIndex = 40;
            this.label2.Text = "CoacheID :";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checAll);
            this.groupBox1.Controls.Add(this.checFrid);
            this.groupBox1.Controls.Add(this.checThir);
            this.groupBox1.Controls.Add(this.checWen);
            this.groupBox1.Controls.Add(this.checTus);
            this.groupBox1.Controls.Add(this.checMon);
            this.groupBox1.Controls.Add(this.checSun);
            this.groupBox1.Controls.Add(this.checSat);
            this.groupBox1.Location = new System.Drawing.Point(476, 312);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(408, 209);
            this.groupBox1.TabIndex = 40;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Trainging Dayes ";
            // 
            // checAll
            // 
            this.checAll.AutoSize = true;
            this.checAll.Enabled = false;
            this.checAll.Location = new System.Drawing.Point(224, 74);
            this.checAll.Name = "checAll";
            this.checAll.Size = new System.Drawing.Size(44, 20);
            this.checAll.TabIndex = 21;
            this.checAll.Text = "All";
            this.checAll.UseVisualStyleBackColor = true;
            // 
            // checFrid
            // 
            this.checFrid.AutoSize = true;
            this.checFrid.Enabled = false;
            this.checFrid.Location = new System.Drawing.Point(50, 109);
            this.checFrid.Name = "checFrid";
            this.checFrid.Size = new System.Drawing.Size(67, 20);
            this.checFrid.TabIndex = 20;
            this.checFrid.Text = "Friday";
            this.checFrid.UseVisualStyleBackColor = true;
            // 
            // checThir
            // 
            this.checThir.AutoSize = true;
            this.checThir.Enabled = false;
            this.checThir.Location = new System.Drawing.Point(224, 39);
            this.checThir.Name = "checThir";
            this.checThir.Size = new System.Drawing.Size(82, 20);
            this.checThir.TabIndex = 19;
            this.checThir.Text = "Thrisday";
            this.checThir.UseVisualStyleBackColor = true;
            // 
            // checWen
            // 
            this.checWen.AutoSize = true;
            this.checWen.Enabled = false;
            this.checWen.Location = new System.Drawing.Point(50, 176);
            this.checWen.Name = "checWen";
            this.checWen.Size = new System.Drawing.Size(90, 20);
            this.checWen.TabIndex = 18;
            this.checWen.Text = "Wenisday";
            this.checWen.UseVisualStyleBackColor = true;
            // 
            // checTus
            // 
            this.checTus.AutoSize = true;
            this.checTus.Enabled = false;
            this.checTus.Location = new System.Drawing.Point(50, 74);
            this.checTus.Name = "checTus";
            this.checTus.Size = new System.Drawing.Size(83, 20);
            this.checTus.TabIndex = 17;
            this.checTus.Text = "Tuseday";
            this.checTus.UseVisualStyleBackColor = true;
            // 
            // checMon
            // 
            this.checMon.AutoSize = true;
            this.checMon.Enabled = false;
            this.checMon.Location = new System.Drawing.Point(22, 255);
            this.checMon.Name = "checMon";
            this.checMon.Size = new System.Drawing.Size(78, 20);
            this.checMon.TabIndex = 16;
            this.checMon.Text = "Monday";
            this.checMon.UseVisualStyleBackColor = true;
            // 
            // checSun
            // 
            this.checSun.AutoSize = true;
            this.checSun.Enabled = false;
            this.checSun.Location = new System.Drawing.Point(50, 144);
            this.checSun.Name = "checSun";
            this.checSun.Size = new System.Drawing.Size(75, 20);
            this.checSun.TabIndex = 15;
            this.checSun.Text = "Sunday";
            this.checSun.UseVisualStyleBackColor = true;
            // 
            // checSat
            // 
            this.checSat.AutoSize = true;
            this.checSat.Enabled = false;
            this.checSat.Location = new System.Drawing.Point(50, 39);
            this.checSat.Name = "checSat";
            this.checSat.Size = new System.Drawing.Size(83, 20);
            this.checSat.TabIndex = 14;
            this.checSat.Text = "Saturday";
            this.checSat.UseVisualStyleBackColor = true;
            // 
            // ctrPersonCard1
            // 
            this.ctrPersonCard1.BackColor = System.Drawing.Color.White;
            this.ctrPersonCard1.Location = new System.Drawing.Point(7, -7);
            this.ctrPersonCard1.Name = "ctrPersonCard1";
            this.ctrPersonCard1.Size = new System.Drawing.Size(888, 321);
            this.ctrPersonCard1.TabIndex = 42;
            // 
            // ctrCoachTrainingCardInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ctrPersonCard1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Name = "ctrCoachTrainingCardInfo";
            this.Size = new System.Drawing.Size(898, 530);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lbEndAt;
        private System.Windows.Forms.Label lbFee;
        private System.Windows.Forms.Label lbStartAt;
        private System.Windows.Forms.Label lbSportName;
        private System.Windows.Forms.Label lbCoachname;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checAll;
        private System.Windows.Forms.CheckBox checFrid;
        private System.Windows.Forms.CheckBox checThir;
        private System.Windows.Forms.CheckBox checWen;
        private System.Windows.Forms.CheckBox checTus;
        private System.Windows.Forms.CheckBox checMon;
        private System.Windows.Forms.CheckBox checSun;
        private System.Windows.Forms.CheckBox checSat;
        private People.ctrPersonCard ctrPersonCard1;
    }
}
