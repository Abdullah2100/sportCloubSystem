﻿namespace SportClubeSystem.CoachTraining
{
    partial class frmShowCoachingTrainingInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.ctrCoachTrainingCardInfo1 = new SportClubeSystem.CoachTraining.controller.ctrCoachTrainingCardInfo();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 17.8F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(303, 41);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(303, 36);
            this.label4.TabIndex = 21;
            this.label4.Text = "CoacheTraining Info";
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.button1.Location = new System.Drawing.Point(739, 634);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(164, 65);
            this.button1.TabIndex = 42;
            this.button1.Text = "Close";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // ctrCoachTrainingCardInfo1
            // 
            this.ctrCoachTrainingCardInfo1.BackColor = System.Drawing.Color.White;
            this.ctrCoachTrainingCardInfo1.Location = new System.Drawing.Point(17, 98);
            this.ctrCoachTrainingCardInfo1.Name = "ctrCoachTrainingCardInfo1";
            this.ctrCoachTrainingCardInfo1.Size = new System.Drawing.Size(898, 530);
            this.ctrCoachTrainingCardInfo1.TabIndex = 43;
            // 
            // frmShowCoachingTrainingInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(941, 716);
            this.Controls.Add(this.ctrCoachTrainingCardInfo1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label4);
            this.Name = "frmShowCoachingTrainingInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmShowCoachingTrainingInfo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private controller.ctrCoachTrainingCardInfo ctrCoachTrainingCardInfo1;
    }
}