﻿namespace SportClubeSystem.SportCoaches
{
    partial class frmCoachTrainingList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.lbListSize = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.dgvCoachTraining = new System.Windows.Forms.DataGridView();
            this.cmsCoachTraing = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.addCoachTrainingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateCoachTrainingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteCoachTrainingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.activeCoachTrainingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deActiveCoachTrainingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateSportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateCoachToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txtFilterHolder = new System.Windows.Forms.TextBox();
            this.cbFilter = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbpIsAvalialbe = new System.Windows.Forms.ComboBox();
            this.showInfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCoachTraining)).BeginInit();
            this.cmsCoachTraing.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SportClubeSystem.Properties.Resources.sportCoaches;
            this.pictureBox1.Location = new System.Drawing.Point(564, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(292, 261);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 17.8F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(541, 300);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(337, 36);
            this.label1.TabIndex = 2;
            this.label1.Text = "Sport Coaches System";
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(1188, 674);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(159, 49);
            this.btnClose.TabIndex = 15;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            // 
            // lbListSize
            // 
            this.lbListSize.AutoSize = true;
            this.lbListSize.Location = new System.Drawing.Point(165, 690);
            this.lbListSize.Name = "lbListSize";
            this.lbListSize.Size = new System.Drawing.Size(14, 16);
            this.lbListSize.TabIndex = 14;
            this.lbListSize.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(94, 690);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 16);
            this.label5.TabIndex = 13;
            this.label5.Text = "Recourd :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(74, 690);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(14, 16);
            this.label2.TabIndex = 12;
            this.label2.Text = "#";
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.White;
            this.btnAdd.Image = global::SportClubeSystem.Properties.Resources.add;
            this.btnAdd.Location = new System.Drawing.Point(1283, 388);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(64, 47);
            this.btnAdd.TabIndex = 11;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // dgvCoachTraining
            // 
            this.dgvCoachTraining.BackgroundColor = System.Drawing.Color.White;
            this.dgvCoachTraining.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCoachTraining.ContextMenuStrip = this.cmsCoachTraing;
            this.dgvCoachTraining.Location = new System.Drawing.Point(53, 453);
            this.dgvCoachTraining.Name = "dgvCoachTraining";
            this.dgvCoachTraining.RowHeadersWidth = 51;
            this.dgvCoachTraining.RowTemplate.Height = 24;
            this.dgvCoachTraining.Size = new System.Drawing.Size(1294, 217);
            this.dgvCoachTraining.TabIndex = 10;
            // 
            // cmsCoachTraing
            // 
            this.cmsCoachTraing.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.cmsCoachTraing.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addCoachTrainingToolStripMenuItem,
            this.updateCoachTrainingToolStripMenuItem,
            this.deleteCoachTrainingToolStripMenuItem,
            this.activeCoachTrainingToolStripMenuItem,
            this.deActiveCoachTrainingToolStripMenuItem,
            this.updateSportToolStripMenuItem,
            this.updateCoachToolStripMenuItem,
            this.showInfoToolStripMenuItem});
            this.cmsCoachTraing.Name = "contextMenuStrip2";
            this.cmsCoachTraing.Size = new System.Drawing.Size(241, 224);
            this.cmsCoachTraing.Opening += new System.ComponentModel.CancelEventHandler(this.cmsCoachTraing_Opening);
            // 
            // addCoachTrainingToolStripMenuItem
            // 
            this.addCoachTrainingToolStripMenuItem.Name = "addCoachTrainingToolStripMenuItem";
            this.addCoachTrainingToolStripMenuItem.Size = new System.Drawing.Size(240, 24);
            this.addCoachTrainingToolStripMenuItem.Text = "Add CoachTraining";
            this.addCoachTrainingToolStripMenuItem.Click += new System.EventHandler(this.addCoachTrainingToolStripMenuItem_Click);
            // 
            // updateCoachTrainingToolStripMenuItem
            // 
            this.updateCoachTrainingToolStripMenuItem.Name = "updateCoachTrainingToolStripMenuItem";
            this.updateCoachTrainingToolStripMenuItem.Size = new System.Drawing.Size(240, 24);
            this.updateCoachTrainingToolStripMenuItem.Text = "Update Coach Training";
            this.updateCoachTrainingToolStripMenuItem.Click += new System.EventHandler(this.updateCoachTrainingToolStripMenuItem_Click);
            // 
            // deleteCoachTrainingToolStripMenuItem
            // 
            this.deleteCoachTrainingToolStripMenuItem.Name = "deleteCoachTrainingToolStripMenuItem";
            this.deleteCoachTrainingToolStripMenuItem.Size = new System.Drawing.Size(240, 24);
            this.deleteCoachTrainingToolStripMenuItem.Text = "Delete Coach Training";
            this.deleteCoachTrainingToolStripMenuItem.Click += new System.EventHandler(this.deleteCoachTrainingToolStripMenuItem_Click);
            // 
            // activeCoachTrainingToolStripMenuItem
            // 
            this.activeCoachTrainingToolStripMenuItem.Name = "activeCoachTrainingToolStripMenuItem";
            this.activeCoachTrainingToolStripMenuItem.Size = new System.Drawing.Size(240, 24);
            this.activeCoachTrainingToolStripMenuItem.Text = "Active Coach Training";
            this.activeCoachTrainingToolStripMenuItem.Click += new System.EventHandler(this.activeCoachTrainingToolStripMenuItem_Click);
            // 
            // deActiveCoachTrainingToolStripMenuItem
            // 
            this.deActiveCoachTrainingToolStripMenuItem.Name = "deActiveCoachTrainingToolStripMenuItem";
            this.deActiveCoachTrainingToolStripMenuItem.Size = new System.Drawing.Size(240, 24);
            this.deActiveCoachTrainingToolStripMenuItem.Text = "DeActive Coach Training";
            this.deActiveCoachTrainingToolStripMenuItem.Click += new System.EventHandler(this.deActiveCoachTrainingToolStripMenuItem_Click);
            // 
            // updateSportToolStripMenuItem
            // 
            this.updateSportToolStripMenuItem.Name = "updateSportToolStripMenuItem";
            this.updateSportToolStripMenuItem.Size = new System.Drawing.Size(240, 24);
            this.updateSportToolStripMenuItem.Text = "UpdateSport";
            this.updateSportToolStripMenuItem.Click += new System.EventHandler(this.updateSportToolStripMenuItem_Click);
            // 
            // updateCoachToolStripMenuItem
            // 
            this.updateCoachToolStripMenuItem.Name = "updateCoachToolStripMenuItem";
            this.updateCoachToolStripMenuItem.Size = new System.Drawing.Size(240, 24);
            this.updateCoachToolStripMenuItem.Text = "UpdateCoach";
            this.updateCoachToolStripMenuItem.Click += new System.EventHandler(this.updateCoachToolStripMenuItem_Click);
            // 
            // txtFilterHolder
            // 
            this.txtFilterHolder.Location = new System.Drawing.Point(290, 411);
            this.txtFilterHolder.Name = "txtFilterHolder";
            this.txtFilterHolder.Size = new System.Drawing.Size(188, 22);
            this.txtFilterHolder.TabIndex = 18;
            this.txtFilterHolder.TextChanged += new System.EventHandler(this.txtFilterHolder_TextChanged);
            this.txtFilterHolder.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFilterHolder_KeyPress);
            // 
            // cbFilter
            // 
            this.cbFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbFilter.FormattingEnabled = true;
            this.cbFilter.Items.AddRange(new object[] {
            "none",
            "Coachs Trainging ID",
            "FullName",
            "is Training Avalidable",
            "Sport Name",
            "Start At",
            "End At",
            "Cost"});
            this.cbFilter.Location = new System.Drawing.Point(121, 411);
            this.cbFilter.Name = "cbFilter";
            this.cbFilter.Size = new System.Drawing.Size(154, 24);
            this.cbFilter.TabIndex = 16;
            this.cbFilter.SelectedIndexChanged += new System.EventHandler(this.cbFilter_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.label3.Location = new System.Drawing.Point(52, 412);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 22);
            this.label3.TabIndex = 17;
            this.label3.Text = "Filter :";
            // 
            // cbpIsAvalialbe
            // 
            this.cbpIsAvalialbe.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbpIsAvalialbe.FormattingEnabled = true;
            this.cbpIsAvalialbe.Items.AddRange(new object[] {
            "All",
            "Yes",
            "No"});
            this.cbpIsAvalialbe.Location = new System.Drawing.Point(290, 411);
            this.cbpIsAvalialbe.Name = "cbpIsAvalialbe";
            this.cbpIsAvalialbe.Size = new System.Drawing.Size(104, 24);
            this.cbpIsAvalialbe.TabIndex = 19;
            this.cbpIsAvalialbe.Visible = false;
            this.cbpIsAvalialbe.SelectedIndexChanged += new System.EventHandler(this.cbpIsAvalialbe_SelectedIndexChanged);
            // 
            // showInfoToolStripMenuItem
            // 
            this.showInfoToolStripMenuItem.Name = "showInfoToolStripMenuItem";
            this.showInfoToolStripMenuItem.Size = new System.Drawing.Size(240, 24);
            this.showInfoToolStripMenuItem.Text = "Show Info";
            this.showInfoToolStripMenuItem.Click += new System.EventHandler(this.showInfoToolStripMenuItem_Click);
            // 
            // frmCoachTrainingList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1379, 737);
            this.Controls.Add(this.cbpIsAvalialbe);
            this.Controls.Add(this.txtFilterHolder);
            this.Controls.Add(this.cbFilter);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lbListSize);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.dgvCoachTraining);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "frmCoachTrainingList";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmSpotCoachesList";
            this.Load += new System.EventHandler(this.frmSpotCoachesList_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCoachTraining)).EndInit();
            this.cmsCoachTraing.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lbListSize;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DataGridView dgvCoachTraining;
        private System.Windows.Forms.TextBox txtFilterHolder;
        private System.Windows.Forms.ComboBox cbFilter;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbpIsAvalialbe;
        private System.Windows.Forms.ContextMenuStrip cmsCoachTraing;
        private System.Windows.Forms.ToolStripMenuItem addCoachTrainingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateCoachTrainingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteCoachTrainingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem activeCoachTrainingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deActiveCoachTrainingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateSportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateCoachToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showInfoToolStripMenuItem;
    }
}