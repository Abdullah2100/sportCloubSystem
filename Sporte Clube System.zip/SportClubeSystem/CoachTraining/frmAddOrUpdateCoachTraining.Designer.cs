﻿namespace SportClubeSystem.SportCoaches
{
    partial class frmAddOrUpdateCoachTraining
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbHeaderTitle = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.gbTrainingDay = new System.Windows.Forms.GroupBox();
            this.checAll = new System.Windows.Forms.CheckBox();
            this.checFrid = new System.Windows.Forms.CheckBox();
            this.checThir = new System.Windows.Forms.CheckBox();
            this.checWen = new System.Windows.Forms.CheckBox();
            this.checTus = new System.Windows.Forms.CheckBox();
            this.checMon = new System.Windows.Forms.CheckBox();
            this.checSun = new System.Windows.Forms.CheckBox();
            this.checSat = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cbbCoaches = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.mtbEndAt = new System.Windows.Forms.MaskedTextBox();
            this.mtbStartAt = new System.Windows.Forms.MaskedTextBox();
            this.txtFee = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbbSports = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.gbTrainingDay.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbHeaderTitle
            // 
            this.lbHeaderTitle.AutoSize = true;
            this.lbHeaderTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHeaderTitle.ForeColor = System.Drawing.Color.Red;
            this.lbHeaderTitle.Location = new System.Drawing.Point(52, 23);
            this.lbHeaderTitle.Name = "lbHeaderTitle";
            this.lbHeaderTitle.Size = new System.Drawing.Size(550, 54);
            this.lbHeaderTitle.TabIndex = 9;
            this.lbHeaderTitle.Text = "Add New CoachTraining";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 33;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.White;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.btnSave.Location = new System.Drawing.Point(396, 595);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(138, 66);
            this.btnSave.TabIndex = 15;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.White;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.btnClose.Location = new System.Drawing.Point(237, 595);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(138, 66);
            this.btnClose.TabIndex = 14;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // gbTrainingDay
            // 
            this.gbTrainingDay.Controls.Add(this.checAll);
            this.gbTrainingDay.Controls.Add(this.checFrid);
            this.gbTrainingDay.Controls.Add(this.checThir);
            this.gbTrainingDay.Controls.Add(this.checWen);
            this.gbTrainingDay.Controls.Add(this.checTus);
            this.gbTrainingDay.Controls.Add(this.checMon);
            this.gbTrainingDay.Controls.Add(this.checSun);
            this.gbTrainingDay.Controls.Add(this.checSat);
            this.gbTrainingDay.Location = new System.Drawing.Point(106, 412);
            this.gbTrainingDay.Name = "gbTrainingDay";
            this.gbTrainingDay.Size = new System.Drawing.Size(428, 164);
            this.gbTrainingDay.TabIndex = 36;
            this.gbTrainingDay.TabStop = false;
            this.gbTrainingDay.Text = "Trainging Dayes ";
            this.gbTrainingDay.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // checAll
            // 
            this.checAll.AutoSize = true;
            this.checAll.Location = new System.Drawing.Point(136, 125);
            this.checAll.Name = "checAll";
            this.checAll.Size = new System.Drawing.Size(44, 20);
            this.checAll.TabIndex = 21;
            this.checAll.Text = "All";
            this.checAll.UseVisualStyleBackColor = true;
            // 
            // checFrid
            // 
            this.checFrid.AutoSize = true;
            this.checFrid.Location = new System.Drawing.Point(22, 125);
            this.checFrid.Name = "checFrid";
            this.checFrid.Size = new System.Drawing.Size(67, 20);
            this.checFrid.TabIndex = 20;
            this.checFrid.Text = "Friday";
            this.checFrid.UseVisualStyleBackColor = true;
            // 
            // checThir
            // 
            this.checThir.AutoSize = true;
            this.checThir.Location = new System.Drawing.Point(231, 87);
            this.checThir.Name = "checThir";
            this.checThir.Size = new System.Drawing.Size(82, 20);
            this.checThir.TabIndex = 19;
            this.checThir.Text = "Thrisday";
            this.checThir.UseVisualStyleBackColor = true;
            // 
            // checWen
            // 
            this.checWen.AutoSize = true;
            this.checWen.Location = new System.Drawing.Point(136, 87);
            this.checWen.Name = "checWen";
            this.checWen.Size = new System.Drawing.Size(90, 20);
            this.checWen.TabIndex = 18;
            this.checWen.Text = "Wenisday";
            this.checWen.UseVisualStyleBackColor = true;
            // 
            // checTus
            // 
            this.checTus.AutoSize = true;
            this.checTus.Location = new System.Drawing.Point(22, 87);
            this.checTus.Name = "checTus";
            this.checTus.Size = new System.Drawing.Size(83, 20);
            this.checTus.TabIndex = 17;
            this.checTus.Text = "Tuseday";
            this.checTus.UseVisualStyleBackColor = true;
            // 
            // checMon
            // 
            this.checMon.AutoSize = true;
            this.checMon.Location = new System.Drawing.Point(231, 45);
            this.checMon.Name = "checMon";
            this.checMon.Size = new System.Drawing.Size(78, 20);
            this.checMon.TabIndex = 16;
            this.checMon.Text = "Monday";
            this.checMon.UseVisualStyleBackColor = true;
            // 
            // checSun
            // 
            this.checSun.AutoSize = true;
            this.checSun.Location = new System.Drawing.Point(136, 45);
            this.checSun.Name = "checSun";
            this.checSun.Size = new System.Drawing.Size(75, 20);
            this.checSun.TabIndex = 15;
            this.checSun.Text = "Sunday";
            this.checSun.UseVisualStyleBackColor = true;
            // 
            // checSat
            // 
            this.checSat.AutoSize = true;
            this.checSat.Location = new System.Drawing.Point(22, 45);
            this.checSat.Name = "checSat";
            this.checSat.Size = new System.Drawing.Size(83, 20);
            this.checSat.TabIndex = 14;
            this.checSat.Text = "Saturday";
            this.checSat.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cbbCoaches);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.mtbEndAt);
            this.groupBox3.Controls.Add(this.mtbStartAt);
            this.groupBox3.Controls.Add(this.txtFee);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.cbbSports);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Location = new System.Drawing.Point(106, 102);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(428, 300);
            this.groupBox3.TabIndex = 37;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Traingin Info";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // cbbCoaches
            // 
            this.cbbCoaches.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbCoaches.FormattingEnabled = true;
            this.cbbCoaches.Location = new System.Drawing.Point(109, 34);
            this.cbbCoaches.Name = "cbbCoaches";
            this.cbbCoaches.Size = new System.Drawing.Size(178, 24);
            this.cbbCoaches.TabIndex = 45;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(34, 96);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 16);
            this.label7.TabIndex = 44;
            this.label7.Text = "Sports :";
            // 
            // mtbEndAt
            // 
            this.mtbEndAt.Location = new System.Drawing.Point(109, 213);
            this.mtbEndAt.Mask = "00:00";
            this.mtbEndAt.Name = "mtbEndAt";
            this.mtbEndAt.Size = new System.Drawing.Size(48, 22);
            this.mtbEndAt.TabIndex = 38;
            this.mtbEndAt.ValidatingType = typeof(System.DateTime);
            // 
            // mtbStartAt
            // 
            this.mtbStartAt.Location = new System.Drawing.Point(109, 155);
            this.mtbStartAt.Mask = "00:00";
            this.mtbStartAt.Name = "mtbStartAt";
            this.mtbStartAt.Size = new System.Drawing.Size(48, 22);
            this.mtbStartAt.TabIndex = 37;
            this.mtbStartAt.ValidatingType = typeof(System.DateTime);
            // 
            // txtFee
            // 
            this.txtFee.Location = new System.Drawing.Point(109, 268);
            this.txtFee.Name = "txtFee";
            this.txtFee.Size = new System.Drawing.Size(118, 22);
            this.txtFee.TabIndex = 39;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(49, 268);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 16);
            this.label6.TabIndex = 43;
            this.label6.Text = "Fee :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 219);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 16);
            this.label5.TabIndex = 42;
            this.label5.Text = "End At :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(28, 158);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 16);
            this.label4.TabIndex = 41;
            this.label4.Text = "Start At  :";
            // 
            // cbbSports
            // 
            this.cbbSports.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbSports.FormattingEnabled = true;
            this.cbbSports.Location = new System.Drawing.Point(109, 96);
            this.cbbSports.Name = "cbbSports";
            this.cbbSports.Size = new System.Drawing.Size(178, 24);
            this.cbbSports.TabIndex = 36;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 16);
            this.label1.TabIndex = 40;
            this.label1.Text = "Coaches :";
            // 
            // frmAddOrUpdateCoachTraining
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(651, 680);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.gbTrainingDay);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbHeaderTitle);
            this.Name = "frmAddOrUpdateCoachTraining";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.frmAddOrUpdateCoachTraining_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.gbTrainingDay.ResumeLayout(false);
            this.gbTrainingDay.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbHeaderTitle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox cbbCoaches;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.MaskedTextBox mtbEndAt;
        private System.Windows.Forms.MaskedTextBox mtbStartAt;
        private System.Windows.Forms.TextBox txtFee;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbbSports;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gbTrainingDay;
        private System.Windows.Forms.CheckBox checAll;
        private System.Windows.Forms.CheckBox checFrid;
        private System.Windows.Forms.CheckBox checThir;
        private System.Windows.Forms.CheckBox checWen;
        private System.Windows.Forms.CheckBox checTus;
        private System.Windows.Forms.CheckBox checMon;
        private System.Windows.Forms.CheckBox checSun;
        private System.Windows.Forms.CheckBox checSat;
    }
}