﻿using SportCllubeBuisness;
using System;
using System.Data;
using System.Windows.Forms;

namespace SportClubeSystem.Employee
{
    public partial class frmListEmployee : Form
    {
        DataTable dtEmployee = new DataTable();
        public frmListEmployee()
        {
            InitializeComponent();
        }

        private void _load()
        {
            dtEmployee = clsEmployeeBuisness.getallEmployee();

            dgvEmployees.DataSource = dtEmployee;

            if (dtEmployee.Rows.Count > 0)
            {
                dgvEmployees.Columns[0].HeaderText = "Employee ID";
                dgvEmployees.Columns[0].Width = 60;

                dgvEmployees.Columns[1].HeaderText = "Person ID";
                //dgvEmployees.Columns[1].Width = 60;

                dgvEmployees.Columns[2].HeaderText = "UserName";
                //dgvEmployees.Columns[2].Width = 250;

                dgvEmployees.Columns[3].HeaderText = "Created Date";
                //dgvEmployees.Columns[3].Width = 120;

                dgvEmployees.Columns[4].HeaderText = "FullName";
                //dgvEmployees.Columns[4].Width = 250;

                dgvEmployees.Columns[5].HeaderText = "Gender";
                //dgvEmployees.Columns[5].Width = 60;

                dgvEmployees.Columns[6].HeaderText = "Brithday";
                //dgvEmployees.Columns[6].Width = 100;

                dgvEmployees.Columns[7].HeaderText = "Nationality";
                //dgvEmployees.Columns[7].Width = 90;

                dgvEmployees.Columns[8].HeaderText = "Phone";
                //dgvEmployees.Columns[8].Width = 100;

                dgvEmployees.Columns[9].HeaderText = "Is Active";
                // dgvEmployees.Columns[0].Width = 50;

            }



            cbFilter.SelectedIndex = 0;
            lbListSize.Text = dtEmployee.Rows.Count.ToString();
        }

        private void frmListEmployee_Load(object sender, EventArgs e)
        {
            _load();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

            frmAddOrUpdateEmployee form = new frmAddOrUpdateEmployee();
            form.ShowDialog();
            _load();
        }

        private void addEmplyeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAddOrUpdateEmployee form = new frmAddOrUpdateEmployee();
            form.ShowDialog();
            _load();
        }

        private void updateEmpoyeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int emplyeeID = (int)dgvEmployees.CurrentRow.Cells[0].Value;
            frmAddOrUpdateEmployee form = new frmAddOrUpdateEmployee(emplyeeID);
            form.ShowDialog();
            _load();
        }

        private void contextMenuStrip1_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {


            int emplyeeID = dgvEmployees.Rows.Count > 0 ? (int)dgvEmployees.CurrentRow.Cells[0].Value : 0;

            bool isActive = emplyeeID == 0 ? false : clsEmployeeBuisness.isEmployeeActive(emplyeeID);
            bool isHasData = dgvEmployees.Rows.Count > 0;
            updateEmpoyeeToolStripMenuItem.Enabled = isHasData;
            activateEmployeeToolStripMenuItem.Enabled = (!isActive && isHasData == true);
            deActivateEmployeeToolStripMenuItem.Enabled = (isActive && isHasData == true);
            deleteEmployeeToolStripMenuItem.Enabled = isHasData;
            updatePasswordToolStripMenuItem.Enabled = isHasData;
            showInfoToolStripMenuItem.Enabled = (isActive && isHasData == true);
        }

        private void cbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtFilterHolder.Text = " ";
            if (cbFilter.SelectedIndex == 0)
            {

                txtFilterHolder.Enabled = false;
                cbStateFilter.Visible = false;
            }
            else
            {

                txtFilterHolder.Visible = (cbFilter.SelectedIndex != 10);
                txtFilterHolder.Enabled = (cbFilter.SelectedIndex != 10);
                cbStateFilter.Visible = (cbFilter.SelectedIndex == 10);

            }
        }

        private void txtFilterHolder_TextChanged(object sender, EventArgs e)
        {
            string columnName = "";

            switch (cbFilter.Text)
            {
                case "Employee ID":
                    {
                        columnName = "employeeID";
                    }
                    break;

                case "Person ID":
                    {
                        columnName = "personID";
                    }
                    break;
                    ;

                case "UserName":
                    {
                        columnName = "userName";
                    }
                    break;

                case "Created Date":
                    {
                        columnName = "createdDate";
                    }
                    break;

                case "FullName":
                    {
                        columnName = "fullName";
                    }
                    break;

                case "Gender":
                    {

                        columnName = "gender";
                    }
                    break;

                case "Brithday":
                    {
                        columnName = "brithday";

                    }
                    break;

                case "Nationality":
                    {
                        columnName = "nationality";

                    }
                    break;

                //"Phone 
                case "Phone":
                    {
                        columnName = "phone";

                    }
                    break;

                case "Is Active":
                    {
                        columnName = "isActive";
                    }
                    break;

                default:
                    {
                        columnName = "none";
                    }
                    break;
            }

            if (string.IsNullOrEmpty(txtFilterHolder.Text.Trim()) || columnName == "none")
            {
                dtEmployee.DefaultView.RowFilter = "";
                return;
            }

            if (columnName == "employeeID" || columnName == "personID")

                dtEmployee.DefaultView.RowFilter = string.Format("[{0}] ={1}", columnName, txtFilterHolder.Text);

            else
                dtEmployee.DefaultView.RowFilter = string.Format("[{0}] like '{1}%'", columnName, txtFilterHolder.Text);


        }

        private void activateEmployeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int coachID = (int)dgvEmployees.CurrentRow.Cells[0].Value;
            if (MessageBox.Show("Are You Sure You Want to Activate Employee", "Question", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == DialogResult.OK)
            {
                if (clsEmployeeBuisness.activateEmployee(coachID))
                {
                    MessageBox.Show("Activate Employee Secssfuly", "Question");
                    _load();
                }
            }
        }

        private void deActivateEmployeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int coachID = (int)dgvEmployees.CurrentRow.Cells[0].Value;
            if (MessageBox.Show("Are You Sure You Want to DeActivate Employee", "Question", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == DialogResult.OK)
            {
                if (clsEmployeeBuisness.deActivateEmployee(coachID))
                {
                    MessageBox.Show("DeActivate Employee Secssfuly", "Question");
                    _load();
                }
            }
        }

        private void cbStateFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            string columnName = "isActive";
            string value = "";
            if (cbStateFilter.Text == "Yes")
            {
                value = "1";
            }
            else if (cbStateFilter.Text == "No")
            {
                value = "0";
            }


            if (!string.IsNullOrEmpty(value))
                dtEmployee.DefaultView.RowFilter = string.Format("[{0}] = {1}", columnName, value);
            else
                dtEmployee.DefaultView.RowFilter = "";


        }

        private void deleteEmployeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int employeeID = (int)dgvEmployees.CurrentRow.Cells[0].Value;
            if (MessageBox.Show("Are you sure you want to delete this Employee", "?", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                if (clsEmployeeBuisness.deleteEmployee(employeeID))
                {
                    MessageBox.Show("the Employee is delete Successfuly", "Done", MessageBoxButtons.OK);
                    _load();

                }
                else
                {
                    MessageBox.Show("Could Not deleted The Employee", "Done", MessageBoxButtons.OK);

                }

            }

        }

        private void updatePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int employeeID = (int)dgvEmployees.CurrentRow.Cells[0].Value;

            frmUpdateEmployeePassword form = new frmUpdateEmployeePassword(employeeID);
            form.ShowDialog();
        }

        private void txtFilterHolder_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (cbFilter.Text == "Employee ID" || cbFilter.Text == "Person ID" | cbFilter.Text == "Phone")

                if (char.IsLetter(e.KeyChar))
                {
                    e.Handled = true;
                }
        }

        private void showInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int employeeID = (int)dgvEmployees.CurrentRow.Cells[0].Value;
            frmShowEmployeeInfo form = new frmShowEmployeeInfo(employeeID);
            form.ShowDialog();
        }
    }
}
