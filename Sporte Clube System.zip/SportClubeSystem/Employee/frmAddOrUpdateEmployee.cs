﻿using SportCllubeBuisness;
using SportClubeSystem.GenralClass;
using System;
using System.Data;
using System.Windows.Forms;


namespace SportClubeSystem.Employee
{
    public partial class frmAddOrUpdateEmployee : Form
    {
        enum enMode { add, update }
        private enMode _mode { get; set; }
        private int _employeeID { get; set; }
        private clsEmployeeBuisness _employee;
        private int _personID
        {
            get
            {
                return ctrPersonCardWithFilter2.personID;
            }
        }

        DataTable dtNationality = new DataTable();

        public frmAddOrUpdateEmployee()
        {
            InitializeComponent();
            _mode = enMode.add;

        }

        public frmAddOrUpdateEmployee(int employeeID)
        {
            InitializeComponent();
            _employeeID = employeeID;
            _mode = enMode.update;
        }

        private void _loadNaationlity()
        {
            dtNationality = clsNaitonalityBuisness.getAllNationality();
            if (dtNationality.Rows.Count > 0)
            {
                foreach (DataRow row in dtNationality.Rows)
                {
                    cbbNationalities.Items.Add(row[1].ToString());
                }
            }
        }

        private void _reseateData()
        {
            _loadNaationlity();
            if (_mode == enMode.add)
            {
                lbHeaderTitle.Text = "Add New Employee";
                btnSave.Text = "Save";
                _employee = new clsEmployeeBuisness();
                tabEmployee1.Enabled = false;
                btnNext.Enabled = false;
                btnSave.Enabled = false;

            }
            else
            {
                lbHeaderTitle.Text = "Update Employee";
                btnSave.Text = "Update";
            }

            if (cbbNationalities.Items.Count > 0)
                cbbNationalities.SelectedIndex = 0;
            txtUserName.Text = "";
            txtPassword.Text = "";
            txtConfirmPassword.Text = "";
            rbNo.Checked = true;
            dtpCreatedDate.Value = DateTime.Now;

        }

        private void _loadData()
        {
            _employee = clsEmployeeBuisness.findEmployeeByID(_employeeID);

            if (_employee == null)
            {
                MessageBox.Show($"Employee Not Found With ID {_employeeID}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return;
            }

            ctrPersonCardWithFilter2.loadPersonData(_employee.personID);
            ctrPersonCardWithFilter2.filterState = false;

            cbbNationalities.SelectedIndex = cbbNationalities.FindString(_employee.personInfo.nationalityIfno.name);

            txtUserName.Text = _employee.userName;
            txtPassword.Text = _employee.password;
            txtConfirmPassword.Text = _employee.password;

            txtPassword.Enabled = false;
            txtConfirmPassword.Enabled = false;

            if (_employee.isActive)
                rbYes.Checked = true;
            else rbNo.Checked = false;
            lbCreatedDate.Visible = true;
            dtpCreatedDate.Visible = true;
            dtpCreatedDate.Value = _employee.createDate;
        }




        private void btnNext_Click(object sender, EventArgs e)
        {
            tabEmployee.SelectedIndex = 1;

        }

        private void btnSave_Click(object sender, EventArgs e)
        {

            if (_personID == 0)
            {
                MessageBox.Show("Please select person to link it ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrEmpty(cbbNationalities.Text))
            {
                errorProvider1.SetError(cbbNationalities, "this feild is reqiued ");
                return;
            }

            if (string.IsNullOrEmpty(txtUserName.Text))
            {
                errorProvider1.SetError(txtUserName, "this feild is reqiued ");
                return;
            }

            if (string.IsNullOrEmpty(txtPassword.Text))
            {
                errorProvider1.SetError(txtPassword, "this feild is reqiued ");
                return;
            }

            if (string.IsNullOrEmpty(txtConfirmPassword.Text))
            {
                errorProvider1.SetError(txtConfirmPassword, "this feild is reqiued ");
                return;
            }

            if (txtConfirmPassword.Text != txtPassword.Text)
            {
                errorProvider1.SetError(txtConfirmPassword, "Confrim password must be like Password");
                return;
            }
            _employee.personID = _personID;
            _employee.userName = txtUserName.Text;
            _employee.password = clsUtil.decodePassword(txtPassword.Text);
            _employee.isActive = rbYes.Checked ? true : false;
            _employee.addBy = clsEmployee.employee.id;

            if (_employee.save())
            {

                MessageBox.Show("Adding Data Seccsfuly", "Done", MessageBoxButtons.OK);

                btnSave.Text = "Update";
            }
            else

            {

                MessageBox.Show("Colud Not Adding Emplyee", "Error", MessageBoxButtons.OK);
            }





        }


        private void frmAddOrUpdateEmployee_Load(object sender, EventArgs e)
        {
            _reseateData();
            if (_mode == enMode.update)
                _loadData();
        }

        private void txtUserName_Leave(object sender, EventArgs e)
        {
            if (clsEmployeeBuisness.isEmployeeExistByUserName(txtUserName.Text))
            {
                errorProvider1.SetError(txtUserName, "this user name already used ");
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ctrPersonCardWithFilter2_onAddComplate(int obj)
        {
            if (clsEmployeeBuisness.isEmployeeExistByPersonID(obj))
            {
                MessageBox.Show($"Person is Already Link To another Account ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnSave.Enabled = false;
                tabEmployee1.Enabled = false;
                btnNext.Enabled = false;
                return;
            }
            btnSave.Enabled = true;
            tabEmployee1.Enabled = true;
            btnNext.Enabled = true;
        }


        private void ctrPersonCardWithFilter2_onPersonSelect(int obj)
        {
            if (clsEmployeeBuisness.isEmployeeExistByPersonID(obj))
            {
                MessageBox.Show($"Person is Already Link To another Account ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnSave.Enabled = false;
                tabEmployee1.Enabled = false;
                btnNext.Enabled = false;
                return;
            }
            btnSave.Enabled = true;
            tabEmployee1.Enabled = true;
            btnNext.Enabled = true;
        }
    }
}
