﻿using SportCllubeBuisness;
using System.Windows.Forms;

namespace SportClubeSystem.Employee
{
    public partial class frmShowEmployeeInfo : Form
    {
        public frmShowEmployeeInfo(int employeeID)
        {
            InitializeComponent();
            _loadData(employeeID);
        }

        private void _loadData(int employeeID)
        {
            clsEmployeeBuisness _employee = clsEmployeeBuisness.findEmployeeByID(employeeID);
            if (_employee == null)
            {
                MessageBox.Show("Are You Sure You Want to Activate Employee", "Question", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
                this.Close();
                return;

            }

            ctrPersonCard1.loadData(_employee.personID);
            lbEmployeeID.Text = _employee.id.ToString();
            lbCreatedDate.Text = _employee.createDate.ToString();
            lbUserName.Text = _employee.userName;
            checIsActive.Checked = _employee.isActive;
        }

        private void button1_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }
    }
}
