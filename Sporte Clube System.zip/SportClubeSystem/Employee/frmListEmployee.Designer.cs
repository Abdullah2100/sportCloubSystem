﻿namespace SportClubeSystem.Employee
{
    partial class frmListEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.cbStateFilter = new System.Windows.Forms.ComboBox();
            this.txtFilterHolder = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.lbListSize = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cbFilter = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvEmployees = new System.Windows.Forms.DataGridView();
            this.cnsEmploye = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.addEmplyeeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateEmpoyeeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteEmployeeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.activateEmployeeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deActivateEmployeeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updatePasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lbHeaderTitle = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.showInfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployees)).BeginInit();
            this.cnsEmploye.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // cbStateFilter
            // 
            this.cbStateFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbStateFilter.FormattingEnabled = true;
            this.cbStateFilter.Items.AddRange(new object[] {
            "All",
            "Yes",
            "No"});
            this.cbStateFilter.Location = new System.Drawing.Point(281, 397);
            this.cbStateFilter.Name = "cbStateFilter";
            this.cbStateFilter.Size = new System.Drawing.Size(140, 24);
            this.cbStateFilter.TabIndex = 45;
            this.cbStateFilter.Visible = false;
            this.cbStateFilter.SelectedIndexChanged += new System.EventHandler(this.cbStateFilter_SelectedIndexChanged);
            // 
            // txtFilterHolder
            // 
            this.txtFilterHolder.Location = new System.Drawing.Point(281, 398);
            this.txtFilterHolder.Name = "txtFilterHolder";
            this.txtFilterHolder.Size = new System.Drawing.Size(188, 22);
            this.txtFilterHolder.TabIndex = 44;
            this.txtFilterHolder.TextChanged += new System.EventHandler(this.txtFilterHolder_TextChanged);
            this.txtFilterHolder.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFilterHolder_KeyPress);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(1368, 633);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(159, 49);
            this.btnClose.TabIndex = 43;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            // 
            // lbListSize
            // 
            this.lbListSize.AutoSize = true;
            this.lbListSize.Location = new System.Drawing.Point(134, 649);
            this.lbListSize.Name = "lbListSize";
            this.lbListSize.Size = new System.Drawing.Size(14, 16);
            this.lbListSize.TabIndex = 42;
            this.lbListSize.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(63, 649);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 16);
            this.label5.TabIndex = 41;
            this.label5.Text = "Recourd :";
            // 
            // cbFilter
            // 
            this.cbFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbFilter.FormattingEnabled = true;
            this.cbFilter.Items.AddRange(new object[] {
            "none",
            "Employee ID",
            "Person ID",
            "UserName",
            "Created Date",
            "FullName ",
            "Gender",
            "Brithday",
            "Nationality ",
            "Phone",
            "Is Active"});
            this.cbFilter.Location = new System.Drawing.Point(112, 398);
            this.cbFilter.Name = "cbFilter";
            this.cbFilter.Size = new System.Drawing.Size(154, 24);
            this.cbFilter.TabIndex = 38;
            this.cbFilter.SelectedIndexChanged += new System.EventHandler(this.cbFilter_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.label2.Location = new System.Drawing.Point(43, 399);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 22);
            this.label2.TabIndex = 40;
            this.label2.Text = "Filter :";
            // 
            // dgvEmployees
            // 
            this.dgvEmployees.BackgroundColor = System.Drawing.Color.White;
            this.dgvEmployees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmployees.ContextMenuStrip = this.cnsEmploye;
            this.dgvEmployees.Location = new System.Drawing.Point(45, 435);
            this.dgvEmployees.Name = "dgvEmployees";
            this.dgvEmployees.RowHeadersWidth = 51;
            this.dgvEmployees.RowTemplate.Height = 24;
            this.dgvEmployees.Size = new System.Drawing.Size(1482, 184);
            this.dgvEmployees.TabIndex = 37;
            // 
            // cnsEmploye
            // 
            this.cnsEmploye.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.cnsEmploye.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addEmplyeeToolStripMenuItem,
            this.updateEmpoyeeToolStripMenuItem,
            this.deleteEmployeeToolStripMenuItem,
            this.activateEmployeeToolStripMenuItem,
            this.deActivateEmployeeToolStripMenuItem,
            this.updatePasswordToolStripMenuItem,
            this.showInfoToolStripMenuItem});
            this.cnsEmploye.Name = "cnsEmploye";
            this.cnsEmploye.Size = new System.Drawing.Size(222, 200);
            this.cnsEmploye.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            // 
            // addEmplyeeToolStripMenuItem
            // 
            this.addEmplyeeToolStripMenuItem.Name = "addEmplyeeToolStripMenuItem";
            this.addEmplyeeToolStripMenuItem.Size = new System.Drawing.Size(221, 24);
            this.addEmplyeeToolStripMenuItem.Text = "Add Emplyee";
            this.addEmplyeeToolStripMenuItem.Click += new System.EventHandler(this.addEmplyeeToolStripMenuItem_Click);
            // 
            // updateEmpoyeeToolStripMenuItem
            // 
            this.updateEmpoyeeToolStripMenuItem.Name = "updateEmpoyeeToolStripMenuItem";
            this.updateEmpoyeeToolStripMenuItem.Size = new System.Drawing.Size(221, 24);
            this.updateEmpoyeeToolStripMenuItem.Text = "Update Employee";
            this.updateEmpoyeeToolStripMenuItem.Click += new System.EventHandler(this.updateEmpoyeeToolStripMenuItem_Click);
            // 
            // deleteEmployeeToolStripMenuItem
            // 
            this.deleteEmployeeToolStripMenuItem.Name = "deleteEmployeeToolStripMenuItem";
            this.deleteEmployeeToolStripMenuItem.Size = new System.Drawing.Size(221, 24);
            this.deleteEmployeeToolStripMenuItem.Text = "Delete Employee";
            this.deleteEmployeeToolStripMenuItem.Click += new System.EventHandler(this.deleteEmployeeToolStripMenuItem_Click);
            // 
            // activateEmployeeToolStripMenuItem
            // 
            this.activateEmployeeToolStripMenuItem.Name = "activateEmployeeToolStripMenuItem";
            this.activateEmployeeToolStripMenuItem.Size = new System.Drawing.Size(221, 24);
            this.activateEmployeeToolStripMenuItem.Text = "Activate Employee";
            this.activateEmployeeToolStripMenuItem.Click += new System.EventHandler(this.activateEmployeeToolStripMenuItem_Click);
            // 
            // deActivateEmployeeToolStripMenuItem
            // 
            this.deActivateEmployeeToolStripMenuItem.Name = "deActivateEmployeeToolStripMenuItem";
            this.deActivateEmployeeToolStripMenuItem.Size = new System.Drawing.Size(221, 24);
            this.deActivateEmployeeToolStripMenuItem.Text = "DeActivate Employee";
            this.deActivateEmployeeToolStripMenuItem.Click += new System.EventHandler(this.deActivateEmployeeToolStripMenuItem_Click);
            // 
            // updatePasswordToolStripMenuItem
            // 
            this.updatePasswordToolStripMenuItem.Name = "updatePasswordToolStripMenuItem";
            this.updatePasswordToolStripMenuItem.Size = new System.Drawing.Size(221, 24);
            this.updatePasswordToolStripMenuItem.Text = "Update Password";
            this.updatePasswordToolStripMenuItem.Click += new System.EventHandler(this.updatePasswordToolStripMenuItem_Click);
            // 
            // lbHeaderTitle
            // 
            this.lbHeaderTitle.AutoSize = true;
            this.lbHeaderTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHeaderTitle.ForeColor = System.Drawing.Color.Red;
            this.lbHeaderTitle.Location = new System.Drawing.Point(519, 316);
            this.lbHeaderTitle.Name = "lbHeaderTitle";
            this.lbHeaderTitle.Size = new System.Drawing.Size(535, 54);
            this.lbHeaderTitle.TabIndex = 35;
            this.lbHeaderTitle.Text = "Employee Management";
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.White;
            this.btnAdd.Image = global::SportClubeSystem.Properties.Resources.add;
            this.btnAdd.Location = new System.Drawing.Point(1463, 360);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(64, 47);
            this.btnAdd.TabIndex = 39;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SportClubeSystem.Properties.Resources._1120619_businessman_client_man_manager_person_icon;
            this.pictureBox1.Location = new System.Drawing.Point(578, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(416, 290);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 36;
            this.pictureBox1.TabStop = false;
            // 
            // showInfoToolStripMenuItem
            // 
            this.showInfoToolStripMenuItem.Name = "showInfoToolStripMenuItem";
            this.showInfoToolStripMenuItem.Size = new System.Drawing.Size(221, 24);
            this.showInfoToolStripMenuItem.Text = "Show Info";
            this.showInfoToolStripMenuItem.Click += new System.EventHandler(this.showInfoToolStripMenuItem_Click);
            // 
            // frmListEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1555, 693);
            this.Controls.Add(this.cbStateFilter);
            this.Controls.Add(this.txtFilterHolder);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lbListSize);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cbFilter);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.dgvEmployees);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lbHeaderTitle);
            this.Name = "frmListEmployee";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmListEmployee";
            this.Load += new System.EventHandler(this.frmListEmployee_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployees)).EndInit();
            this.cnsEmploye.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbStateFilter;
        private System.Windows.Forms.TextBox txtFilterHolder;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lbListSize;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbFilter;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DataGridView dgvEmployees;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbHeaderTitle;
        private System.Windows.Forms.ContextMenuStrip cnsEmploye;
        private System.Windows.Forms.ToolStripMenuItem addEmplyeeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateEmpoyeeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteEmployeeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem activateEmployeeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deActivateEmployeeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updatePasswordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showInfoToolStripMenuItem;
    }
}