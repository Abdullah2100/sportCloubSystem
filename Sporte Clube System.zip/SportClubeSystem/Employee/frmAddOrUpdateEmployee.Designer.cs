﻿namespace SportClubeSystem.Employee
{
    partial class frmAddOrUpdateEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbHeaderTitle = new System.Windows.Forms.Label();
            this.tabEmployee = new System.Windows.Forms.TabControl();
            this.tabPerson = new System.Windows.Forms.TabPage();
            this.ctrPersonCardWithFilter2 = new SportClubeSystem.People.controller.ctrPersonCardWithFilter();
            this.btnNext = new System.Windows.Forms.Button();
            this.tabEmployee1 = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.txtConfirmPassword = new System.Windows.Forms.TextBox();
            this.rbNo = new System.Windows.Forms.RadioButton();
            this.rbYes = new System.Windows.Forms.RadioButton();
            this.lbIsActive = new System.Windows.Forms.Label();
            this.dtpCreatedDate = new System.Windows.Forms.DateTimePicker();
            this.lbCreatedDate = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbbNationalities = new System.Windows.Forms.ComboBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.tabEmployee.SuspendLayout();
            this.tabPerson.SuspendLayout();
            this.tabEmployee1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbHeaderTitle
            // 
            this.lbHeaderTitle.AutoSize = true;
            this.lbHeaderTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHeaderTitle.ForeColor = System.Drawing.Color.Red;
            this.lbHeaderTitle.Location = new System.Drawing.Point(279, 37);
            this.lbHeaderTitle.Name = "lbHeaderTitle";
            this.lbHeaderTitle.Size = new System.Drawing.Size(448, 54);
            this.lbHeaderTitle.TabIndex = 36;
            this.lbHeaderTitle.Text = "Add New Employee";
            // 
            // tabEmployee
            // 
            this.tabEmployee.Controls.Add(this.tabPerson);
            this.tabEmployee.Controls.Add(this.tabEmployee1);
            this.tabEmployee.Location = new System.Drawing.Point(51, 111);
            this.tabEmployee.Name = "tabEmployee";
            this.tabEmployee.SelectedIndex = 0;
            this.tabEmployee.Size = new System.Drawing.Size(943, 556);
            this.tabEmployee.TabIndex = 37;
            // 
            // tabPerson
            // 
            this.tabPerson.Controls.Add(this.ctrPersonCardWithFilter2);
            this.tabPerson.Controls.Add(this.btnNext);
            this.tabPerson.Location = new System.Drawing.Point(4, 25);
            this.tabPerson.Name = "tabPerson";
            this.tabPerson.Padding = new System.Windows.Forms.Padding(3);
            this.tabPerson.Size = new System.Drawing.Size(935, 527);
            this.tabPerson.TabIndex = 0;
            this.tabPerson.Text = "PersonInfo";
            this.tabPerson.UseVisualStyleBackColor = true;
            // 
            // ctrPersonCardWithFilter2
            // 
            this.ctrPersonCardWithFilter2.BackColor = System.Drawing.Color.White;
            this.ctrPersonCardWithFilter2.filterState = true;
            this.ctrPersonCardWithFilter2.Location = new System.Drawing.Point(6, 20);
            this.ctrPersonCardWithFilter2.Name = "ctrPersonCardWithFilter2";
            this.ctrPersonCardWithFilter2.Size = new System.Drawing.Size(901, 439);
            this.ctrPersonCardWithFilter2.TabIndex = 2;
            this.ctrPersonCardWithFilter2.onPersonSelect += new System.Action<int>(this.ctrPersonCardWithFilter2_onPersonSelect);
            this.ctrPersonCardWithFilter2.onAddComplate += new System.Action<int>(this.ctrPersonCardWithFilter2_onAddComplate);
            // 
            // btnNext
            // 
            this.btnNext.BackColor = System.Drawing.Color.White;
            this.btnNext.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.btnNext.Location = new System.Drawing.Point(763, 465);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(130, 45);
            this.btnNext.TabIndex = 1;
            this.btnNext.Text = "next ->";
            this.btnNext.UseVisualStyleBackColor = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // tabEmployee1
            // 
            this.tabEmployee1.Controls.Add(this.label5);
            this.tabEmployee1.Controls.Add(this.txtConfirmPassword);
            this.tabEmployee1.Controls.Add(this.rbNo);
            this.tabEmployee1.Controls.Add(this.rbYes);
            this.tabEmployee1.Controls.Add(this.lbIsActive);
            this.tabEmployee1.Controls.Add(this.dtpCreatedDate);
            this.tabEmployee1.Controls.Add(this.lbCreatedDate);
            this.tabEmployee1.Controls.Add(this.label3);
            this.tabEmployee1.Controls.Add(this.txtPassword);
            this.tabEmployee1.Controls.Add(this.label2);
            this.tabEmployee1.Controls.Add(this.txtUserName);
            this.tabEmployee1.Controls.Add(this.label1);
            this.tabEmployee1.Controls.Add(this.cbbNationalities);
            this.tabEmployee1.Location = new System.Drawing.Point(4, 25);
            this.tabEmployee1.Name = "tabEmployee1";
            this.tabEmployee1.Padding = new System.Windows.Forms.Padding(3);
            this.tabEmployee1.Size = new System.Drawing.Size(935, 527);
            this.tabEmployee1.TabIndex = 1;
            this.tabEmployee1.Text = "EmployeeInfo";
            this.tabEmployee1.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 293);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(121, 16);
            this.label5.TabIndex = 14;
            this.label5.Text = "Confirm Password :";
            // 
            // txtConfirmPassword
            // 
            this.txtConfirmPassword.Location = new System.Drawing.Point(165, 287);
            this.txtConfirmPassword.MaxLength = 15;
            this.txtConfirmPassword.Name = "txtConfirmPassword";
            this.txtConfirmPassword.PasswordChar = '#';
            this.txtConfirmPassword.Size = new System.Drawing.Size(165, 22);
            this.txtConfirmPassword.TabIndex = 13;
            this.txtConfirmPassword.UseSystemPasswordChar = true;
            // 
            // rbNo
            // 
            this.rbNo.AutoSize = true;
            this.rbNo.Location = new System.Drawing.Point(244, 196);
            this.rbNo.Name = "rbNo";
            this.rbNo.Size = new System.Drawing.Size(46, 20);
            this.rbNo.TabIndex = 12;
            this.rbNo.TabStop = true;
            this.rbNo.Text = "No";
            this.rbNo.UseVisualStyleBackColor = true;
            // 
            // rbYes
            // 
            this.rbYes.AutoSize = true;
            this.rbYes.Location = new System.Drawing.Point(165, 196);
            this.rbYes.Name = "rbYes";
            this.rbYes.Size = new System.Drawing.Size(52, 20);
            this.rbYes.TabIndex = 11;
            this.rbYes.TabStop = true;
            this.rbYes.Text = "Yes";
            this.rbYes.UseVisualStyleBackColor = true;
            // 
            // lbIsActive
            // 
            this.lbIsActive.AutoSize = true;
            this.lbIsActive.Location = new System.Drawing.Point(75, 175);
            this.lbIsActive.Name = "lbIsActive";
            this.lbIsActive.Size = new System.Drawing.Size(60, 16);
            this.lbIsActive.TabIndex = 10;
            this.lbIsActive.Text = "isActive :";
            // 
            // dtpCreatedDate
            // 
            this.dtpCreatedDate.Enabled = false;
            this.dtpCreatedDate.Location = new System.Drawing.Point(165, 335);
            this.dtpCreatedDate.Name = "dtpCreatedDate";
            this.dtpCreatedDate.Size = new System.Drawing.Size(165, 22);
            this.dtpCreatedDate.TabIndex = 7;
            this.dtpCreatedDate.Visible = false;
            // 
            // lbCreatedDate
            // 
            this.lbCreatedDate.AutoSize = true;
            this.lbCreatedDate.Location = new System.Drawing.Point(45, 341);
            this.lbCreatedDate.Name = "lbCreatedDate";
            this.lbCreatedDate.Size = new System.Drawing.Size(90, 16);
            this.lbCreatedDate.TabIndex = 6;
            this.lbCreatedDate.Text = "CreatedDate :";
            this.lbCreatedDate.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(62, 245);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "Password :";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(168, 241);
            this.txtPassword.MaxLength = 15;
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '#';
            this.txtPassword.Size = new System.Drawing.Size(165, 22);
            this.txtPassword.TabIndex = 4;
            this.txtPassword.UseSystemPasswordChar = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(65, 129);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "UserName :";
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(171, 125);
            this.txtUserName.MaxLength = 100;
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(165, 22);
            this.txtUserName.TabIndex = 2;
            this.txtUserName.Leave += new System.EventHandler(this.txtUserName_Leave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(65, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nationality :";
            // 
            // cbbNationalities
            // 
            this.cbbNationalities.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbNationalities.FormattingEnabled = true;
            this.cbbNationalities.Location = new System.Drawing.Point(171, 78);
            this.cbbNationalities.Name = "cbbNationalities";
            this.cbbNationalities.Size = new System.Drawing.Size(165, 24);
            this.cbbNationalities.TabIndex = 0;
            // 
            // btnClose
            // 
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.btnClose.Location = new System.Drawing.Point(648, 688);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(161, 50);
            this.btnClose.TabIndex = 38;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnSave
            // 
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.btnSave.Location = new System.Drawing.Point(833, 688);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(161, 50);
            this.btnSave.TabIndex = 39;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // frmAddOrUpdateEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1034, 750);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.tabEmployee);
            this.Controls.Add(this.lbHeaderTitle);
            this.Name = "frmAddOrUpdateEmployee";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmAddOrUpdateEmployee";
            this.Load += new System.EventHandler(this.frmAddOrUpdateEmployee_Load);
            this.tabEmployee.ResumeLayout(false);
            this.tabPerson.ResumeLayout(false);
            this.tabEmployee1.ResumeLayout(false);
            this.tabEmployee1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbHeaderTitle;
        private System.Windows.Forms.TabControl tabEmployee;
        private System.Windows.Forms.TabPage tabPerson;
        private People.controller.ctrPersonCardWithFilter ctrPersonCardWithFilter1;
        private System.Windows.Forms.TabPage tabEmployee1;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Label lbIsActive;
        private System.Windows.Forms.DateTimePicker dtpCreatedDate;
        private System.Windows.Forms.Label lbCreatedDate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbbNationalities;
        private System.Windows.Forms.RadioButton rbNo;
        private System.Windows.Forms.RadioButton rbYes;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtConfirmPassword;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private People.controller.ctrPersonCardWithFilter ctrPersonCardWithFilter2;
    }
}