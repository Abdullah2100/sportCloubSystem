﻿using SportCllubeBuisness;
using SportClubeSystem.GenralClass;
using System;
using System.Windows.Forms;

namespace SportClubeSystem.Employee
{
    public partial class frmUpdateEmployeePassword : Form
    {
        private clsEmployeeBuisness _employee { get; set; }
        private int _employeeID = 0;
        public frmUpdateEmployeePassword(int employeeID)
        {
            InitializeComponent();
            _loadData(employeeID);
        }

        private void _loadData(int id)
        {
            _employee = clsEmployeeBuisness.findEmployeeByID(id);
            if (_employee == null)
            {
                MessageBox.Show("Some File Must Has Value", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }
            ctrPersonCard1.loadData(_employee.personID);
        }

        private void frmUpdateEmployeePassword_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            TextBox temp = (TextBox)sender;
            if (string.IsNullOrEmpty(temp.Text))
            {
                errorProvider1.SetError(temp, "reqiure feild");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!this.ValidateChildren())
            {
                MessageBox.Show("Some File Must Has Value", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;

            }

            if (!clsUtil.compareHash(txtCurrentPassword.Text, _employee.password))
            {
                errorProvider1.SetError(txtCurrentPassword, "Not Valide Password");
                return;
            }

            if (txtnewPassword.Text != txtConfirmPassword.Text)
            {
                errorProvider1.SetError(txtConfirmPassword, "ConfirmPassword Must be like new password");
                return;

            }
            _employee.password = clsUtil.decodePassword(txtnewPassword.Text);
            if (_employee.save())
            {
                MessageBox.Show("update password Seccsfuly", "Done", MessageBoxButtons.OK);
                return;

            }

            else

            {

                MessageBox.Show("Colud Not update password", "Error", MessageBoxButtons.OK);
            }
        }
    }
}
