﻿namespace SportClubeSystem.Employee
{
    partial class frmShowEmployeeInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ctrPersonCard1 = new SportClubeSystem.People.ctrPersonCard();
            this.lbHeaderTitle = new System.Windows.Forms.Label();
            this.gbEmployee = new System.Windows.Forms.GroupBox();
            this.lbCreatedDate = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.checIsActive = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lbUserName = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbEmployeeID = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.gbEmployee.SuspendLayout();
            this.SuspendLayout();
            // 
            // ctrPersonCard1
            // 
            this.ctrPersonCard1.BackColor = System.Drawing.Color.White;
            this.ctrPersonCard1.Location = new System.Drawing.Point(59, 117);
            this.ctrPersonCard1.Name = "ctrPersonCard1";
            this.ctrPersonCard1.Size = new System.Drawing.Size(888, 321);
            this.ctrPersonCard1.TabIndex = 0;
            // 
            // lbHeaderTitle
            // 
            this.lbHeaderTitle.AutoSize = true;
            this.lbHeaderTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHeaderTitle.ForeColor = System.Drawing.Color.Red;
            this.lbHeaderTitle.Location = new System.Drawing.Point(397, 44);
            this.lbHeaderTitle.Name = "lbHeaderTitle";
            this.lbHeaderTitle.Size = new System.Drawing.Size(239, 54);
            this.lbHeaderTitle.TabIndex = 11;
            this.lbHeaderTitle.Text = "Employee";
            this.lbHeaderTitle.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // gbEmployee
            // 
            this.gbEmployee.Controls.Add(this.lbCreatedDate);
            this.gbEmployee.Controls.Add(this.label6);
            this.gbEmployee.Controls.Add(this.checIsActive);
            this.gbEmployee.Controls.Add(this.label5);
            this.gbEmployee.Controls.Add(this.lbUserName);
            this.gbEmployee.Controls.Add(this.label3);
            this.gbEmployee.Controls.Add(this.lbEmployeeID);
            this.gbEmployee.Controls.Add(this.label1);
            this.gbEmployee.Location = new System.Drawing.Point(70, 447);
            this.gbEmployee.Name = "gbEmployee";
            this.gbEmployee.Size = new System.Drawing.Size(862, 146);
            this.gbEmployee.TabIndex = 12;
            this.gbEmployee.TabStop = false;
            this.gbEmployee.Text = "Employee Info";
            // 
            // lbCreatedDate
            // 
            this.lbCreatedDate.AutoSize = true;
            this.lbCreatedDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.lbCreatedDate.Location = new System.Drawing.Point(505, 90);
            this.lbCreatedDate.Name = "lbCreatedDate";
            this.lbCreatedDate.Size = new System.Drawing.Size(72, 26);
            this.lbCreatedDate.TabIndex = 7;
            this.lbCreatedDate.Text = "?????";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.label6.Location = new System.Drawing.Point(346, 93);
            this.label6.Name = "label6";
            this.label6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label6.Size = new System.Drawing.Size(153, 26);
            this.label6.TabIndex = 6;
            this.label6.Text = "Created Date :";
            // 
            // checIsActive
            // 
            this.checIsActive.AutoSize = true;
            this.checIsActive.Location = new System.Drawing.Point(181, 99);
            this.checIsActive.Name = "checIsActive";
            this.checIsActive.Size = new System.Drawing.Size(18, 17);
            this.checIsActive.TabIndex = 5;
            this.checIsActive.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.label5.Location = new System.Drawing.Point(38, 93);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 26);
            this.label5.TabIndex = 4;
            this.label5.Text = "isActive :";
            // 
            // lbUserName
            // 
            this.lbUserName.AutoSize = true;
            this.lbUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.lbUserName.Location = new System.Drawing.Point(481, 42);
            this.lbUserName.Name = "lbUserName";
            this.lbUserName.Size = new System.Drawing.Size(72, 26);
            this.lbUserName.TabIndex = 3;
            this.lbUserName.Text = "?????";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.label3.Location = new System.Drawing.Point(346, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 26);
            this.label3.TabIndex = 2;
            this.label3.Text = "UserName :";
            // 
            // lbEmployeeID
            // 
            this.lbEmployeeID.AutoSize = true;
            this.lbEmployeeID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.lbEmployeeID.Location = new System.Drawing.Point(176, 42);
            this.lbEmployeeID.Name = "lbEmployeeID";
            this.lbEmployeeID.Size = new System.Drawing.Size(72, 26);
            this.lbEmployeeID.TabIndex = 1;
            this.lbEmployeeID.Text = "?????";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.label1.Location = new System.Drawing.Point(38, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "EmplyeeID :";
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.button1.Location = new System.Drawing.Point(783, 613);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(149, 57);
            this.button1.TabIndex = 13;
            this.button1.Text = "Close";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmShowEmployeeInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1014, 682);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.gbEmployee);
            this.Controls.Add(this.lbHeaderTitle);
            this.Controls.Add(this.ctrPersonCard1);
            this.Name = "frmShowEmployeeInfo";
            this.Text = "frmShowEmployeeInfo";
            this.gbEmployee.ResumeLayout(false);
            this.gbEmployee.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private People.ctrPersonCard ctrPersonCard1;
        private System.Windows.Forms.Label lbHeaderTitle;
        private System.Windows.Forms.GroupBox gbEmployee;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbCreatedDate;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox checIsActive;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbUserName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbEmployeeID;
        private System.Windows.Forms.Button button1;
    }
}