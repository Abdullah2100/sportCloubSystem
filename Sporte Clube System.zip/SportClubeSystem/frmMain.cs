﻿using SportClubeSystem.Auth;
using SportClubeSystem.Coach;
using SportClubeSystem.Employee;
using SportClubeSystem.GenralClass;
using SportClubeSystem.Members;
using SportClubeSystem.MemberSubscription;
using SportClubeSystem.People;
using SportClubeSystem.SportCoaches;
using SportClubeSystem.Sports;
using System;
using System.Windows.Forms;

namespace SportClubeSystem
{
    public partial class frmMain : Form
    {
        frmLogin _loginPage;
        public frmMain(frmLogin temp)
        {
            InitializeComponent();
            this._loginPage = temp;
        }


        private void frmMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            _loginPage.Show();
            this.Close();

        }

        private void btnSports_Click(object sender, EventArgs e)
        {
            frmSportList form = new frmSportList();
            form.ShowDialog();
        }

        private void btnPeople_Click(object sender, EventArgs e)
        {
            frmPeoplesList form = new frmPeoplesList();
            form.ShowDialog();
        }

        private void btnMembers_Click(object sender, EventArgs e)
        {

            frmListMember form = new frmListMember();
            form.ShowDialog();
        }

        private void btnCoaches_Click(object sender, EventArgs e)
        {
            frmListCoachs form = new frmListCoachs();
            form.ShowDialog();
        }

        private void btnCoachTrainging_Click(object sender, EventArgs e)
        {

            frmCoachTrainingList form = new frmCoachTrainingList();
            form.ShowDialog();
        }

        private void btnMemberSubscription_Click(object sender, EventArgs e)
        {
            frmListMemberSubscription form = new frmListMemberSubscription();
            form.ShowDialog();
        }

        private void btnEmployee_Click(object sender, EventArgs e)
        {
            frmListEmployee form = new frmListEmployee();
            form.ShowDialog();
        }

        private void updatePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int? id = clsEmployee.employee.id;
            frmUpdateEmployeePassword form = new frmUpdateEmployeePassword(id ?? 0);
            form.ShowDialog();
        }

        private void showInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int? id = clsEmployee.employee.id;
            frmShowEmployeeInfo form = new frmShowEmployeeInfo(id ?? 0);
            form.ShowDialog();
        }

        private void currentEmployeToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            updatePasswordToolStripMenuItem.Enabled = clsEmployee.employee != null;
            showInfoToolStripMenuItem.Enabled = clsEmployee.employee != null;
        }

    }
}
