﻿using SportCllubeBuisness;
using System;
using System.Windows.Forms;

namespace SportClubeSystem.CoachTraining.controller
{
    public partial class ctrCoachInfoCard : UserControl
    {
        public clsCoachBuisness coachBuisness;
        public ctrCoachInfoCard()
        {
            InitializeComponent();
        }
        public void loadData(int coachID)
        {

            coachBuisness = clsCoachBuisness.findCoachByID(coachID);
            if (coachBuisness == null)
            {
                return;
            }
            ctrPersonCard1.loadData(coachBuisness.personID);
            dtpStartTime.Value = coachBuisness.startTraingDate;
            dtpStartTime.Enabled = false;
            chekActive.Checked = coachBuisness.isActive;
            chekActive.Enabled = false;

        }

        private void ctrCoachInfoCard_Load(object sender, EventArgs e)
        {


        }
    }
}
