﻿namespace SportClubeSystem.CoachTraining.controller
{
    partial class ctrCoachInfoCard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbCoachInfo = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.chekActive = new System.Windows.Forms.CheckBox();
            this.dtpStartTime = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.ctrPersonCard1 = new SportClubeSystem.People.ctrPersonCard();
            this.gbCoachInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbCoachInfo
            // 
            this.gbCoachInfo.Controls.Add(this.label2);
            this.gbCoachInfo.Controls.Add(this.chekActive);
            this.gbCoachInfo.Controls.Add(this.dtpStartTime);
            this.gbCoachInfo.Controls.Add(this.label1);
            this.gbCoachInfo.Location = new System.Drawing.Point(13, 325);
            this.gbCoachInfo.Name = "gbCoachInfo";
            this.gbCoachInfo.Size = new System.Drawing.Size(865, 92);
            this.gbCoachInfo.TabIndex = 14;
            this.gbCoachInfo.TabStop = false;
            this.gbCoachInfo.Text = "CoachInfo";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(545, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Is Active  :";
            // 
            // chekActive
            // 
            this.chekActive.AutoSize = true;
            this.chekActive.Location = new System.Drawing.Point(623, 42);
            this.chekActive.Name = "chekActive";
            this.chekActive.Size = new System.Drawing.Size(53, 20);
            this.chekActive.TabIndex = 5;
            this.chekActive.Text = "Yes";
            this.chekActive.UseVisualStyleBackColor = true;
            // 
            // dtpStartTime
            // 
            this.dtpStartTime.Location = new System.Drawing.Point(151, 41);
            this.dtpStartTime.Name = "dtpStartTime";
            this.dtpStartTime.Size = new System.Drawing.Size(176, 22);
            this.dtpStartTime.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "StartTrainDate :";
            // 
            // ctrPersonCard1
            // 
            this.ctrPersonCard1.BackColor = System.Drawing.Color.White;
            this.ctrPersonCard1.Location = new System.Drawing.Point(3, -2);
            this.ctrPersonCard1.Name = "ctrPersonCard1";
            this.ctrPersonCard1.Size = new System.Drawing.Size(888, 321);
            this.ctrPersonCard1.TabIndex = 0;
            // 
            // ctrCoachInfoCard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.gbCoachInfo);
            this.Controls.Add(this.ctrPersonCard1);
            this.Name = "ctrCoachInfoCard";
            this.Size = new System.Drawing.Size(897, 434);
            this.Load += new System.EventHandler(this.ctrCoachInfoCard_Load);
            this.gbCoachInfo.ResumeLayout(false);
            this.gbCoachInfo.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private People.ctrPersonCard ctrPersonCard1;
        private System.Windows.Forms.GroupBox gbCoachInfo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox chekActive;
        private System.Windows.Forms.DateTimePicker dtpStartTime;
        private System.Windows.Forms.Label label1;
    }
}
