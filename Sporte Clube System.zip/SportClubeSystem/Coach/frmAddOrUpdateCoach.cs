﻿using SportCllubeBuisness;
using SportClubeSystem.GenralClass;
using System;
using System.Windows.Forms;

namespace SportClubeSystem.Coach
{
    public partial class frmAddOrUpdateCoach : Form
    {
        private enum enMode { add, update };
        private enMode _mode;
        private clsPeopleBuisness _person
        {
            get { return ctrPersonCardWithFilter1.person; }
        }
        private int _personID
        {
            get { return ctrPersonCardWithFilter1.personID; }
        }
        private clsCoachBuisness _coach;
        private int _coachID;
        public frmAddOrUpdateCoach()
        {
            InitializeComponent();
        }

        public frmAddOrUpdateCoach(int coachID)
        {
            InitializeComponent();
            this._coachID = coachID;
            _mode = enMode.update;
        }
        private void _reaset()
        {
            if (_mode == enMode.add)
            {
                lbHeaderTitle.Text = "Add New Coach";
                btnSave.Text = "Add";
                _coach = new clsCoachBuisness();
            }
            else
            {
                lbHeaderTitle.Text = "Update Coach";
                btnSave.Text = "Update";
            }
        }

        private void _loadData(int coachId)
        {
            _coach = clsCoachBuisness.findCoachByID(coachId);
            if (_coach == null)
            {
                MessageBox.Show("User  Not Found", "Error", MessageBoxButtons.OK);
                this.Close();
                return;
            }
            ctrPersonCardWithFilter1.filterState = false;
            ctrPersonCardWithFilter1.loadPersonData(_coach.personID);
            dtpStartTime.Value = _coach.startTraingDate;
            chekIsActive.Checked = _coach.isActive;
        }

        private void frmAddOrUpdateCoach_Load(object sender, EventArgs e)
        {
            _reaset();
            if (_mode == enMode.update)
                _loadData(_coachID);

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (_personID == 0)
            {
                MessageBox.Show("Please select person to link it ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            _coach.personID = _personID;
            _coach.startTraingDate = dtpStartTime.Value;
            _coach.isActive = chekIsActive.Checked;
            _coach.addBy = clsEmployee.employee.id;
            if (_coach.save())
            {
                MessageBox.Show("Adding Coach Seccsfuly", "Done", MessageBoxButtons.OK);
                btnSave.Text = "Update";
            }
            else
            {
                MessageBox.Show("Colud", "Error", MessageBoxButtons.OK);

            }

        }

        private void ctrPersonCardWithFilter1_onAddComplate_1(int obj)
        {
            if (_person == null)
            {
                MessageBox.Show("User  Not Found", "Error", MessageBoxButtons.OK);
                // this.Close();
                btnSave.Visible = false;
                gbCoachInfo.Visible = false;
                ctrPersonCardWithFilter1.focuseSearch();
                return;
            }
            btnSave.Visible = true;
            gbCoachInfo.Visible = true;
            ctrPersonCardWithFilter1.filterState = false;
            ctrPersonCardWithFilter1.loadPersonData(obj);
        }

        private void ctrPersonCardWithFilter1_onPersonSelect_1(int obj)
        {
            if (clsCoachBuisness.isCoachExistByPerson(obj))
            {
                MessageBox.Show("Person is Already linked To Coach", "Error", MessageBoxButtons.OK);
                btnSave.Visible = false;
                gbCoachInfo.Visible = false;
                ctrPersonCardWithFilter1.focuseSearch();
                return;
            }

            btnSave.Enabled = true;
            ctrPersonCardWithFilter1.loadPersonData(obj);
        }

    }
}
