﻿using SportCllubeBuisness;
using System.Windows.Forms;

namespace SportClubeSystem.Coach
{
    public partial class frmShowCoachInfo : Form
    {
        public frmShowCoachInfo(int coachID)
        {
            InitializeComponent();
            _loadData(coachID);

        }

        private void _loadData(int coachID)
        {
            clsCoachBuisness coach = clsCoachBuisness.findCoachByID(coachID);
            if (coach == null)
            {

                MessageBox.Show("coach Not Found ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }

            ctrCoachInfoCard1.loadData(coachID);

        }

        private void btnClose_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }
    }
}
