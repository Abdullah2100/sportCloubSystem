﻿using SportCllubeBuisness;
using System;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;

namespace SportClubeSystem.Coach
{
    public partial class frmListCoachs : Form
    {
        DataTable dtCoach = new DataTable();
        public frmListCoachs()
        {
            InitializeComponent();
        }

        private void _loadData()
        {
            cbFilter.SelectedIndex = 0;
            dtCoach = clsCoachBuisness.getAllCoachs();
            dgvCoache.DataSource = dtCoach;
            if (dgvCoache.Rows.Count > 0)
            {
                dgvCoache.Columns[0].HeaderText = "Coache ID";
                dgvCoache.Columns[0].Width = 60;


                dgvCoache.Columns[1].HeaderText = "Person ID";
                dgvCoache.Columns[1].Width = 60;

                dgvCoache.Columns[2].HeaderText = "Start At";
                dgvCoache.Columns[2].Width = 70;


                dgvCoache.Columns[3].HeaderText = "Full Name";
                dgvCoache.Columns[3].Width = 310;

                dgvCoache.Columns[4].HeaderText = "Gender";
                dgvCoache.Columns[4].Width = 50;


                dgvCoache.Columns[5].HeaderText = "BrithDay";
                dgvCoache.Columns[5].Width = 130;


                dgvCoache.Columns[6].HeaderText = "Nationality";
                dgvCoache.Columns[6].Width = 45;



                dgvCoache.Columns[7].HeaderText = "Phone";
                dgvCoache.Columns[7].Width = 100;


                dgvCoache.Columns[8].HeaderText = "Is Active";
                dgvCoache.Columns[8].Width = 80;

                dgvCoache.Columns[9].HeaderText = "End At";
                dgvCoache.Columns[9].Width = 80;

                lbListSize.Text = dgvCoache.Rows.Count.ToString();

            }
        }

        private void frmListCoachs_Load(object sender, EventArgs e)
        {

            _loadData();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            frmAddOrUpdateCoach form = new frmAddOrUpdateCoach();
            form.ShowDialog();
            _loadData();

        }

        private void addCoachToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAddOrUpdateCoach form = new frmAddOrUpdateCoach();
            form.ShowDialog();
            _loadData();

        }

        private void updateCoachToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int coachID = (int)dgvCoache.CurrentRow.Cells[0].Value;
            frmAddOrUpdateCoach form = new frmAddOrUpdateCoach(coachID);
            form.ShowDialog();
            _loadData();

        }

        private void cmsCoach_Opening(object sender, CancelEventArgs e)
        {
            bool hasData = dtCoach.Rows.Count > 0;

            int coachID = !hasData ? 0 : (int)dgvCoache.CurrentRow.Cells[0].Value;
            bool isActive = coachID == 0 ? false : clsCoachBuisness.isCoachActive(coachID);
            activateCoachToolStripMenuItem.Enabled = (!isActive && hasData);
            deActivateCoachToolStripMenuItem.Enabled = (isActive && hasData);
            updateCoachToolStripMenuItem.Enabled = (isActive && hasData);
            showCoachInfoToolStripMenuItem.Enabled = (isActive && hasData);
            deleteCoachToolStripMenuItem.Enabled = (isActive && hasData);
        }

        private void activateCoachToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int coachID = (int)dgvCoache.CurrentRow.Cells[0].Value;
            if (MessageBox.Show("Are You Sure You Want to Activate Coach", "Question", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == DialogResult.OK)
            {
                if (clsCoachBuisness.activateCoach(coachID))
                {
                    MessageBox.Show("Activate Coach Secssfuly", "Question");
                    _loadData();
                }
            }
        }

        private void deActivateCoachToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int coachID = (int)dgvCoache.CurrentRow.Cells[0].Value;
            if (MessageBox.Show("Are You Sure You Want to deActive Coach", "Question", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == DialogResult.OK)
            {
                if (clsCoachBuisness.deActivateCoach(coachID))
                {
                    MessageBox.Show("deActive Coach Secssfuly", "Question");
                    _loadData();
                }
            }
        }

        private void showCoachInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int coachID = (int)dgvCoache.CurrentRow.Cells[0].Value;

            frmShowCoachInfo form = new frmShowCoachInfo(coachID);
            form.ShowDialog();
            _loadData();
        }

        private void deleteCoachToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int trianingCoachID = (int)dgvCoache.CurrentRow.Cells[0].Value;
            if (clsCoachBuisness.deleteCoach(trianingCoachID))
            {
                MessageBox.Show("the Coach is delete Successfuly", "Done", MessageBoxButtons.OK);
                _loadData();

            }
            else
            {
                MessageBox.Show("Could Not deleted The Coach", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void cbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtFilterHolder.Text = "";
            if (cbFilter.SelectedIndex == 0)
            {
                txtFilterHolder.Enabled = false;
                cbStateFilter.Visible = false;
            }
            else
            {
                txtFilterHolder.Enabled = cbFilter.SelectedIndex != 0;
                txtFilterHolder.Visible = cbFilter.SelectedIndex != 8;
                cbStateFilter.Visible = (cbFilter.SelectedIndex == 8);
            }
        }

        private void txtFilterHolder_TextChanged(object sender, EventArgs e)
        {
            string columnName = "";

            switch (cbFilter.Text)
            {
                case "Coache ID":
                    {
                        columnName = "CoacheID";
                    }
                    break;

                case "Person ID":
                    {
                        columnName = "personID";
                    }
                    break;
                    ;

                case "Start At":
                    {
                        columnName = "startTraingDate";
                    }
                    break;

                case "FullName":
                    {
                        columnName = "fullName";

                    }
                    break;

                case "Gender":
                    {
                        columnName = "gender";

                    }
                    break;

                case "BrithDay":
                    {

                        columnName = "brithday";
                    }
                    break;

                case "Nationality":
                    {
                        columnName = "nationality";

                    }
                    break;

                case "Phone":
                    {
                        columnName = "phone";

                    }
                    break;

                case "Is Active":
                    {
                        columnName = "isActive";

                    }
                    break;

                case "End At":
                    {
                        columnName = "endTraingDate";
                    }
                    break;

                default:
                    {
                        columnName = "none";
                    }
                    break;
            }

            if (string.IsNullOrEmpty(txtFilterHolder.Text.Trim()) || columnName == "none")
            {
                dtCoach.DefaultView.RowFilter = "";
                return;
            }

            if (columnName == "CoacheID" || columnName == "personID")

                dtCoach.DefaultView.RowFilter = string.Format("[{0}] ={1}", columnName, txtFilterHolder.Text);

            else
                dtCoach.DefaultView.RowFilter = string.Format("[{0}] like '{1}%'", columnName, txtFilterHolder.Text);

        }

        private void cbStateFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            string columnName = "isActive";
            string value = "";
            if (cbStateFilter.Text == "Yes")
            {
                value = "1";
            }
            else if (cbStateFilter.Text == "No")
            {
                value = "0";
            }


            if (!string.IsNullOrEmpty(value))
                dtCoach.DefaultView.RowFilter = string.Format("[{0}] = {1}", columnName, value);
            else
                dtCoach.DefaultView.RowFilter = "";

        }

        private void txtFilterHolder_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (cbFilter.Text == "Coache ID" || cbFilter.Text == "Person ID" | cbFilter.Text == "Phone")
            {
                if (char.IsLetter(e.KeyChar))
                {
                    e.Handled = true;
                }
            }
        }
    }
}
