﻿namespace SportClubeSystem
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnSports = new System.Windows.Forms.Button();
            this.btnMemberSubscription = new System.Windows.Forms.Button();
            this.btnEmployee = new System.Windows.Forms.Button();
            this.btnPeople = new System.Windows.Forms.Button();
            this.btnMembers = new System.Windows.Forms.Button();
            this.btnCoaches = new System.Windows.Forms.Button();
            this.btnCoachTrainging = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.currentEmployeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updatePasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showInfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SportClubeSystem.Properties.Resources.gym;
            this.pictureBox1.Location = new System.Drawing.Point(402, 120);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(470, 434);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btnSports
            // 
            this.btnSports.BackColor = System.Drawing.Color.White;
            this.btnSports.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSports.Location = new System.Drawing.Point(-1, 157);
            this.btnSports.Name = "btnSports";
            this.btnSports.Size = new System.Drawing.Size(164, 63);
            this.btnSports.TabIndex = 1;
            this.btnSports.TabStop = false;
            this.btnSports.Text = "Sports";
            this.btnSports.UseVisualStyleBackColor = false;
            this.btnSports.Click += new System.EventHandler(this.btnSports_Click);
            // 
            // btnMemberSubscription
            // 
            this.btnMemberSubscription.BackColor = System.Drawing.Color.White;
            this.btnMemberSubscription.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMemberSubscription.Location = new System.Drawing.Point(-1, 293);
            this.btnMemberSubscription.Name = "btnMemberSubscription";
            this.btnMemberSubscription.Size = new System.Drawing.Size(239, 63);
            this.btnMemberSubscription.TabIndex = 2;
            this.btnMemberSubscription.TabStop = false;
            this.btnMemberSubscription.Text = "MemberSubscription";
            this.btnMemberSubscription.UseVisualStyleBackColor = false;
            this.btnMemberSubscription.Click += new System.EventHandler(this.btnMemberSubscription_Click);
            // 
            // btnEmployee
            // 
            this.btnEmployee.BackColor = System.Drawing.Color.White;
            this.btnEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmployee.Location = new System.Drawing.Point(-1, 439);
            this.btnEmployee.Name = "btnEmployee";
            this.btnEmployee.Size = new System.Drawing.Size(164, 63);
            this.btnEmployee.TabIndex = 3;
            this.btnEmployee.TabStop = false;
            this.btnEmployee.Text = "Employees";
            this.btnEmployee.UseVisualStyleBackColor = false;
            this.btnEmployee.Click += new System.EventHandler(this.btnEmployee_Click);
            // 
            // btnPeople
            // 
            this.btnPeople.BackColor = System.Drawing.Color.White;
            this.btnPeople.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPeople.Location = new System.Drawing.Point(1095, 157);
            this.btnPeople.Name = "btnPeople";
            this.btnPeople.Size = new System.Drawing.Size(164, 63);
            this.btnPeople.TabIndex = 6;
            this.btnPeople.TabStop = false;
            this.btnPeople.Text = "Peoples";
            this.btnPeople.UseVisualStyleBackColor = false;
            this.btnPeople.Click += new System.EventHandler(this.btnPeople_Click);
            // 
            // btnMembers
            // 
            this.btnMembers.BackColor = System.Drawing.Color.White;
            this.btnMembers.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMembers.Location = new System.Drawing.Point(1045, 293);
            this.btnMembers.Name = "btnMembers";
            this.btnMembers.Size = new System.Drawing.Size(214, 63);
            this.btnMembers.TabIndex = 5;
            this.btnMembers.TabStop = false;
            this.btnMembers.Text = "Members";
            this.btnMembers.UseVisualStyleBackColor = false;
            this.btnMembers.Click += new System.EventHandler(this.btnMembers_Click);
            // 
            // btnCoaches
            // 
            this.btnCoaches.BackColor = System.Drawing.Color.White;
            this.btnCoaches.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCoaches.Location = new System.Drawing.Point(1095, 439);
            this.btnCoaches.Name = "btnCoaches";
            this.btnCoaches.Size = new System.Drawing.Size(164, 63);
            this.btnCoaches.TabIndex = 4;
            this.btnCoaches.TabStop = false;
            this.btnCoaches.Text = "Coaches";
            this.btnCoaches.UseVisualStyleBackColor = false;
            this.btnCoaches.Click += new System.EventHandler(this.btnCoaches_Click);
            // 
            // btnCoachTrainging
            // 
            this.btnCoachTrainging.BackColor = System.Drawing.Color.White;
            this.btnCoachTrainging.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCoachTrainging.Location = new System.Drawing.Point(519, 683);
            this.btnCoachTrainging.Name = "btnCoachTrainging";
            this.btnCoachTrainging.Size = new System.Drawing.Size(214, 63);
            this.btnCoachTrainging.TabIndex = 7;
            this.btnCoachTrainging.TabStop = false;
            this.btnCoachTrainging.Text = "CoachTraining";
            this.btnCoachTrainging.UseVisualStyleBackColor = false;
            this.btnCoachTrainging.Click += new System.EventHandler(this.btnCoachTrainging_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.currentEmployeToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1257, 30);
            this.menuStrip1.TabIndex = 8;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // currentEmployeToolStripMenuItem
            // 
            this.currentEmployeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.updatePasswordToolStripMenuItem,
            this.showInfoToolStripMenuItem});
            this.currentEmployeToolStripMenuItem.Name = "currentEmployeToolStripMenuItem";
            this.currentEmployeToolStripMenuItem.Size = new System.Drawing.Size(133, 26);
            this.currentEmployeToolStripMenuItem.Text = "Current Employe";
            this.currentEmployeToolStripMenuItem.DropDownOpening += new System.EventHandler(this.currentEmployeToolStripMenuItem_DropDownOpening);
            // 
            // updatePasswordToolStripMenuItem
            // 
            this.updatePasswordToolStripMenuItem.Enabled = false;
            this.updatePasswordToolStripMenuItem.Name = "updatePasswordToolStripMenuItem";
            this.updatePasswordToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.updatePasswordToolStripMenuItem.Text = "Update Password";
            this.updatePasswordToolStripMenuItem.Click += new System.EventHandler(this.updatePasswordToolStripMenuItem_Click);
            // 
            // showInfoToolStripMenuItem
            // 
            this.showInfoToolStripMenuItem.Name = "showInfoToolStripMenuItem";
            this.showInfoToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.showInfoToolStripMenuItem.Text = "Show Info";
            this.showInfoToolStripMenuItem.Click += new System.EventHandler(this.showInfoToolStripMenuItem_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1257, 745);
            this.Controls.Add(this.btnCoachTrainging);
            this.Controls.Add(this.btnPeople);
            this.Controls.Add(this.btnMembers);
            this.Controls.Add(this.btnCoaches);
            this.Controls.Add(this.btnEmployee);
            this.Controls.Add(this.btnMemberSubscription);
            this.Controls.Add(this.btnSports);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmMain_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnSports;
        private System.Windows.Forms.Button btnMemberSubscription;
        private System.Windows.Forms.Button btnEmployee;
        private System.Windows.Forms.Button btnPeople;
        private System.Windows.Forms.Button btnMembers;
        private System.Windows.Forms.Button btnCoaches;
        private System.Windows.Forms.Button btnCoachTrainging;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem currentEmployeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updatePasswordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showInfoToolStripMenuItem;
    }
}

