﻿using SportCllubeBuisness;
using SportClubeSystem.CoachTraining;
using SportClubeSystem.Members;
using System.Data;
using System.Windows.Forms;

namespace SportClubeSystem.MemberSubscription
{
    public partial class frmListMemberSubscription : Form
    {
        DataTable dtMemberSubscription = new DataTable();
        public frmListMemberSubscription()
        {
            InitializeComponent();
        }

        private void _loadData()
        {
            dtMemberSubscription = clsMemberSubscriptionsBuisness.getAllMemberSubscription();
            dgvMemberSubscription.DataSource = dtMemberSubscription;
            if (dgvMemberSubscription.Rows.Count > 0)
            {
                dgvMemberSubscription.Columns[0].HeaderText = "Subscription ID";
                dgvMemberSubscription.Columns[0].Width = 60;

                dgvMemberSubscription.Columns[1].HeaderText = "Sport Name";
                dgvMemberSubscription.Columns[1].Width = 150;

                dgvMemberSubscription.Columns[2].HeaderText = "Coatch Name";
                dgvMemberSubscription.Columns[2].Width = 300;

                dgvMemberSubscription.Columns[3].HeaderText = "Member Name";
                dgvMemberSubscription.Columns[3].Width = 300;

                dgvMemberSubscription.Columns[4].HeaderText = "Start Date";
                dgvMemberSubscription.Columns[4].Width = 100;

                dgvMemberSubscription.Columns[5].HeaderText = "End Date";
                dgvMemberSubscription.Columns[5].Width = 100;


                dgvMemberSubscription.Columns[6].HeaderText = "Coach ID";
                dgvMemberSubscription.Columns[6].Width = 100;

                dgvMemberSubscription.Columns[7].HeaderText = "Member ID";
                dgvMemberSubscription.Columns[7].Width = 100;
                lbListSize.Text = dgvMemberSubscription.RowCount.ToString();
            }

        }

        private void frmListMemberSubscription_Load(object sender, System.EventArgs e)
        {
            _loadData();
        }

        private void btnAdd_Click(object sender, System.EventArgs e)
        {
            frmAddOrUpdateMemberSubscription form = new frmAddOrUpdateMemberSubscription();
            form.ShowDialog();
            _loadData();
        }

        private void addMemberToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            frmAddOrUpdateMemberSubscription form = new frmAddOrUpdateMemberSubscription();
            form.ShowDialog();
            _loadData();

        }

        private void cmsMemberSubscription_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {
            bool hasData = dtMemberSubscription.Rows.Count > 0;
            int memberSubscriptionID = !hasData ? 0 : (int)dgvMemberSubscription.CurrentRow.Cells[0].Value;
            cmsMemberSubscription.Items[1].Enabled = hasData;
            cmsMemberSubscription.Items[2].Enabled = hasData;
            cmsMemberSubscription.Items[3].Enabled = hasData;
            cmsMemberSubscription.Items[4].Enabled = hasData;

        }

        private void updateMemberSubscriptionToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            int memberSubscriptionID = (int)dgvMemberSubscription.CurrentRow.Cells[0].Value;
            frmAddOrUpdateMemberSubscription form = new frmAddOrUpdateMemberSubscription(memberSubscriptionID);
            form.ShowDialog();
        }

        private void deleteMemberSubscriptionToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            int trianingCoachID = (int)dgvMemberSubscription.CurrentRow.Cells[0].Value;
            if (MessageBox.Show("Are You Sure to Delete This MemberSubscription", "Question", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                if (clsMemberSubscriptionsBuisness.deleteMemberSubscriptionByID(trianingCoachID))
                {
                    MessageBox.Show("the MemberSubscription is delete Successfuly", "Done", MessageBoxButtons.OK);
                    _loadData();

                }
                else
                {
                    MessageBox.Show("Could Not deleted The MemberSubscription", "Done", MessageBoxButtons.OK);

                }
            }
        }

        private void showCoachTriningInfoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            int coachID = (int)dgvMemberSubscription.CurrentRow.Cells[6].Value;
            clsCoachTrainingBuisness coachTraining = clsCoachTrainingBuisness.findCoachTrainingByCoachID(coachID);
            frmShowCoachingTrainingInfo form = new frmShowCoachingTrainingInfo(coachTraining.id);
            form.ShowDialog();

        }

        private void showMemberInfoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            int memberID = (int)dgvMemberSubscription.CurrentRow.Cells[7].Value;
            frmShowMemberInfo form = new frmShowMemberInfo(memberID);
            form.ShowDialog();

        }

        private void cbbFilter_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            txtFilterHolder.Enabled = !(cbbFilter.Text == "none");
        }

        private void txtFilterHolder_TextChanged(object sender, System.EventArgs e)
        {
            string columnName = "";

            switch (cbbFilter.Text)
            {
                case "Subscription ID":
                    {
                        columnName = "subscriptionID";
                    }
                    break;


                case "Sport Name":
                    {
                        columnName = "sportName";
                    }
                    break;
                    ;

                case "Coatch Name":
                    {
                        columnName = "coatchName";
                    }
                    break;

                case "Member Name":
                    {
                        columnName = "memberName";

                    }
                    break;


                case "Start Date":
                    {
                        columnName = "startDate";

                    }
                    break;

                case "End Date":
                    {

                        columnName = "endDate";
                    }
                    break;

                case "Coach ID":
                    {
                        columnName = "coacheID";

                    }
                    break;


                case "Member ID":
                    {
                        columnName = "memberID";

                    }
                    break;

                default:
                    {

                        columnName = "none";
                    }
                    break;
            }

            if (string.IsNullOrEmpty(txtFilterHolder.Text) || columnName == "none")
            {
                dtMemberSubscription.DefaultView.RowFilter = "";
                return;
            }

            if (columnName == "subscriptionID" || columnName == "memberID" || columnName == "coacheID")

                dtMemberSubscription.DefaultView.RowFilter = string.Format("[{0}] ='{1}'", columnName, txtFilterHolder.Text);

            else
                dtMemberSubscription.DefaultView.RowFilter = string.Format("[{0}] like '{1}%'", columnName, txtFilterHolder.Text);


        }

        private void cbbFilter_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (cbbFilter.Text == "Subscription ID" || cbbFilter.Text == "Member ID" || cbbFilter.Text == "Coach ID")
            {
                e.Handled = char.IsDigit(e.KeyChar);

            }

        }

        private void txtFilterHolder_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (cbbFilter.Text == "Subscription ID" || cbbFilter.Text == "Coach ID" || cbbFilter.Text == "Member ID")
            {
                if (char.IsLetter(e.KeyChar))
                {
                    e.Handled = true;
                }
            }
        }
    }
}
