﻿using SportCllubeBuisness;
using SportClubeSystem.GenralClass;
using System;
using System.Data;
using System.Windows.Forms;

namespace SportClubeSystem.MemberSubscription
{
    public partial class frmAddOrUpdateMemberSubscription : Form
    {
        enum enMode { add, update };
        private enMode _mode = enMode.add;
        private clsMemberSubscriptionsBuisness _memberSubscription;
        private int _memberSubscriptionID = 0;

        private DataTable _dtCoachtingTraining = new DataTable();
        private clsCoachTrainingBuisness _coachTraining;

        decimal reminder;

        private DataTable _dtMembers = new DataTable();
        private int _memberID = 0;

        public frmAddOrUpdateMemberSubscription()
        {
            InitializeComponent();
            _mode = enMode.add;
        }

        public frmAddOrUpdateMemberSubscription(int memberSubscriptionID)
        {
            InitializeComponent();
            _memberSubscriptionID = memberSubscriptionID;
            _mode = enMode.update;

        }

        private void _fillCoachingTrainingName()
        {
            _dtCoachtingTraining = clsCoachTrainingBuisness.getAllCoachsTraingin();
            foreach (DataRow row in _dtCoachtingTraining.Rows)
            {
                cbbCoachingTrainingName.Items.Add(row[1] + " ( " + row[3] + ")");
            }

        }


        private void _fillMemberName()
        {
            _dtMembers = clsMemberBuisness.getAllMember();
            foreach (DataRow row in _dtMembers.Rows)
            {
                cbbMemberName.Items.Add(row[2]);
            }
        }

        private void _reseatData()
        {
            if (_mode == enMode.add)
            {
                _memberSubscription = new clsMemberSubscriptionsBuisness();
                lbHeaderTitle.Text = "Add New  MemberSubscription Data";
                btnAdd.Text = "add";
            }
            else
            {
                _memberSubscription = new clsMemberSubscriptionsBuisness();
                lbHeaderTitle.Text = "Update MemberSubscription Data";
                btnAdd.Text = "Update";
            }

            _fillCoachingTrainingName();
            _fillMemberName();
            dtpEndDate.Value = DateTime.Now;
            dtpEndDate.Value = DateTime.Now.AddDays(30);
            lbFee.Text = "????";
        }
        private void _loadData(int memberSubscriptionID)
        {


            _memberSubscription = clsMemberSubscriptionsBuisness.findMemberSubscrioptionsByID(memberSubscriptionID);
            if (_memberSubscription == null)
            {

            }

            cbbMemberName.SelectedIndex = cbbMemberName.FindString(clsMemberBuisness.findMemberByID(_memberSubscription.memberID).personInfo.fullName);
            clsCoachTrainingBuisness coachinTraingin = clsCoachTrainingBuisness.findCoachTrainingByID(_memberSubscription.coatchTrainingID);

            cbbCoachingTrainingName.SelectedIndex = cbbCoachingTrainingName.FindString(coachinTraingin.coatchInfo.fullName + " ( " + coachinTraingin.sprotInfo.name + ")");
            cbbMemberName.Enabled = false;
            dtpEndDate.Value = _memberSubscription.startDate;
            dtpEndDate.Value = _memberSubscription.endDate;
            lbFee.Text = _memberSubscription.fee.ToString();

        }


        private void frmAddOrUpdateMemberSubscription_Load(object sender, EventArgs e)
        {
            _reseatData();
            if (_mode == enMode.update)
                _loadData(_memberSubscriptionID);
        }

        private void cbbCoachingTrainingName_SelectedIndexChanged(object sender, EventArgs e)
        {
            string[] nameAndSport = cbbCoachingTrainingName.Text.Split('(');
            string query = $"fullName = '{nameAndSport[0]}' AND sportName = '{nameAndSport[1].Substring(1, nameAndSport[1].Length - 2)}' ";
            DataRow[] coathTraiingRows = _dtCoachtingTraining.Select(query);

            _coachTraining = clsCoachTrainingBuisness.findCoachTrainingByID(Convert.ToInt32(coathTraiingRows[0][0]));

            if (_coachTraining != null)
            {
                lbFee.Text = _coachTraining.fee.ToString();
                if (_mode == enMode.update && _coachTraining.id != _memberSubscription.coatchTrainingID)
                {
                    reminder = Convert.ToDecimal(lbFee.Text) - _memberSubscription.fee;
                    lbRminder.Visible = true;
                    lbRminderHolder.Visible = true;
                    lbRminderHolder.Text = Convert.ToString(reminder);
                    _memberSubscription.fee = reminder;
                }
            }
        }

        private void cbbMemberName_SelectedIndexChanged(object sender, EventArgs e)
        {
            string nameAndSport = cbbMemberName.Text;
            string query = $"fullName = '{nameAndSport}' ";
            _memberID = Convert.ToInt32(_dtMembers.Select(query)[0][0]);

        }

        private void cbbValidation(object sender, System.ComponentModel.CancelEventArgs e)
        {
            string data = ((ComboBox)sender).Text;
            if (string.IsNullOrEmpty(data))
            {
                epHndler.SetError((ComboBox)sender, "You must select itme");
                return;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!this.ValidateChildren())
            {
                MessageBox.Show("Some Feild Requirment ", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (_coachTraining != null)
            {
                _memberSubscription.fee = reminder != 0 ? reminder : Convert.ToDecimal(lbFee.Text);
                _memberSubscription.coatchTrainingID = Convert.ToInt32(_coachTraining.id);
            }

            if (_memberID > 0)
                _memberSubscription.memberID = Convert.ToInt32(_memberID);

            _memberSubscription.startDate = dtpStartDate.Value;
            _memberSubscription.endDate = dtpStartDate.Value.AddDays(30);
            _memberSubscription.addBy = clsEmployee.employee.id;

            if (_memberSubscription.save())
            {
                MessageBox.Show("Adding Data Seccessfuly", "Done", MessageBoxButtons.OK);
                lbMemberID.Text = _memberSubscription.id.ToString();
                return;
            }
            else
            {
                MessageBox.Show("Feild to add Data", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
