﻿namespace SportClubeSystem.MemberSubscription
{
    partial class frmAddOrUpdateMemberSubscription
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbHeaderTitle = new System.Windows.Forms.Label();
            this.lable = new System.Windows.Forms.Label();
            this.lbMemberID = new System.Windows.Forms.Label();
            this.cbbCoachingTrainingName = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbbMemberName = new System.Windows.Forms.ComboBox();
            this.dtpStartDate = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dtpEndDate = new System.Windows.Forms.DateTimePicker();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lbFee = new System.Windows.Forms.Label();
            this.epHndler = new System.Windows.Forms.ErrorProvider(this.components);
            this.lbRminderHolder = new System.Windows.Forms.Label();
            this.lbRminder = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.epHndler)).BeginInit();
            this.SuspendLayout();
            // 
            // lbHeaderTitle
            // 
            this.lbHeaderTitle.AutoSize = true;
            this.lbHeaderTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHeaderTitle.ForeColor = System.Drawing.Color.Red;
            this.lbHeaderTitle.Location = new System.Drawing.Point(235, 70);
            this.lbHeaderTitle.Name = "lbHeaderTitle";
            this.lbHeaderTitle.Size = new System.Drawing.Size(680, 54);
            this.lbHeaderTitle.TabIndex = 11;
            this.lbHeaderTitle.Text = "Add New MemberSubscription";
            // 
            // lable
            // 
            this.lable.AutoSize = true;
            this.lable.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.lable.Location = new System.Drawing.Point(95, 219);
            this.lable.Name = "lable";
            this.lable.Size = new System.Drawing.Size(126, 26);
            this.lable.TabIndex = 12;
            this.lable.Text = "MemberID :";
            // 
            // lbMemberID
            // 
            this.lbMemberID.AutoSize = true;
            this.lbMemberID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.lbMemberID.Location = new System.Drawing.Point(239, 219);
            this.lbMemberID.Name = "lbMemberID";
            this.lbMemberID.Size = new System.Drawing.Size(84, 26);
            this.lbMemberID.TabIndex = 13;
            this.lbMemberID.Text = "[?????]";
            // 
            // cbbCoachingTrainingName
            // 
            this.cbbCoachingTrainingName.FormattingEnabled = true;
            this.cbbCoachingTrainingName.Location = new System.Drawing.Point(245, 278);
            this.cbbCoachingTrainingName.Name = "cbbCoachingTrainingName";
            this.cbbCoachingTrainingName.Size = new System.Drawing.Size(417, 24);
            this.cbbCoachingTrainingName.TabIndex = 14;
            this.cbbCoachingTrainingName.SelectedIndexChanged += new System.EventHandler(this.cbbCoachingTrainingName_SelectedIndexChanged);
            this.cbbCoachingTrainingName.Validating += new System.ComponentModel.CancelEventHandler(this.cbbValidation);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.label2.Location = new System.Drawing.Point(57, 278);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(164, 26);
            this.label2.TabIndex = 15;
            this.label2.Text = "CoachTraining :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.label4.Location = new System.Drawing.Point(52, 341);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(169, 26);
            this.label4.TabIndex = 19;
            this.label4.Text = "Member Name :";
            // 
            // cbbMemberName
            // 
            this.cbbMemberName.FormattingEnabled = true;
            this.cbbMemberName.Location = new System.Drawing.Point(245, 345);
            this.cbbMemberName.Name = "cbbMemberName";
            this.cbbMemberName.Size = new System.Drawing.Size(417, 24);
            this.cbbMemberName.TabIndex = 18;
            this.cbbMemberName.SelectedIndexChanged += new System.EventHandler(this.cbbMemberName_SelectedIndexChanged);
            this.cbbMemberName.Validating += new System.ComponentModel.CancelEventHandler(this.cbbValidation);
            // 
            // dtpStartDate
            // 
            this.dtpStartDate.Location = new System.Drawing.Point(910, 222);
            this.dtpStartDate.Name = "dtpStartDate";
            this.dtpStartDate.Size = new System.Drawing.Size(200, 22);
            this.dtpStartDate.TabIndex = 20;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.label5.Location = new System.Drawing.Point(754, 220);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(122, 26);
            this.label5.TabIndex = 21;
            this.label5.Text = "Start Date :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.label6.Location = new System.Drawing.Point(754, 278);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(115, 26);
            this.label6.TabIndex = 23;
            this.label6.Text = "End Date :";
            // 
            // dtpEndDate
            // 
            this.dtpEndDate.Enabled = false;
            this.dtpEndDate.Location = new System.Drawing.Point(910, 280);
            this.dtpEndDate.Name = "dtpEndDate";
            this.dtpEndDate.Size = new System.Drawing.Size(200, 22);
            this.dtpEndDate.TabIndex = 22;
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.White;
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.btnAdd.Location = new System.Drawing.Point(981, 438);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(129, 58);
            this.btnAdd.TabIndex = 24;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.White;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.btnClose.Location = new System.Drawing.Point(817, 438);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(129, 58);
            this.btnClose.TabIndex = 25;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.label3.Location = new System.Drawing.Point(808, 341);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 26);
            this.label3.TabIndex = 27;
            this.label3.Text = "Fee :";
            // 
            // lbFee
            // 
            this.lbFee.AutoSize = true;
            this.lbFee.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.lbFee.Location = new System.Drawing.Point(916, 341);
            this.lbFee.Name = "lbFee";
            this.lbFee.Size = new System.Drawing.Size(84, 26);
            this.lbFee.TabIndex = 28;
            this.lbFee.Text = "??????";
            // 
            // epHndler
            // 
            this.epHndler.ContainerControl = this;
            // 
            // lbRminderHolder
            // 
            this.lbRminderHolder.AutoSize = true;
            this.lbRminderHolder.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.lbRminderHolder.Location = new System.Drawing.Point(916, 389);
            this.lbRminderHolder.Name = "lbRminderHolder";
            this.lbRminderHolder.Size = new System.Drawing.Size(24, 26);
            this.lbRminderHolder.TabIndex = 30;
            this.lbRminderHolder.Text = "0";
            this.lbRminderHolder.Visible = false;
            // 
            // lbRminder
            // 
            this.lbRminder.AutoSize = true;
            this.lbRminder.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.lbRminder.Location = new System.Drawing.Point(744, 389);
            this.lbRminder.Name = "lbRminder";
            this.lbRminder.Size = new System.Drawing.Size(125, 26);
            this.lbRminder.TabIndex = 29;
            this.lbRminder.Text = "Reminder  :";
            this.lbRminder.Visible = false;
            // 
            // frmAddOrUpdateMemberSubscription
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1147, 523);
            this.Controls.Add(this.lbRminderHolder);
            this.Controls.Add(this.lbRminder);
            this.Controls.Add(this.lbFee);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dtpEndDate);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dtpStartDate);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cbbMemberName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbbCoachingTrainingName);
            this.Controls.Add(this.lbMemberID);
            this.Controls.Add(this.lable);
            this.Controls.Add(this.lbHeaderTitle);
            this.Name = "frmAddOrUpdateMemberSubscription";
            this.Text = "frmAddOrUpdateMemberSubscription";
            this.Load += new System.EventHandler(this.frmAddOrUpdateMemberSubscription_Load);
            ((System.ComponentModel.ISupportInitialize)(this.epHndler)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbHeaderTitle;
        private System.Windows.Forms.Label lable;
        private System.Windows.Forms.Label lbMemberID;
        private System.Windows.Forms.ComboBox cbbCoachingTrainingName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbbMemberName;
        private System.Windows.Forms.DateTimePicker dtpStartDate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dtpEndDate;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbFee;
        private System.Windows.Forms.ErrorProvider epHndler;
        private System.Windows.Forms.Label lbRminderHolder;
        private System.Windows.Forms.Label lbRminder;
    }
}