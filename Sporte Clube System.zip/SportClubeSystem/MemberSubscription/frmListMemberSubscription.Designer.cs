﻿namespace SportClubeSystem.MemberSubscription
{
    partial class frmListMemberSubscription
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbHeaderTitle = new System.Windows.Forms.Label();
            this.txtFilterHolder = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.lbListSize = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbbFilter = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvMemberSubscription = new System.Windows.Forms.DataGridView();
            this.cmsMemberSubscription = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.addMemberToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateMemberSubscriptionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteMemberSubscriptionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showCoachTriningInfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showMemberInfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnAdd = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMemberSubscription)).BeginInit();
            this.cmsMemberSubscription.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbHeaderTitle
            // 
            this.lbHeaderTitle.AutoSize = true;
            this.lbHeaderTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHeaderTitle.ForeColor = System.Drawing.Color.Red;
            this.lbHeaderTitle.Location = new System.Drawing.Point(388, 333);
            this.lbHeaderTitle.Name = "lbHeaderTitle";
            this.lbHeaderTitle.Size = new System.Drawing.Size(780, 54);
            this.lbHeaderTitle.TabIndex = 10;
            this.lbHeaderTitle.Text = "MemberSubscription  Management";
            // 
            // txtFilterHolder
            // 
            this.txtFilterHolder.Enabled = false;
            this.txtFilterHolder.Location = new System.Drawing.Point(260, 440);
            this.txtFilterHolder.Name = "txtFilterHolder";
            this.txtFilterHolder.Size = new System.Drawing.Size(188, 22);
            this.txtFilterHolder.TabIndex = 32;
            this.txtFilterHolder.TextChanged += new System.EventHandler(this.txtFilterHolder_TextChanged);
            this.txtFilterHolder.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFilterHolder_KeyPress);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(1373, 675);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(159, 49);
            this.btnClose.TabIndex = 31;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            // 
            // lbListSize
            // 
            this.lbListSize.AutoSize = true;
            this.lbListSize.Location = new System.Drawing.Point(113, 691);
            this.lbListSize.Name = "lbListSize";
            this.lbListSize.Size = new System.Drawing.Size(14, 16);
            this.lbListSize.TabIndex = 30;
            this.lbListSize.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(42, 691);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 16);
            this.label5.TabIndex = 29;
            this.label5.Text = "Recourd :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 691);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(14, 16);
            this.label4.TabIndex = 28;
            this.label4.Text = "#";
            // 
            // cbbFilter
            // 
            this.cbbFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbFilter.FormattingEnabled = true;
            this.cbbFilter.Items.AddRange(new object[] {
            "none",
            "Subscription ID",
            "Sport Name",
            "Coatch Name",
            "Member Name",
            "Start Date",
            "End Date",
            "Coach ID",
            "Member ID"});
            this.cbbFilter.Location = new System.Drawing.Point(91, 440);
            this.cbbFilter.Name = "cbbFilter";
            this.cbbFilter.Size = new System.Drawing.Size(154, 24);
            this.cbbFilter.TabIndex = 25;
            this.cbbFilter.SelectedIndexChanged += new System.EventHandler(this.cbbFilter_SelectedIndexChanged);
            this.cbbFilter.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbbFilter_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.label2.Location = new System.Drawing.Point(22, 441);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 22);
            this.label2.TabIndex = 27;
            this.label2.Text = "Filter :";
            // 
            // dgvMemberSubscription
            // 
            this.dgvMemberSubscription.BackgroundColor = System.Drawing.Color.White;
            this.dgvMemberSubscription.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMemberSubscription.ContextMenuStrip = this.cmsMemberSubscription;
            this.dgvMemberSubscription.Location = new System.Drawing.Point(24, 477);
            this.dgvMemberSubscription.Name = "dgvMemberSubscription";
            this.dgvMemberSubscription.RowHeadersWidth = 51;
            this.dgvMemberSubscription.RowTemplate.Height = 24;
            this.dgvMemberSubscription.Size = new System.Drawing.Size(1508, 184);
            this.dgvMemberSubscription.TabIndex = 24;
            // 
            // cmsMemberSubscription
            // 
            this.cmsMemberSubscription.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.cmsMemberSubscription.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addMemberToolStripMenuItem,
            this.updateMemberSubscriptionToolStripMenuItem,
            this.deleteMemberSubscriptionToolStripMenuItem,
            this.showCoachTriningInfoToolStripMenuItem,
            this.showMemberInfoToolStripMenuItem});
            this.cmsMemberSubscription.Name = "contextMenuStrip1";
            this.cmsMemberSubscription.Size = new System.Drawing.Size(270, 152);
            this.cmsMemberSubscription.Opening += new System.ComponentModel.CancelEventHandler(this.cmsMemberSubscription_Opening);
            // 
            // addMemberToolStripMenuItem
            // 
            this.addMemberToolStripMenuItem.Name = "addMemberToolStripMenuItem";
            this.addMemberToolStripMenuItem.Size = new System.Drawing.Size(269, 24);
            this.addMemberToolStripMenuItem.Text = "Add MemberSubscription ";
            this.addMemberToolStripMenuItem.Click += new System.EventHandler(this.addMemberToolStripMenuItem_Click);
            // 
            // updateMemberSubscriptionToolStripMenuItem
            // 
            this.updateMemberSubscriptionToolStripMenuItem.Name = "updateMemberSubscriptionToolStripMenuItem";
            this.updateMemberSubscriptionToolStripMenuItem.Size = new System.Drawing.Size(269, 24);
            this.updateMemberSubscriptionToolStripMenuItem.Text = "Update MemberSubscription";
            this.updateMemberSubscriptionToolStripMenuItem.Click += new System.EventHandler(this.updateMemberSubscriptionToolStripMenuItem_Click);
            // 
            // deleteMemberSubscriptionToolStripMenuItem
            // 
            this.deleteMemberSubscriptionToolStripMenuItem.Name = "deleteMemberSubscriptionToolStripMenuItem";
            this.deleteMemberSubscriptionToolStripMenuItem.Size = new System.Drawing.Size(269, 24);
            this.deleteMemberSubscriptionToolStripMenuItem.Text = "Delete MemberSubscription";
            this.deleteMemberSubscriptionToolStripMenuItem.Click += new System.EventHandler(this.deleteMemberSubscriptionToolStripMenuItem_Click);
            // 
            // showCoachTriningInfoToolStripMenuItem
            // 
            this.showCoachTriningInfoToolStripMenuItem.Name = "showCoachTriningInfoToolStripMenuItem";
            this.showCoachTriningInfoToolStripMenuItem.Size = new System.Drawing.Size(269, 24);
            this.showCoachTriningInfoToolStripMenuItem.Text = "Show CoachTrining Info";
            this.showCoachTriningInfoToolStripMenuItem.Click += new System.EventHandler(this.showCoachTriningInfoToolStripMenuItem_Click);
            // 
            // showMemberInfoToolStripMenuItem
            // 
            this.showMemberInfoToolStripMenuItem.Name = "showMemberInfoToolStripMenuItem";
            this.showMemberInfoToolStripMenuItem.Size = new System.Drawing.Size(269, 24);
            this.showMemberInfoToolStripMenuItem.Text = "Show Member Info";
            this.showMemberInfoToolStripMenuItem.Click += new System.EventHandler(this.showMemberInfoToolStripMenuItem_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.White;
            this.btnAdd.Image = global::SportClubeSystem.Properties.Resources.add;
            this.btnAdd.Location = new System.Drawing.Point(1468, 415);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(64, 47);
            this.btnAdd.TabIndex = 26;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SportClubeSystem.Properties.Resources.memberSubscription;
            this.pictureBox1.Location = new System.Drawing.Point(503, 28);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(551, 279);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // frmListMemberSubscription
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1568, 744);
            this.Controls.Add(this.txtFilterHolder);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lbListSize);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cbbFilter);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.dgvMemberSubscription);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lbHeaderTitle);
            this.Name = "frmListMemberSubscription";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmListMemberSubscription";
            this.Load += new System.EventHandler(this.frmListMemberSubscription_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMemberSubscription)).EndInit();
            this.cmsMemberSubscription.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbHeaderTitle;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtFilterHolder;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lbListSize;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbbFilter;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DataGridView dgvMemberSubscription;
        private System.Windows.Forms.ContextMenuStrip cmsMemberSubscription;
        private System.Windows.Forms.ToolStripMenuItem addMemberToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateMemberSubscriptionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteMemberSubscriptionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showCoachTriningInfoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showMemberInfoToolStripMenuItem;
    }
}