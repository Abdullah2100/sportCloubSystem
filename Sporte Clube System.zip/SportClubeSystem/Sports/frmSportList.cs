﻿using SportCllubeBuisness;
using System;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;

namespace SportClubeSystem.Sports
{
    public partial class frmSportList : Form
    {
        DataTable dtSportList = new DataTable();
        public frmSportList()
        {
            InitializeComponent();
        }
        private void _pageLoad()
        {
            dgvSport.DataSource = clsSportBuisness.getAllSport();
            if (dgvSport.Rows.Count > 0)
            {

                dgvSport.Columns[0].HeaderText = "Sport ID";
                dgvSport.Columns[0].Width = 90;


                dgvSport.Columns[1].Width = 230;

                dgvSport.Columns[2].HeaderText = "Create Date";
                dgvSport.Columns[2].Width = 115;


                dgvSport.Columns[2].HeaderText = "Is Active";
                dgvSport.Columns[3].Width = 115;
                lbListSize.Text = dgvSport.Rows.Count.ToString();
            }

        }


        private void frmSport_Load(object sender, EventArgs e)
        {
            _pageLoad();

        }

        private void dToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAddOrUpdateSport form = new frmAddOrUpdateSport();
            form.ShowDialog();
            _pageLoad();

        }

        private void updateSportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int id = (int)dgvSport.CurrentRow.Cells[0].Value;
            frmAddOrUpdateSport form = new frmAddOrUpdateSport(id);
            form.ShowDialog();
            _pageLoad();
        }

        private void deleteSportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int id = (int)dgvSport.CurrentRow.Cells[0].Value;

            if (MessageBox.Show("Are You Sure You Want To Delte This Sport", "Atention", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == DialogResult.OK)
            {
                if (clsSportBuisness.deleteSport(id))
                {
                    MessageBox.Show("Delete Sport Seccessfuly", "Done", MessageBoxButtons.OKCancel);
                    _pageLoad();
                }
                else
                {
                    MessageBox.Show("Could Not Delete  Sport it has Smoe Link", "Error", MessageBoxButtons.OKCancel);

                }
            }
        }

        private void cnsMenu_Opening(object sender, CancelEventArgs e)
        {
            bool hasData = dtSportList.Rows.Count > 0;
            int id = !hasData ? 0 : (int)dgvSport.CurrentRow.Cells[0].Value;

            bool isActivate = clsSportBuisness.isSportActiveByID(id);
            cmsSport.Items[4].Enabled = (!isActivate && hasData);
            cmsSport.Items[3].Enabled = (isActivate && hasData);
            cmsSport.Items[1].Enabled = hasData;
            cmsSport.Items[2].Enabled = hasData;



        }

        private void changeSportStateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int id = (int)dgvSport.CurrentRow.Cells[0].Value;

            if (MessageBox.Show("Are You Sure You Want To Deactivate This Sport", "Atention", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == DialogResult.OK)
            {
                if (clsSportBuisness.activeSport(id))
                {
                    MessageBox.Show(" Sport is Deactivate  Seccessfuly", "Done", MessageBoxButtons.OKCancel);
                    _pageLoad();
                }
                else
                {
                    MessageBox.Show("Could Not Deactivate  Sport", "Error", MessageBoxButtons.OKCancel);

                }
            }
        }

        private void deActivateSportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int id = (int)dgvSport.CurrentRow.Cells[0].Value;

            if (MessageBox.Show("Are You Sure You Want To Activate This Sport", "Atention", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == DialogResult.OK)
            {
                if (clsSportBuisness.deActiveSport(id))
                {
                    MessageBox.Show(" Sport is Activate  Seccessfuly", "Done", MessageBoxButtons.OKCancel);
                    _pageLoad();
                }
                else
                {
                    MessageBox.Show("Could Not Activate  Sport", "Error", MessageBoxButtons.OKCancel);

                }
            }
        }


        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
