﻿using SportCllubeBuisness;
using SportClubeSystem.GenralClass;
using System;
using System.Windows.Forms;

namespace SportClubeSystem.Sports
{
    public partial class frmAddOrUpdateSport : Form
    {
        public enum enSport_mode { add, update };
        public enSport_mode _mode;
        public int sportID = 0;
        clsSportBuisness sport;

        public frmAddOrUpdateSport()
        {
            InitializeComponent();
            _mode = enSport_mode.add;
        }

        public frmAddOrUpdateSport(int sportID)
        {
            InitializeComponent();
            _mode = enSport_mode.update;
            this.sportID = sportID;
        }

        private void _reseat()
        {
            txtName.Text = "";

            if (_mode == enSport_mode.add)
            {
                sport = new clsSportBuisness();
                btnSave.Text = "Add";
                lbHeader.Text = "Add New Sport";
            }
            else
            {
                btnSave.Text = "Update";
                lbHeader.Text = "Update Sport";
            }
        }

        public void _loadData(int id)
        {
            sport = clsSportBuisness.findSport(id);
            if (sport == null)
            {
                MessageBox.Show("Sport Not Found ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }


            lbID.Visible = true;
            lbIDHolder.Visible = true;
            txtName.Text = sport.name;
            lbIDHolder.Text = sport.id.ToString();

        }

        private void frmAddOrUpdateSport_Load(object sender, EventArgs e)
        {
            _reseat();
            if (_mode != enSport_mode.add)
                _loadData(this.sportID);

        }

        private void txtName_Validated(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtName.Text))
            {

                errorProvider1.SetError(txtName, "Name Must Not be Empty");
                return;
            }
            if (clsSportBuisness.isSportExistByName(txtName.Text))
            {
                errorProvider1.SetError(txtName, "Sport Name is Already Used");
                return;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!this.ValidateChildren())
            {
                MessageBox.Show("Some Feild Must Be Valide", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            sport.name = txtName.Text;
            sport.addBy = clsEmployee.employee.id;

            if (sport.save())
            {
                MessageBox.Show("Adding Successfuly", "Done", MessageBoxButtons.OK);
                btnSave.Text = "Update";
                lbHeader.Text = "Update Sport";
                _mode = enSport_mode.update;
            }
            else
            {
                MessageBox.Show("Could Not Save Sport To Database", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

    }
}
