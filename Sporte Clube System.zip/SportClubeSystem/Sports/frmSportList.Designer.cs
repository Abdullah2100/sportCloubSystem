﻿namespace SportClubeSystem.Sports
{
    partial class frmSportList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvSport = new System.Windows.Forms.DataGridView();
            this.cmsSport = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.dToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateSportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteSportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changeSportStateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deActivateSportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lbListSize = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSport)).BeginInit();
            this.cmsSport.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 17.8F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(304, 334);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(282, 36);
            this.label1.TabIndex = 1;
            this.label1.Text = "Sport Management";
            // 
            // dgvSport
            // 
            this.dgvSport.BackgroundColor = System.Drawing.Color.White;
            this.dgvSport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSport.ContextMenuStrip = this.cmsSport;
            this.dgvSport.Location = new System.Drawing.Point(45, 453);
            this.dgvSport.Name = "dgvSport";
            this.dgvSport.RowHeadersWidth = 51;
            this.dgvSport.RowTemplate.Height = 24;
            this.dgvSport.Size = new System.Drawing.Size(824, 217);
            this.dgvSport.TabIndex = 2;
            // 
            // cmsSport
            // 
            this.cmsSport.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.cmsSport.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dToolStripMenuItem,
            this.updateSportToolStripMenuItem,
            this.deleteSportToolStripMenuItem,
            this.changeSportStateToolStripMenuItem,
            this.deActivateSportToolStripMenuItem});
            this.cmsSport.Name = "cnsMenu";
            this.cmsSport.Size = new System.Drawing.Size(211, 152);
            this.cmsSport.Opening += new System.ComponentModel.CancelEventHandler(this.cnsMenu_Opening);
            // 
            // dToolStripMenuItem
            // 
            this.dToolStripMenuItem.Name = "dToolStripMenuItem";
            this.dToolStripMenuItem.Size = new System.Drawing.Size(210, 24);
            this.dToolStripMenuItem.Text = "Add Sport";
            this.dToolStripMenuItem.Click += new System.EventHandler(this.dToolStripMenuItem_Click);
            // 
            // updateSportToolStripMenuItem
            // 
            this.updateSportToolStripMenuItem.Name = "updateSportToolStripMenuItem";
            this.updateSportToolStripMenuItem.Size = new System.Drawing.Size(210, 24);
            this.updateSportToolStripMenuItem.Text = "Update Sport";
            this.updateSportToolStripMenuItem.Click += new System.EventHandler(this.updateSportToolStripMenuItem_Click);
            // 
            // deleteSportToolStripMenuItem
            // 
            this.deleteSportToolStripMenuItem.Name = "deleteSportToolStripMenuItem";
            this.deleteSportToolStripMenuItem.Size = new System.Drawing.Size(210, 24);
            this.deleteSportToolStripMenuItem.Text = "Delete Sport";
            this.deleteSportToolStripMenuItem.Click += new System.EventHandler(this.deleteSportToolStripMenuItem_Click);
            // 
            // changeSportStateToolStripMenuItem
            // 
            this.changeSportStateToolStripMenuItem.Name = "changeSportStateToolStripMenuItem";
            this.changeSportStateToolStripMenuItem.Size = new System.Drawing.Size(210, 24);
            this.changeSportStateToolStripMenuItem.Text = "Activate Sport";
            this.changeSportStateToolStripMenuItem.Click += new System.EventHandler(this.changeSportStateToolStripMenuItem_Click);
            // 
            // deActivateSportToolStripMenuItem
            // 
            this.deActivateSportToolStripMenuItem.Name = "deActivateSportToolStripMenuItem";
            this.deActivateSportToolStripMenuItem.Size = new System.Drawing.Size(210, 24);
            this.deActivateSportToolStripMenuItem.Text = "DeActivate Sport";
            this.deActivateSportToolStripMenuItem.Click += new System.EventHandler(this.deActivateSportToolStripMenuItem_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(44, 693);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(14, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "#";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(64, 693);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 16);
            this.label5.TabIndex = 7;
            this.label5.Text = "Recourd :";
            // 
            // lbListSize
            // 
            this.lbListSize.AutoSize = true;
            this.lbListSize.Location = new System.Drawing.Point(135, 693);
            this.lbListSize.Name = "lbListSize";
            this.lbListSize.Size = new System.Drawing.Size(14, 16);
            this.lbListSize.TabIndex = 8;
            this.lbListSize.Text = "0";
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(710, 682);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(159, 49);
            this.btnClose.TabIndex = 9;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Image = global::SportClubeSystem.Properties.Resources.add;
            this.button1.Location = new System.Drawing.Point(805, 378);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(64, 47);
            this.button1.TabIndex = 3;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SportClubeSystem.Properties.Resources.sportManagment;
            this.pictureBox1.Location = new System.Drawing.Point(214, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(465, 300);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // frmSportList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(927, 738);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lbListSize);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dgvSport);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "frmSportList";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmSport";
            this.Load += new System.EventHandler(this.frmSport_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSport)).EndInit();
            this.cmsSport.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvSport;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbListSize;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ContextMenuStrip cmsSport;
        private System.Windows.Forms.ToolStripMenuItem dToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateSportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteSportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changeSportStateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deActivateSportToolStripMenuItem;
    }
}