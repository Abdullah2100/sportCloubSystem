﻿using SportCllubeBuisness;
using System;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;

namespace SportClubeSystem.People
{
    public partial class frmAddOrUpdatePeoples : Form
    {
        public Action<int> onPersonAdd;

        protected virtual void addPerson(int personId)
        {
            Action<int> addHandler = onPersonAdd;
            if (addHandler != null)
                addHandler(personId);

        }



        private enum enPeopleMode { add, update }
        private enPeopleMode _mode;
        int peopleID = 0;
        clsPeopleBuisness people;
        public frmAddOrUpdatePeoples()
        {
            InitializeComponent();
            _mode = enPeopleMode.add;

        }

        public frmAddOrUpdatePeoples(int peopleID)
        {
            InitializeComponent();
            _mode = enPeopleMode.update;
            this.peopleID = peopleID;
        }


        private void _loadNationalityList()
        {
            DataTable dtNationalityList = new DataTable();
            dtNationalityList = clsNaitonalityBuisness.getAllNationality();
            if (dtNationalityList.Columns.Count > 0)
            {
                foreach (DataRow dr in dtNationalityList.Rows)
                {
                    cbNatilnalityList.Items.Add(dr["name"]);
                }

                cbNatilnalityList.SelectedIndex = 0;
            }
        }
        private void _restart()
        {
            _loadNationalityList();
            if (_mode == enPeopleMode.update)
            {
                btnSave.Text = "Update";
                lbHeaderTitle.Text = "Update Person Data";
            }
            else
            {
                people = new clsPeopleBuisness();
                btnSave.Text = "Add";
                lbHeaderTitle.Text = "Add New Peorson";
            }

            dtpBrithDay.Value = DateTime.Now;
            rbMale.Checked = true;
            txtFirstName.Text = "";
            txtSecondName.Text = "";
            txtThirdName.Text = "";
            txtFamilyName.Text = "";
            txtPhone.Text = "";
            TxtAddress.Text = "";
        }

        private void _loadData(int id)
        {
            people = clsPeopleBuisness.findPeopleByID(id);
            if (people == null)
            {
                MessageBox.Show("People  Not Found ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }

            dtpBrithDay.Value = people.brithday;
            cbNatilnalityList.SelectedIndex = cbNatilnalityList.FindString(people.nationalityIfno.name);

            if (people.gender)
                rbMale.Checked = true;
            else
                rbFemale.Checked = true;

            txtFirstName.Text = people.firstName;
            txtSecondName.Text = people.secondName;
            txtThirdName.Text = people.thirdName;
            txtFamilyName.Text = people.familyName;
            txtPhone.Text = people.phone;
            TxtAddress.Text = people.address;

        }


        private void genral_Validating(object sender, CancelEventArgs e)
        {
            TextBox temp = (TextBox)sender;
            if (string.IsNullOrEmpty(temp.Text))
            {
                epHolder.SetError(temp, "required Feild must not be null");
            }

        }
        private void txtPhone_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtPhone.Text))
            {
                epHolder.SetError(txtPhone, "required Feild must not be null");
            }
            if (clsPeopleBuisness.isPeopleExistByPhon(txtPhone.Text))
            {
                epHolder.SetError(txtPhone, "This phone is Allready Used");

            }
        }

        private void frmAddOrUpdatePeople_Load(object sender, EventArgs e)
        {
            _restart();
            if (_mode == enPeopleMode.update)
                _loadData(peopleID);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

            if (!this.ValidateChildren())
            {
                MessageBox.Show("Some Feild Required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            people.nationalityID = clsNaitonalityBuisness.findNationalityByName(cbNatilnalityList.Text).id;
            people.gender = (rbMale.Checked == true);
            people.firstName = txtFirstName.Text;
            people.secondName = txtSecondName.Text;
            people.thirdName = txtThirdName.Text;
            people.familyName = txtFamilyName.Text;
            people.phone = txtPhone.Text;
            people.address = TxtAddress.Text;
            people.brithday = dtpBrithDay.Value;

            if (people.save())
            {
                if (_mode == enPeopleMode.add)
                {

                    btnSave.Text = "Update";
                }

                MessageBox.Show("Person Add Seccssfuly", "Done", MessageBoxButtons.OK);
                onPersonAdd?.Invoke(people.id);
            }
            else
            {
                MessageBox.Show("Could Not Adding Person", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }


        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtPhone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

    }
}
