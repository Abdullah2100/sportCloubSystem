﻿using SportCllubeBuisness;
using System;
using System.Data;
using System.Windows.Forms;

namespace SportClubeSystem.People
{
    public partial class frmPeoplesList : Form
    {
        DataTable dtPeopleList = new DataTable();
        public frmPeoplesList()
        {
            InitializeComponent();
        }

        private void _loadData()
        {
            cbFilter.SelectedIndex = cbFilter.FindString("none");

            dtPeopleList = clsPeopleBuisness.getAllPeople();
            dgvPeople.DataSource = dtPeopleList;

            if (dtPeopleList.Rows.Count > 0)
            {

                dgvPeople.Columns[0].HeaderText = "People ID";
                dgvPeople.Columns[0].Width = 100;

                dgvPeople.Columns[1].HeaderText = "FullName";
                dgvPeople.Columns[1].Width = 320;

                dgvPeople.Columns[2].HeaderText = "Gender";
                dgvPeople.Columns[2].Width = 40;

                dgvPeople.Columns[3].HeaderText = "BrithDay";
                dgvPeople.Columns[3].Width = 130;

                dgvPeople.Columns[4].HeaderText = "Nationality";
                dgvPeople.Columns[4].Width = 120;

                dgvPeople.Columns[5].HeaderText = "Phone";
                dgvPeople.Columns[5].Width = 130;
                lbListSize.Text = dtPeopleList.Rows.Count.ToString();


            }
        }
        private void frmPeopleList_Load(object sender, EventArgs e)
        {
            _loadData();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtFilterHolder.Text = "";
            txtFilterHolder.Visible = (cbFilter.SelectedIndex != 0);

        }


        private void txtFilterHolder_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (cbFilter.Text == "People ID" || cbFilter.Text == "Phone")
            {
                if (char.IsLetter(e.KeyChar))
                {
                    e.Handled = true;
                }

            }


        }

        private void txtFilterHolder_TextChanged(object sender, EventArgs e)
        {
            string columnName = "";
            switch (cbFilter.Text)
            {

                case "People ID":
                    { columnName = "personID"; }
                    break;
                case "FullName":
                    { columnName = "fullName"; }
                    break;

                case "Gender":
                    { columnName = "gender"; }
                    break;
                case "BrithDay":
                    { columnName = "brithday"; }
                    break;
                case "Nationality":
                    { columnName = "nationality"; }
                    break;
                case "Phone":
                    { columnName = "phone"; }
                    break;

                default:
                    {
                        columnName = "none";
                    }
                    break;
            }


            if (string.IsNullOrEmpty(txtFilterHolder.Text) || columnName == "none")
            {
                dtPeopleList.DefaultView.RowFilter = "";
                txtFilterHolder.Text = "";
                return;

            }



            if (columnName == "personID")
            {
                dtPeopleList.DefaultView.RowFilter = string.Format("[{0}] = {1}", columnName, txtFilterHolder.Text);
            }
            else
            {
                dtPeopleList.DefaultView.RowFilter = string.Format("[{0}] like '{1}%'", columnName, txtFilterHolder.Text);

            }

        }
        private void result(int id)
        {
            MessageBox.Show($"thie id for user is {id}", "Done", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }


        private void button1_Click(object sender, EventArgs e)
        {

            frmAddOrUpdatePeoples form = new frmAddOrUpdatePeoples();
            form.ShowDialog();
            _loadData();
        }

        private void dToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAddOrUpdatePeoples form = new frmAddOrUpdatePeoples();
            form.ShowDialog();
            _loadData();

        }

        private void updatePeopleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int peopleID = (int)dgvPeople.CurrentRow.Cells[0].Value;
            frmAddOrUpdatePeoples form = new frmAddOrUpdatePeoples(peopleID);
            form.ShowDialog();
            _loadData();
        }

        private void deletePeopleToolStripMenuItem_Click(object sender, EventArgs e)
        {

            int peopleID = (int)dgvPeople.CurrentRow.Cells[0].Value;
            if (MessageBox.Show($"thie id for user is {peopleID}", "Dision", MessageBoxButtons.OK, MessageBoxIcon.Exclamation) == DialogResult.OK)
            {

                if (clsPeopleBuisness.deletePeople(peopleID))
                {
                    MessageBox.Show($"Person Delete Seccessfuly", "Done", MessageBoxButtons.OK);
                    _loadData();
                    return;
                }
                else
                {
                    MessageBox.Show($"Person Has Some Link", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }

        private void showInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int peopleID = (int)dgvPeople.CurrentRow.Cells[0].Value;

            frmShowPersonInfo form = new frmShowPersonInfo(peopleID);
            form.ShowDialog();
            _loadData();

        }

        private void cmsPeopleList_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {
            int peopleID = dgvPeople.Rows.Count > 0 ? (int)dgvPeople.CurrentRow.Cells[0].Value : 0;

            bool isHasData = peopleID > 0;
            cmsPeopleList.Items[1].Enabled = isHasData;
            cmsPeopleList.Items[2].Enabled = isHasData;
            cmsPeopleList.Items[3].Enabled = isHasData;

        }
    }
}
