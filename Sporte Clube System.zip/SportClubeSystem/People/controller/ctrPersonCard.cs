﻿using SportCllubeBuisness;
using SportClubeSystem.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Resources;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportClubeSystem.People
{
    public partial class ctrPersonCard : UserControl
    {
        public ctrPersonCard()
        {
            InitializeComponent();
        }

        private int _personID;
        public int personID
        {
            get { return _personID; }
        }
        private clsPeopleBuisness _person;
        public clsPeopleBuisness person
        {
            get { return _person; }
        }

        public void loadData(int id)
        {
            _personID = id;
            _person = clsPeopleBuisness.findPeopleByID(id);
            linPersonUpdate.Enabled =_person != null;
            if(person == null)
            {
                          
                return;
            }
            lbId.Text = _person.id.ToString();
            lbName.Text = _person.fullName;
            lbBrithDay.Text = _person.brithday.ToString();
            lbGender.Text = _person.gender? "Male" : "Female";
            
            lbNationality.Text = _person.nationalityIfno.name;
            lbPhone.Text = _person.phone;
            lbAddress.Text = string.IsNullOrEmpty(_person.address)? "" : _person.address;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmAddOrUpdatePeoples form = new frmAddOrUpdatePeoples(_personID);
            form.ShowDialog();
            loadData(_personID);
        }

        private void lbId_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void lbPhone_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void lbAddress_Click(object sender, EventArgs e)
        {

        }
    }
}
