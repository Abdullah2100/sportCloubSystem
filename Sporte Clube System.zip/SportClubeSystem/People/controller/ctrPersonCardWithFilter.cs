﻿using SportCllubeBuisness;
using System;
using System.Windows.Forms;

namespace SportClubeSystem.People.controller
{
    public partial class ctrPersonCardWithFilter : UserControl
    {
        public event Action<int> onPersonSelect;
        public event Action<int> onAddComplate;

        private int _personID = 0;
        public int personID
        {
            get { return ctrPersonCard1.personID; }
        }
        private bool _filterState = true;

        public bool filterState
        {
            set
            {
                _filterState = value;
                gbFilterContoler.Enabled = _filterState;
            }
            get
            {
                return _filterState;
            }
        }
        public void focuseSearch()
        {
            txtFilterName.Focus();
        }

        private clsPeopleBuisness _person { get; set; }
        public clsPeopleBuisness person
        {
            get { return ctrPersonCard1.person; }
        }


        public ctrPersonCardWithFilter()
        {
            InitializeComponent();
        }

        protected void selectPersonAciton(int personID)
        {
            Action<int> selectComplate = onPersonSelect;
            if (selectComplate != null)
                selectComplate(personID);

        }

        protected void addComplate(int personID)
        {
            cbFilter.SelectedIndex = 0;
            _personID = personID;
            _person = clsPeopleBuisness.findPeopleByID(personID);
            if (_person == null)
            {
                MessageBox.Show("You Must riwte Data To be search", "Error", MessageBoxButtons.OK);
                return;
            }
            txtFilterName.Text = personID.ToString();
            gbFilterContoler.Enabled = false;
            ctrPersonCard1.loadData(personID);
            onAddComplate?.Invoke(personID);

        }



        public void loadPersonData(int personID)
        {
            txtFilterName.Text = personID.ToString();
            cbFilter.SelectedIndex = 0;
            ctrPersonCard1.loadData(personID);
        }


        private void cbFilter_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtFilterName.Text))
            {
                MessageBox.Show("You Must riwte Data To be search", "Error", MessageBoxButtons.OK);
                return;
            }
            switch (cbFilter.Text)
            {
                case "Person ID":
                    {
                        int personID = Convert.ToInt32(txtFilterName.Text);
                        _person = clsPeopleBuisness.findPeopleByID(personID);
                        if (_person != null)
                        {
                            ctrPersonCard1.loadData(personID);
                        }

                    }
                    break;
                case "Phone":
                    {
                        _person = clsPeopleBuisness.findPeopleByPhone(txtFilterName.Text);
                        if (_person != null)
                        {
                            ctrPersonCard1.loadData(personID);
                        }

                    }
                    break;

            }
            if (_person == null)
            {
                MessageBox.Show("Person Not Found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtFilterName.Focus();
                return;
            }

            selectPersonAciton(personID);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            frmAddOrUpdatePeoples form = new frmAddOrUpdatePeoples();
            form.onPersonAdd += addComplate;
            form.ShowDialog();
        }

        private void ctrPersonCardWithFilter_Load(object sender, EventArgs e)
        {
            cbFilter.SelectedIndex = 0;
            txtFilterName.Focus();
        }


    }
}
