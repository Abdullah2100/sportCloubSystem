﻿namespace SportClubeSystem.People
{
    partial class ctrPersonCard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbUserCard = new System.Windows.Forms.GroupBox();
            this.lbId = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.linPersonUpdate = new System.Windows.Forms.LinkLabel();
            this.lbPhone = new System.Windows.Forms.Label();
            this.lbGender = new System.Windows.Forms.Label();
            this.lbAddress = new System.Windows.Forms.Label();
            this.lbNationality = new System.Windows.Forms.Label();
            this.lbBrithDay = new System.Windows.Forms.Label();
            this.lbName = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.gbUserCard.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbUserCard
            // 
            this.gbUserCard.Controls.Add(this.lbId);
            this.gbUserCard.Controls.Add(this.label5);
            this.gbUserCard.Controls.Add(this.linPersonUpdate);
            this.gbUserCard.Controls.Add(this.lbPhone);
            this.gbUserCard.Controls.Add(this.lbGender);
            this.gbUserCard.Controls.Add(this.lbAddress);
            this.gbUserCard.Controls.Add(this.lbNationality);
            this.gbUserCard.Controls.Add(this.lbBrithDay);
            this.gbUserCard.Controls.Add(this.lbName);
            this.gbUserCard.Controls.Add(this.label7);
            this.gbUserCard.Controls.Add(this.label8);
            this.gbUserCard.Controls.Add(this.label4);
            this.gbUserCard.Controls.Add(this.label3);
            this.gbUserCard.Controls.Add(this.label2);
            this.gbUserCard.Controls.Add(this.label1);
            this.gbUserCard.Location = new System.Drawing.Point(9, 11);
            this.gbUserCard.Name = "gbUserCard";
            this.gbUserCard.Size = new System.Drawing.Size(867, 298);
            this.gbUserCard.TabIndex = 0;
            this.gbUserCard.TabStop = false;
            this.gbUserCard.Text = "Person Info ";
            // 
            // lbId
            // 
            this.lbId.AutoSize = true;
            this.lbId.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.lbId.Location = new System.Drawing.Point(163, 79);
            this.lbId.Name = "lbId";
            this.lbId.Size = new System.Drawing.Size(72, 26);
            this.lbId.TabIndex = 17;
            this.lbId.Text = "[????]";
            this.lbId.Click += new System.EventHandler(this.lbId_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.label5.Location = new System.Drawing.Point(11, 79);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(121, 26);
            this.label5.TabIndex = 16;
            this.label5.Text = "Person ID :";
            // 
            // linPersonUpdate
            // 
            this.linPersonUpdate.AutoSize = true;
            this.linPersonUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.linPersonUpdate.Location = new System.Drawing.Point(656, 79);
            this.linPersonUpdate.Name = "linPersonUpdate";
            this.linPersonUpdate.Size = new System.Drawing.Size(102, 22);
            this.linPersonUpdate.TabIndex = 15;
            this.linPersonUpdate.TabStop = true;
            this.linPersonUpdate.Text = "Update Info";
            this.linPersonUpdate.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // lbPhone
            // 
            this.lbPhone.AutoSize = true;
            this.lbPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.lbPhone.Location = new System.Drawing.Point(163, 165);
            this.lbPhone.Name = "lbPhone";
            this.lbPhone.Size = new System.Drawing.Size(72, 26);
            this.lbPhone.TabIndex = 14;
            this.lbPhone.Text = "[????]";
            this.lbPhone.Click += new System.EventHandler(this.lbPhone_Click);
            // 
            // lbGender
            // 
            this.lbGender.AutoSize = true;
            this.lbGender.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.lbGender.Location = new System.Drawing.Point(734, 165);
            this.lbGender.Name = "lbGender";
            this.lbGender.Size = new System.Drawing.Size(72, 26);
            this.lbGender.TabIndex = 13;
            this.lbGender.Text = "[????]";
            // 
            // lbAddress
            // 
            this.lbAddress.AutoSize = true;
            this.lbAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.lbAddress.Location = new System.Drawing.Point(163, 219);
            this.lbAddress.Name = "lbAddress";
            this.lbAddress.Size = new System.Drawing.Size(72, 26);
            this.lbAddress.TabIndex = 12;
            this.lbAddress.Text = "[????]";
            this.lbAddress.Click += new System.EventHandler(this.lbAddress_Click);
            // 
            // lbNationality
            // 
            this.lbNationality.AutoSize = true;
            this.lbNationality.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.lbNationality.Location = new System.Drawing.Point(734, 121);
            this.lbNationality.Name = "lbNationality";
            this.lbNationality.Size = new System.Drawing.Size(72, 26);
            this.lbNationality.TabIndex = 11;
            this.lbNationality.Text = "[????]";
            // 
            // lbBrithDay
            // 
            this.lbBrithDay.AutoSize = true;
            this.lbBrithDay.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.lbBrithDay.Location = new System.Drawing.Point(163, 121);
            this.lbBrithDay.Name = "lbBrithDay";
            this.lbBrithDay.Size = new System.Drawing.Size(72, 26);
            this.lbBrithDay.TabIndex = 10;
            this.lbBrithDay.Text = "[????]";
            // 
            // lbName
            // 
            this.lbName.AutoSize = true;
            this.lbName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.lbName.Location = new System.Drawing.Point(163, 40);
            this.lbName.Name = "lbName";
            this.lbName.Size = new System.Drawing.Size(72, 26);
            this.lbName.TabIndex = 9;
            this.lbName.Text = "[????]";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.label7.Location = new System.Drawing.Point(45, 165);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 26);
            this.label7.TabIndex = 7;
            this.label7.Text = "Phone :";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.label8.Location = new System.Drawing.Point(607, 165);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 26);
            this.label8.TabIndex = 6;
            this.label8.Text = "Gender :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.label4.Location = new System.Drawing.Point(28, 219);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 26);
            this.label4.TabIndex = 5;
            this.label4.Text = "Address :";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.label3.Location = new System.Drawing.Point(577, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 26);
            this.label3.TabIndex = 4;
            this.label3.Text = "Nationality :";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.label2.Location = new System.Drawing.Point(24, 121);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 26);
            this.label2.TabIndex = 3;
            this.label2.Text = "BrithDay :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F);
            this.label1.Location = new System.Drawing.Point(43, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 26);
            this.label1.TabIndex = 2;
            this.label1.Text = "Name  :";
            // 
            // ctrPersonCard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.gbUserCard);
            this.Name = "ctrPersonCard";
            this.Size = new System.Drawing.Size(888, 321);
            this.gbUserCard.ResumeLayout(false);
            this.gbUserCard.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbUserCard;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbPhone;
        private System.Windows.Forms.Label lbGender;
        private System.Windows.Forms.Label lbAddress;
        private System.Windows.Forms.Label lbNationality;
        private System.Windows.Forms.Label lbBrithDay;
        private System.Windows.Forms.Label lbName;
        private System.Windows.Forms.LinkLabel linPersonUpdate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbId;
    }
}
