﻿using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace SportClubeSystem.Auth
{
    public partial class frmLogin : Form
    {
        frmLogin _copy;
        public frmLogin()
        {
            InitializeComponent();
        }


        private void btnLogin_Click(object sender, EventArgs e)
        {
            //if (!this.ValidateChildren())
            //{
            //    MessageBox.Show("Some File Must Has Value", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    return;
            //    ;
            //}

            //clsEmployeeBuisness _current = clsEmployeeBuisness.findEmployeeByUserNameAndPassword(txtUsername.Text
            //    , clsUtil.decodePassword(txtPassword.Text
            //    ));

            //if (_current == null)
            //{
            //    MessageBox.Show("User Not Found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    return;
            //}

            //if (!_current.isActive)
            //{
            //    MessageBox.Show("Your Account Not Activated", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    return;

            //}

            //if (chcSaveCurrentUser.Checked)
            //{
            //    clsEmployee.saveEmployeeToRegistory(txtUsername.Text, txtPassword.Text);
            //}
            //else
            //{
            //    clsEmployee.saveEmployeeToRegistory("", "");
            //}

            //clsEmployee.employee = _current;

            frmMain mainform = new frmMain(this);
            this.Hide();
            mainform.ShowDialog();
        }

        private void textBox1_Validating(object sender, CancelEventArgs e)
        {
            //TextBox temp = (TextBox)sender;
            //if (string.IsNullOrEmpty(txtUsername.Text))
            //{
            //    errorProvider1.SetError(temp, "Feild is required");
            //}
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            //string userName = "";
            //string password = "";
            //if (clsEmployee.isUserInRegistory(ref userName, ref password))
            //{
            //    txtUsername.Text = userName;
            //    txtPassword.Text = password;
            //    chcSaveCurrentUser.Checked = true;
            //}
        }
    }
}
